import { Navigation } from "@/components/navigation"
import { Footer } from "@/components/footer"
import { FloatingMagnolia } from "@/components/floating-magnolia"
import { ProjectDetail } from "@/components/portfolio/project-detail"
import { notFound } from "next/navigation"

// Sample project data - in a real app, this would come from a database or CMS
const projects = {
  "southern-heritage": {
    title: "Southern Heritage Website",
    category: "Web Design",
    date: "May 2023",
    client: "Southern Heritage Foundation",
    description:
      "A responsive website for a cultural heritage foundation that celebrates and preserves Southern traditions, stories, and artifacts. The design incorporates Southern Gothic elements with modern web technologies.",
    challenge:
      "The client needed a website that could showcase their extensive collection of historical artifacts and stories while maintaining an authentic Southern Gothic aesthetic. They also required a user-friendly content management system for regular updates.",
    solution:
      "We created a custom WordPress theme with a dark, atmospheric design featuring gold accents and magnolia motifs. The site includes a searchable artifact database, interactive timeline, and story archive with rich media integration.",
    result:
      "The new website increased visitor engagement by 45%, with average session duration increasing from 1:30 to 3:45. Membership sign-ups increased by 28% in the first three months after launch.",
    technologies: ["WordPress", "JavaScript", "GSAP Animation", "Custom CMS", "Responsive Design"],
    mainImage: "/placeholder.svg?height=600&width=800",
    galleryImages: [
      "/placeholder.svg?height=400&width=400",
      "/placeholder.svg?height=400&width=400",
      "/placeholder.svg?height=400&width=400",
      "/placeholder.svg?height=400&width=400",
      "/placeholder.svg?height=400&width=400",
      "/placeholder.svg?height=400&width=400",
    ],
    link: "https://example.com/southern-heritage",
  },
  // Add more projects as needed
}

export default function ProjectPage({ params }: { params: { slug: string } }) {
  const project = projects[params.slug as keyof typeof projects]

  if (!project) {
    notFound()
  }

  return (
    <main className="min-h-screen bg-background">
      <Navigation />

      {/* Hero Section */}
      <section className="relative pt-20 pb-16 overflow-hidden">
        <div className="absolute inset-0 bg-gradient-midnight opacity-95" />

        <div className="container relative z-10 px-4">
          <div className="max-w-4xl mx-auto text-center">
            <h1 className="text-4xl md:text-5xl lg:text-6xl font-serif font-bold text-rich-gold mb-6">
              {project.title}
            </h1>
            <p className="text-xl text-magnolia-white/90 font-lora italic mb-8">{project.category}</p>
          </div>
        </div>

        {/* Decorative elements */}
        <FloatingMagnolia size="lg" color="gold" className="top-12 right-[10%]" />
        <FloatingMagnolia size="md" color="white" className="bottom-24 left-[15%]" delay={1.5} />
      </section>

      {/* Project Detail */}
      <ProjectDetail project={project} />

      <Footer />
    </main>
  )
}

