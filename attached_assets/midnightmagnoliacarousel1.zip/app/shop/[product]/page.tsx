import { Navigation } from "@/components/navigation"
import { Footer } from "@/components/footer"
import { FloatingMagnolia } from "@/components/floating-magnolia"
import Image from "next/image"
import Link from "next/link"
import { Button } from "@/components/ui/button"
import { ArrowLeft, Check, Star } from "lucide-react"
import { Card, CardContent } from "@/components/ui/card"

export default function ProductDetailPage({ params }: { params: { product: string } }) {
  // This would normally fetch the product data based on the slug
  const product = {
    id: 1,
    name: "Midnight Entrepreneur Planner",
    description:
      "Digital planner with income tracking, automation checklists, and strategy frameworks designed for neurodivergent entrepreneurs.",
    longDescription: `
      <p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Sed euismod, nisl vel ultricies lacinia, nisl nisl aliquam nisl, eu aliquam nisl nisl sit amet nisl. Sed euismod, nisl vel ultricies lacinia, nisl nisl aliquam nisl, eu aliquam nisl nisl sit amet nisl.</p>
      
      <p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Nullam in dui mauris. Vivamus hendrerit arcu sed erat molestie vehicula. Sed auctor neque eu tellus rhoncus ut eleifend nibh porttitor. Ut in nulla enim. Phasellus molestie magna non est bibendum non venenatis nisl tempor. Suspendisse dictum feugiat nisl ut dapibus.</p>
    `,
    price: "$49",
    image: "/placeholder.svg?height=600&width=600",
    margin: "85%",
    creationTime: "3-day creation time",
    format: "PDF format with Midnight Magnolia branding and fillable fields",
    category: "digital",
    badge: "Bestseller",
    features: [
      "Income tracking templates designed for neurodivergent brains",
      "Automation checklists to streamline your business processes",
      "Strategy frameworks that adapt to your unique thinking style",
      "Visual cues and color-coding for enhanced focus",
      "Flexible planning pages that don't require rigid daily structure",
    ],
    testimonials: [
      {
        name: "Elena Martinez",
        role: "Digital Product Creator",
        quote:
          "The Midnight Entrepreneur Planner completely transformed my approach to business planning. As someone with ADHD, I finally found a system that works with my brain instead of against it.",
        rating: 5,
      },
      {
        name: "Marcus Thompson",
        role: "Marketing Consultant",
        quote:
          "This planner is unlike anything I've tried before. The income tracking templates alone have helped me increase my revenue by 30% in just two months.",
        rating: 5,
      },
    ],
    relatedProducts: [
      {
        id: 2,
        name: "Southern Digital Brand Kit",
        price: "$79",
        image: "/placeholder.svg?height=300&width=300",
      },
      {
        id: 3,
        name: "Magnolia AI Prompt Collection",
        price: "$37",
        image: "/placeholder.svg?height=300&width=300",
      },
      {
        id: 6,
        name: "Midnight Strategy Vault",
        price: "$97",
        image: "/placeholder.svg?height=300&width=300",
      },
    ],
  }

  return (
    <main className="min-h-screen bg-background">
      <Navigation />

      {/* Product Detail Section */}
      <section className="relative pt-20 pb-16">
        <div className="container px-4">
          <Link href="/shop" className="inline-flex items-center text-rich-gold hover:text-rich-gold/80 mb-6">
            <ArrowLeft className="h-4 w-4 mr-2" />
            Back to Shop
          </Link>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-12">
            <div className="relative">
              <div className="relative aspect-square overflow-hidden rounded-lg bg-midnight-blue/20 border border-rich-gold/20">
                <Image
                  src={product.image || "/placeholder.svg"}
                  alt={product.name}
                  fill
                  className="object-contain p-4"
                />

                {product.badge && (
                  <div className="absolute top-4 right-4 bg-rich-gold text-midnight-blue text-xs font-bold px-3 py-1 rounded-full">
                    {product.badge}
                  </div>
                )}
              </div>
            </div>

            <div>
              <h1 className="text-3xl md:text-4xl font-serif font-bold text-rich-gold mb-4">{product.name}</h1>

              <p className="text-xl font-serif font-bold text-rich-gold mb-6">{product.price}</p>

              <p className="text-foreground/80 font-lora mb-6">{product.description}</p>

              <div className="space-y-4 mb-8">
                {product.features.map((feature, index) => (
                  <div key={index} className="flex items-start gap-2">
                    <Check className="h-5 w-5 text-rich-gold shrink-0 mt-0.5" />
                    <p className="text-foreground/80 font-lora">{feature}</p>
                  </div>
                ))}
              </div>

              <div className="space-y-2 text-sm text-foreground/60 mb-8">
                <p className="flex items-start gap-1">
                  <Check className="h-3 w-3 text-rich-gold shrink-0 mt-0.5" />
                  <span>{product.format}</span>
                </p>
                <p className="flex items-start gap-1">
                  <Check className="h-3 w-3 text-rich-gold shrink-0 mt-0.5" />
                  <span>Instant digital delivery</span>
                </p>
                <p className="flex items-start gap-1">
                  <Check className="h-3 w-3 text-rich-gold shrink-0 mt-0.5" />
                  <span>Lifetime access to updates</span>
                </p>
              </div>

              <Button size="lg" className="w-full bg-rich-gold hover:bg-rich-gold/90 text-midnight-blue mb-4">
                Add to Cart
              </Button>

              <Button
                size="lg"
                variant="outline"
                className="w-full border-rich-gold text-rich-gold hover:bg-rich-gold/10"
              >
                Buy Now
              </Button>
            </div>
          </div>
        </div>
      </section>

      {/* Product Description */}
      <section className="py-16 bg-gradient-midnight relative overflow-hidden">
        <div className="absolute inset-0 bg-[url('/images/southern-gothic-2.jpeg')] bg-cover bg-center opacity-10" />
        <div className="absolute inset-0 bg-gradient-midnight opacity-90" />

        <div className="container relative z-10 px-4">
          <div className="max-w-3xl mx-auto">
            <h2 className="text-2xl md:text-3xl font-serif font-bold text-rich-gold mb-6 text-center">
              Product Details
            </h2>

            <div
              className="prose prose-lg prose-invert max-w-none"
              dangerouslySetInnerHTML={{ __html: product.longDescription }}
            />

            <div className="mt-12">
              <h3 className="text-xl font-serif font-bold text-rich-gold mb-4">What's Included</h3>

              <ul className="space-y-4">
                <li className="flex items-start gap-2">
                  <Check className="h-5 w-5 text-rich-gold shrink-0 mt-0.5" />
                  <p className="text-magnolia-white/90 font-lora">
                    Lorem ipsum dolor sit amet, consectetur adipiscing elit
                  </p>
                </li>
                <li className="flex items-start gap-2">
                  <Check className="h-5 w-5 text-rich-gold shrink-0 mt-0.5" />
                  <p className="text-magnolia-white/90 font-lora">Nullam in dui mauris vivamus hendrerit arcu</p>
                </li>
                <li className="flex items-start gap-2">
                  <Check className="h-5 w-5 text-rich-gold shrink-0 mt-0.5" />
                  <p className="text-magnolia-white/90 font-lora">
                    Sed auctor neque eu tellus rhoncus ut eleifend nibh porttitor
                  </p>
                </li>
                <li className="flex items-start gap-2">
                  <Check className="h-5 w-5 text-rich-gold shrink-0 mt-0.5" />
                  <p className="text-magnolia-white/90 font-lora">
                    Ut in nulla enim phasellus molestie magna non est bibendum
                  </p>
                </li>
                <li className="flex items-start gap-2">
                  <Check className="h-5 w-5 text-rich-gold shrink-0 mt-0.5" />
                  <p className="text-magnolia-white/90 font-lora">Suspendisse dictum feugiat nisl ut dapibus</p>
                </li>
              </ul>
            </div>
          </div>
        </div>

        {/* Decorative elements */}
        <FloatingMagnolia size="sm" color="gold" className="top-1/4 right-[15%]" />
        <FloatingMagnolia size="md" color="white" className="bottom-1/4 left-[10%]" delay={1.2} />
      </section>

      {/* Testimonials */}
      <section className="py-16">
        <div className="container px-4">
          <h2 className="text-2xl md:text-3xl font-serif font-bold text-rich-gold mb-8 text-center">
            Customer Experiences
          </h2>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-8 max-w-4xl mx-auto">
            {product.testimonials.map((testimonial, index) => (
              <Card key={index} className="bg-midnight-blue/20 border-rich-gold/20">
                <CardContent className="pt-6">
                  <div className="flex items-center gap-4 mb-4">
                    <div className="w-12 h-12 rounded-full bg-rich-gold/20 flex items-center justify-center">
                      <span className="text-xl text-rich-gold">{testimonial.name.substring(0, 2)}</span>
                    </div>
                    <div>
                      <p className="font-serif font-bold text-rich-gold">{testimonial.name}</p>
                      <p className="text-sm text-foreground/60">{testimonial.role}</p>
                    </div>
                  </div>
                  <p className="text-foreground/80 font-lora italic mb-4">"{testimonial.quote}"</p>
                  <div className="flex gap-1">
                    {[...Array(testimonial.rating)].map((_, i) => (
                      <Star key={i} className="w-5 h-5 text-rich-gold fill-rich-gold" />
                    ))}
                  </div>
                </CardContent>
              </Card>
            ))}
          </div>
        </div>
      </section>

      {/* Related Products */}
      <section className="py-16 bg-gradient-midnight relative overflow-hidden">
        <div className="absolute inset-0 bg-[url('/images/southern-gothic-3.jpeg')] bg-cover bg-center opacity-10" />
        <div className="absolute inset-0 bg-gradient-midnight opacity-90" />

        <div className="container relative z-10 px-4">
          <h2 className="text-2xl md:text-3xl font-serif font-bold text-rich-gold mb-8 text-center">
            You May Also Like
          </h2>

          <div className="grid grid-cols-1 md:grid-cols-3 gap-8 max-w-5xl mx-auto">
            {product.relatedProducts.map((relatedProduct) => (
              <div
                key={relatedProduct.id}
                className="bg-midnight-blue/20 border border-rich-gold/20 rounded-lg overflow-hidden"
              >
                <div className="relative aspect-square overflow-hidden">
                  <Image
                    src={relatedProduct.image || "/placeholder.svg"}
                    alt={relatedProduct.name}
                    fill
                    className="object-cover"
                  />
                </div>
                <div className="p-4">
                  <h3 className="font-serif font-bold text-rich-gold mb-2">{relatedProduct.name}</h3>
                  <p className="text-foreground/80 font-serif mb-4">{relatedProduct.price}</p>
                  <Link href={`/shop/${relatedProduct.id}`}>
                    <Button className="w-full bg-rich-gold hover:bg-rich-gold/90 text-midnight-blue">
                      View Details
                    </Button>
                  </Link>
                </div>
              </div>
            ))}
          </div>
        </div>

        {/* Decorative elements */}
        <FloatingMagnolia size="sm" color="gold" className="top-1/4 right-[15%]" />
        <FloatingMagnolia size="md" color="white" className="bottom-1/4 left-[10%]" delay={1.2} />
      </section>

      <Footer />
    </main>
  )
}

