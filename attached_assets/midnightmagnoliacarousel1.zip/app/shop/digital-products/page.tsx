import { Navigation } from "@/components/navigation"
import { Footer } from "@/components/footer"
import { FloatingMagnolia } from "@/components/floating-magnolia"
import { ProductGallery } from "@/components/products/product-gallery"
import { AccessibilityProvider } from "@/contexts/accessibility-context"

export default function DigitalProductsPage() {
  return (
    <AccessibilityProvider>
      <main className="min-h-screen bg-background">
        <Navigation />

        {/* Hero Section */}
        <section className="relative pt-20 pb-16 overflow-hidden">
          <div className="absolute inset-0 bg-gradient-midnight opacity-95" />

          <div className="container relative z-10 px-4">
            <div className="max-w-4xl mx-auto text-center">
              <h1 className="text-4xl md:text-5xl lg:text-6xl font-serif font-bold text-rich-gold mb-6">
                Digital Sanctuary
              </h1>
              <p className="text-xl text-magnolia-white/90 font-lora italic mb-8">
                Transformative digital products designed for neurodivergent entrepreneurs seeking sustainable success
              </p>
            </div>
          </div>

          {/* Decorative elements */}
          <FloatingMagnolia size="lg" color="gold" className="top-12 right-[10%]" />
          <FloatingMagnolia size="md" color="white" className="bottom-24 left-[15%]" delay={1.5} />
        </section>

        {/* Product Gallery */}
        <ProductGallery />

        <Footer />
      </main>
    </AccessibilityProvider>
  )
}

