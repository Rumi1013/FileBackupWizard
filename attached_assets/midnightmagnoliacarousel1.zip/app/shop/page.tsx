import { Navigation } from "@/components/navigation"
import { Footer } from "@/components/footer"
import { FloatingMagnolia } from "@/components/floating-magnolia"
import Image from "next/image"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardFooter, CardHeader, CardTitle } from "@/components/ui/card"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Check, Star } from "lucide-react"

// Product data based on the provided list
const digitalProducts = [
  {
    id: 1,
    name: "Midnight Entrepreneur Planner",
    description:
      "Digital planner with income tracking, automation checklists, and strategy frameworks designed for neurodivergent entrepreneurs.",
    price: "$49",
    image: "/placeholder.svg?height=400&width=600",
    margin: "85%",
    creationTime: "3-day creation time",
    format: "PDF format with Midnight Magnolia branding and fillable fields",
    category: "digital",
    featured: true,
    badge: "Bestseller",
  },
  {
    id: 2,
    name: "Southern Digital Brand Kit",
    description:
      "Complete brand template system with mood boards, logo placeholders, and color palettes inspired by Southern Gothic aesthetics.",
    price: "$79",
    image: "/placeholder.svg?height=400&width=600",
    margin: "90%",
    creationTime: "5-day creation time",
    format: "Includes Canva templates and Notion database",
    category: "digital",
    featured: true,
    badge: "Popular",
  },
  {
    id: 3,
    name: "Magnolia AI Prompt Collection",
    description:
      "100+ curated prompts for business automation, content creation, and digital product development to enhance your creative workflow.",
    price: "$37",
    image: "/placeholder.svg?height=400&width=600",
    margin: "95%",
    creationTime: "2-day creation time",
    format: "Searchable PDF organized by business function",
    category: "digital",
    featured: false,
    badge: "New",
  },
  {
    id: 4,
    name: "Midnight Magnolia Journal",
    description:
      "Hardcover journal with Southern Gothic aesthetic, cream pages, and gold accents to capture your entrepreneurial journey.",
    price: "$32",
    image: "/placeholder.svg?height=400&width=600",
    margin: "45%",
    creationTime: "Print-on-demand",
    format: "Premium positioning with inspirational quotes and planning pages",
    category: "print",
    featured: true,
    badge: "Bestseller",
  },
  {
    id: 5,
    name: "Resilience Art Prints",
    description:
      "Southern-inspired silhouette art on premium paper, perfect for adding a touch of Southern Gothic elegance to your space.",
    price: "$24-45",
    image: "/placeholder.svg?height=400&width=600",
    margin: "60%",
    creationTime: "Print-on-demand",
    format: "Available in multiple sizes with gold foil accents",
    category: "print",
    featured: false,
    badge: null,
  },
  {
    id: 6,
    name: "Midnight Strategy Vault",
    description:
      "Digital business template bundle with Notion, Airtable, and spreadsheet systems designed for neurodivergent entrepreneurs.",
    price: "$97",
    image: "/placeholder.svg?height=400&width=600",
    margin: "92%",
    creationTime: "7-day creation time",
    format: "Automation focus with implementation guides",
    category: "bundle",
    featured: true,
    badge: "Best Value",
  },
  {
    id: 7,
    name: "Southern Digital Newsletter",
    description:
      "Premium email content on digital entrepreneurship with Southern Gothic aesthetic delivered monthly to your inbox.",
    price: "$9/month",
    image: "/placeholder.svg?height=400&width=600",
    margin: "98%",
    creationTime: "Ongoing content creation",
    format: "Includes monthly digital asset downloads",
    category: "subscription",
    featured: false,
    badge: "Subscription",
  },
  {
    id: 8,
    name: "Magnolia Mentorship Templates",
    description:
      "Client onboarding system with service templates and automation workflows to elevate your client experience.",
    price: "$67",
    image: "/placeholder.svg?height=400&width=600",
    margin: "88%",
    creationTime: "4-day creation time",
    format: "Complete client experience framework",
    category: "bundle",
    featured: false,
    badge: null,
  },
]

export default function ShopPage() {
  return (
    <main className="min-h-screen bg-background">
      <Navigation />

      {/* Hero Section */}
      <section className="relative pt-20 pb-16 overflow-hidden">
        <div className="absolute inset-0 bg-gradient-midnight opacity-95" />

        <div className="container relative z-10 px-4">
          <div className="max-w-4xl mx-auto text-center">
            <h1 className="text-4xl md:text-5xl lg:text-6xl font-serif font-bold text-rich-gold mb-6">
              Digital Sanctuary
            </h1>
            <p className="text-xl text-magnolia-white/90 font-lora italic mb-8">
              Transformative digital products designed for neurodivergent entrepreneurs seeking sustainable success
            </p>
          </div>
        </div>

        {/* Decorative elements */}
        <FloatingMagnolia size="lg" color="gold" className="top-12 right-[10%]" />
        <FloatingMagnolia size="md" color="white" className="bottom-24 left-[15%]" delay={1.5} />
      </section>

      {/* Featured Products */}
      <section className="py-16 md:py-24 relative overflow-hidden">
        <div className="container px-4">
          <div className="text-center mb-16">
            <h2 className="text-3xl md:text-4xl font-serif font-bold text-rich-gold mb-4">Featured Offerings</h2>
            <p className="text-lg text-foreground/80 max-w-2xl mx-auto font-lora">
              Our most beloved digital products, each crafted with attention to detail and designed to enhance your
              entrepreneurial journey.
            </p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
            {digitalProducts
              .filter((product) => product.featured)
              .map((product) => (
                <ProductCard key={product.id} product={product} featured={true} />
              ))}
          </div>
        </div>
      </section>

      {/* All Products */}
      <section className="py-16 md:py-24 bg-gradient-midnight relative overflow-hidden">
        <div className="absolute inset-0 bg-[url('/images/southern-gothic-2.jpeg')] bg-cover bg-center opacity-10" />
        <div className="absolute inset-0 bg-gradient-midnight opacity-90" />

        <div className="container relative z-10 px-4">
          <div className="text-center mb-16">
            <h2 className="text-3xl md:text-4xl font-serif font-bold text-rich-gold mb-4">Digital Collection</h2>
            <p className="text-lg text-magnolia-white/80 max-w-2xl mx-auto font-lora">
              Browse our complete collection of digital products designed to support your entrepreneurial journey.
            </p>
          </div>

          <Tabs defaultValue="all" className="w-full">
            <div className="flex justify-center mb-8">
              <TabsList className="bg-midnight-blue/30">
                <TabsTrigger
                  value="all"
                  className="data-[state=active]:bg-rich-gold/20 data-[state=active]:text-rich-gold"
                >
                  All Products
                </TabsTrigger>
                <TabsTrigger
                  value="digital"
                  className="data-[state=active]:bg-rich-gold/20 data-[state=active]:text-rich-gold"
                >
                  Digital Products
                </TabsTrigger>
                <TabsTrigger
                  value="print"
                  className="data-[state=active]:bg-rich-gold/20 data-[state=active]:text-rich-gold"
                >
                  Print-on-Demand
                </TabsTrigger>
                <TabsTrigger
                  value="bundle"
                  className="data-[state=active]:bg-rich-gold/20 data-[state=active]:text-rich-gold"
                >
                  Bundles
                </TabsTrigger>
              </TabsList>
            </div>

            <TabsContent value="all" className="mt-0">
              <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
                {digitalProducts.map((product) => (
                  <ProductCard key={product.id} product={product} />
                ))}
              </div>
            </TabsContent>

            <TabsContent value="digital" className="mt-0">
              <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
                {digitalProducts
                  .filter((product) => product.category === "digital")
                  .map((product) => (
                    <ProductCard key={product.id} product={product} />
                  ))}
              </div>
            </TabsContent>

            <TabsContent value="print" className="mt-0">
              <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
                {digitalProducts
                  .filter((product) => product.category === "print")
                  .map((product) => (
                    <ProductCard key={product.id} product={product} />
                  ))}
              </div>
            </TabsContent>

            <TabsContent value="bundle" className="mt-0">
              <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
                {digitalProducts
                  .filter((product) => product.category === "bundle" || product.category === "subscription")
                  .map((product) => (
                    <ProductCard key={product.id} product={product} />
                  ))}
              </div>
            </TabsContent>
          </Tabs>
        </div>

        {/* Decorative elements */}
        <FloatingMagnolia size="sm" color="gold" className="top-1/4 right-[15%]" />
        <FloatingMagnolia size="md" color="white" className="bottom-1/4 left-[10%]" delay={1.2} />
      </section>

      {/* Benefits Section */}
      <section className="py-16 md:py-24">
        <div className="container px-4">
          <div className="text-center mb-16">
            <h2 className="text-3xl md:text-4xl font-serif font-bold text-rich-gold mb-4">
              Why Choose Our Digital Products
            </h2>
            <p className="text-lg text-foreground/80 max-w-2xl mx-auto font-lora">
              Each product is thoughtfully designed with neurodivergent entrepreneurs in mind, providing structure
              without rigidity and support without overwhelm.
            </p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-3 gap-8 max-w-5xl mx-auto">
            <Card className="bg-midnight-blue/20 border-rich-gold/20 hover:bg-midnight-blue/30 transition-colors">
              <CardHeader>
                <div className="w-12 h-12 rounded-full bg-rich-gold/20 flex items-center justify-center mb-4">
                  <span className="text-2xl text-rich-gold">✦</span>
                </div>
                <CardTitle className="text-rich-gold">Neurodivergent-Friendly Design</CardTitle>
              </CardHeader>
              <CardContent>
                <p className="text-foreground/80 font-lora">
                  Our products are designed with ADHD and neurodivergent brains in mind, featuring clear organization,
                  visual cues, and flexible implementation options.
                </p>
              </CardContent>
            </Card>

            <Card className="bg-midnight-blue/20 border-rich-gold/20 hover:bg-midnight-blue/30 transition-colors">
              <CardHeader>
                <div className="w-12 h-12 rounded-full bg-rich-gold/20 flex items-center justify-center mb-4">
                  <span className="text-2xl text-rich-gold">✧</span>
                </div>
                <CardTitle className="text-rich-gold">Southern Gothic Aesthetic</CardTitle>
              </CardHeader>
              <CardContent>
                <p className="text-foreground/80 font-lora">
                  Experience the unique blend of Southern elegance and digital innovation that defines the Midnight
                  Magnolia brand, making productivity beautiful.
                </p>
              </CardContent>
            </Card>

            <Card className="bg-midnight-blue/20 border-rich-gold/20 hover:bg-midnight-blue/30 transition-colors">
              <CardHeader>
                <div className="w-12 h-12 rounded-full bg-rich-gold/20 flex items-center justify-center mb-4">
                  <span className="text-2xl text-rich-gold">✦</span>
                </div>
                <CardTitle className="text-rich-gold">Sustainable Success Focus</CardTitle>
              </CardHeader>
              <CardContent>
                <p className="text-foreground/80 font-lora">
                  Our products prioritize sustainable business practices, helping you create systems that support
                  long-term success without burnout.
                </p>
              </CardContent>
            </Card>
          </div>
        </div>
      </section>

      {/* Testimonials */}
      <section className="py-16 md:py-24 bg-gradient-midnight relative overflow-hidden">
        <div className="absolute inset-0 bg-[url('/images/southern-gothic-3.jpeg')] bg-cover bg-center opacity-10" />
        <div className="absolute inset-0 bg-gradient-midnight opacity-90" />

        <div className="container relative z-10 px-4">
          <div className="text-center mb-16">
            <h2 className="text-3xl md:text-4xl font-serif font-bold text-rich-gold mb-4">Voices of Transformation</h2>
            <p className="text-lg text-magnolia-white/80 max-w-2xl mx-auto font-lora">
              Hear from entrepreneurs who have experienced the impact of our digital products.
            </p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-8 max-w-4xl mx-auto">
            <Card className="bg-midnight-blue/30 border-rich-gold/20 backdrop-blur-sm">
              <CardContent className="p-6">
                <div className="flex gap-1 mb-4">
                  {[...Array(5)].map((_, i) => (
                    <Star key={i} className="h-5 w-5 text-rich-gold fill-rich-gold" />
                  ))}
                </div>
                <p className="text-magnolia-white/90 font-lora italic mb-6">
                  "The Midnight Entrepreneur Planner transformed how I approach my business. As someone with ADHD, I've
                  struggled with traditional planners, but this one seems to understand how my brain works. The income
                  tracking and automation checklists have helped me increase my revenue by 30% in just two months."
                </p>
                <div className="flex items-center gap-4">
                  <div className="w-10 h-10 rounded-full bg-rich-gold/20 flex items-center justify-center">
                    <span className="text-sm text-rich-gold">JM</span>
                  </div>
                  <div>
                    <p className="font-serif font-bold text-rich-gold">Jasmine Morgan</p>
                    <p className="text-sm text-magnolia-white/70">Digital Creator</p>
                  </div>
                </div>
              </CardContent>
            </Card>

            <Card className="bg-midnight-blue/30 border-rich-gold/20 backdrop-blur-sm">
              <CardContent className="p-6">
                <div className="flex gap-1 mb-4">
                  {[...Array(5)].map((_, i) => (
                    <Star key={i} className="h-5 w-5 text-rich-gold fill-rich-gold" />
                  ))}
                </div>
                <p className="text-magnolia-white/90 font-lora italic mb-6">
                  "The Midnight Strategy Vault is worth every penny. The Notion templates alone saved me weeks of setup
                  time, and the automation workflows have reduced my administrative tasks by 70%. As a neurodivergent
                  entrepreneur, having these systems in place has been life-changing for my business."
                </p>
                <div className="flex items-center gap-4">
                  <div className="w-10 h-10 rounded-full bg-rich-gold/20 flex items-center justify-center">
                    <span className="text-sm text-rich-gold">AT</span>
                  </div>
                  <div>
                    <p className="font-serif font-bold text-rich-gold">Alexander Thomas</p>
                    <p className="text-sm text-magnolia-white/70">Marketing Consultant</p>
                  </div>
                </div>
              </CardContent>
            </Card>
          </div>
        </div>

        {/* Decorative elements */}
        <FloatingMagnolia size="sm" color="gold" className="top-1/4 right-[15%]" />
        <FloatingMagnolia size="md" color="white" className="bottom-1/4 left-[10%]" delay={1.2} />
      </section>

      {/* FAQ Section */}
      <section className="py-16 md:py-24">
        <div className="container px-4">
          <div className="text-center mb-16">
            <h2 className="text-3xl md:text-4xl font-serif font-bold text-rich-gold mb-4">
              Frequently Asked Questions
            </h2>
            <p className="text-lg text-foreground/80 max-w-2xl mx-auto font-lora">
              Find answers to common questions about our digital products.
            </p>
          </div>

          <div className="max-w-3xl mx-auto grid gap-6">
            <Card className="bg-midnight-blue/20 border-rich-gold/20">
              <CardContent className="p-6">
                <h3 className="font-serif font-bold text-rich-gold mb-2">
                  How do I access my digital products after purchase?
                </h3>
                <p className="text-foreground/80 font-lora">
                  After completing your purchase, you'll receive an email with download links and access instructions.
                  All digital products are also available in your account dashboard for future downloads. If you need
                  assistance, our support team is available to help.
                </p>
              </CardContent>
            </Card>

            <Card className="bg-midnight-blue/20 border-rich-gold/20">
              <CardContent className="p-6">
                <h3 className="font-serif font-bold text-rich-gold mb-2">
                  Are your digital products designed for specific industries?
                </h3>
                <p className="text-foreground/80 font-lora">
                  Our digital products are designed to be versatile and adaptable across various industries. While
                  they're particularly well-suited for creative entrepreneurs, coaches, consultants, and digital product
                  creators, the frameworks and templates can be customized for your specific business needs.
                </p>
              </CardContent>
            </Card>

            <Card className="bg-midnight-blue/20 border-rich-gold/20">
              <CardContent className="p-6">
                <h3 className="font-serif font-bold text-rich-gold mb-2">Do you offer refunds on digital products?</h3>
                <p className="text-foreground/80 font-lora">
                  Due to the digital nature of our products, we do not offer refunds once the product has been
                  downloaded. However, we stand behind the quality of our offerings and are happy to provide support if
                  you're experiencing any issues with implementation or access.
                </p>
              </CardContent>
            </Card>

            <Card className="bg-midnight-blue/20 border-rich-gold/20">
              <CardContent className="p-6">
                <h3 className="font-serif font-bold text-rich-gold mb-2">
                  How often are your digital products updated?
                </h3>
                <p className="text-foreground/80 font-lora">
                  We regularly update our digital products to ensure they remain current with best practices and
                  technology changes. When you purchase a product, you'll receive all future updates to that product at
                  no additional cost. Subscription products like the Southern Digital Newsletter are updated monthly
                  with fresh content.
                </p>
              </CardContent>
            </Card>
          </div>
        </div>
      </section>

      {/* CTA */}
      <section className="py-16 bg-gradient-midnight relative overflow-hidden">
        <div className="absolute inset-0 bg-[url('/images/southern-gothic-1.jpeg')] bg-cover bg-center opacity-10" />
        <div className="absolute inset-0 bg-gradient-midnight opacity-90" />

        <div className="container relative z-10 px-4 text-center">
          <h2 className="text-3xl md:text-4xl font-serif font-bold text-rich-gold mb-6">
            Ready to Transform Your Business?
          </h2>
          <p className="text-xl text-magnolia-white/90 font-lora max-w-2xl mx-auto mb-8">
            Explore our collection of digital products designed to support your entrepreneurial journey with systems
            that honor your neurodivergent mind.
          </p>
          <Button size="lg" className="bg-rich-gold hover:bg-rich-gold/90 text-midnight-blue font-medium">
            Shop All Products
          </Button>
        </div>
      </section>

      <Footer />
    </main>
  )
}

// Product Card Component
function ProductCard({ product, featured = false }: { product: any; featured?: boolean }) {
  return (
    <Card
      className={`bg-midnight-blue/20 border-rich-gold/20 overflow-hidden h-full flex flex-col ${featured ? "transform hover:-translate-y-2 transition-transform duration-300" : ""}`}
    >
      <div className="relative">
        <div className="relative aspect-[4/3] overflow-hidden">
          <Image
            src={product.image || "/placeholder.svg"}
            alt={product.name}
            fill
            className="object-cover transition-transform duration-500 hover:scale-105"
          />

          {product.badge && (
            <div className="absolute top-2 right-2 bg-rich-gold text-midnight-blue text-xs font-bold px-2 py-1 rounded-full">
              {product.badge}
            </div>
          )}
        </div>
      </div>

      <CardHeader className="p-4 pb-2">
        <CardTitle className="text-rich-gold text-xl">{product.name}</CardTitle>
      </CardHeader>

      <CardContent className="p-4 pt-0 flex-grow">
        <p className="text-foreground/80 font-lora text-sm mb-4">{product.description}</p>

        <div className="space-y-2 text-xs text-foreground/60">
          <p className="flex items-center gap-1">
            <Check className="h-3 w-3 text-rich-gold" />
            <span>{product.format}</span>
          </p>
          <p className="flex items-center gap-1">
            <Check className="h-3 w-3 text-rich-gold" />
            <span>{product.creationTime}</span>
          </p>
        </div>
      </CardContent>

      <CardFooter className="p-4 pt-0 flex justify-between items-center">
        <p className="font-serif font-bold text-rich-gold text-xl">{product.price}</p>
        <Button className="bg-rich-gold hover:bg-rich-gold/90 text-midnight-blue">Add to Cart</Button>
      </CardFooter>
    </Card>
  )
}

