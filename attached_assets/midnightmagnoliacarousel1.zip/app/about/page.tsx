import { Navigation } from "@/components/navigation"
import { Footer } from "@/components/footer"
import { FloatingMagnolia } from "@/components/floating-magnolia"
import Image from "next/image"
import { Button } from "@/components/ui/button"

export default function AboutPage() {
  return (
    <main className="min-h-screen bg-background">
      <Navigation />

      {/* Hero Section */}
      <section className="relative pt-20 pb-16 overflow-hidden">
        <div className="absolute inset-0 bg-gradient-midnight opacity-95" />

        <div className="container relative z-10 px-4">
          <div className="max-w-4xl mx-auto text-center">
            <h1 className="text-4xl md:text-5xl lg:text-6xl font-serif font-bold text-rich-gold mb-6">
              The Story Behind Midnight Magnolia
            </h1>
            <p className="text-xl text-magnolia-white/90 font-lora italic mb-8">
              A journey of transformation, resilience, and reclamation that birthed not just a business, but a movement
              for financial autonomy and creative freedom.
            </p>
          </div>
        </div>

        {/* Decorative elements */}
        <FloatingMagnolia size="lg" color="gold" className="top-12 right-[10%]" />
        <FloatingMagnolia size="md" color="white" className="bottom-24 left-[15%]" delay={1.5} />
      </section>

      {/* Founder Story */}
      <section className="py-16 md:py-24 relative overflow-hidden">
        <div className="container px-4">
          <div className="grid grid-cols-1 md:grid-cols-2 gap-12 items-center">
            <div className="relative">
              <div className="relative aspect-[3/4] overflow-hidden rounded-lg">
                <div className="absolute inset-0 bg-gradient-to-t from-midnight-blue/80 via-transparent to-transparent z-10" />
                <Image
                  src="/images/southern-gothic-3.jpeg"
                  alt="Latisha Vincent-Waters, founder of Midnight Magnolia"
                  fill
                  className="object-cover"
                />
              </div>
              <div className="absolute -bottom-6 -right-6 w-32 h-32 rounded-full bg-rich-gold/10 animate-glow" />
              <div className="absolute -top-6 -left-6 w-24 h-24 rounded-full bg-rich-gold/10 animate-glow" />
            </div>

            <div>
              <h2 className="text-3xl font-serif font-bold text-rich-gold mb-6">Origins in Transformation</h2>

              <div className="prose prose-lg prose-invert max-w-none">
                <p className="text-magnolia-white/90 font-lora mb-4">
                  Midnight Magnolia was born from the ashes of burnout, the trauma of activism, and the journey of
                  self-discovery that follows when you finally choose yourself. As its founder, my path to creating this
                  brand was neither straightforward nor gentle—but it was necessary.
                </p>

                <p className="text-magnolia-white/90 font-lora mb-4">
                  For years, I poured myself into the movement for Black liberation. I showed up in the streets, in the
                  meetings, in the unspoken spaces where freedom was born. I helped free countless individuals, reunite
                  families, and challenge systems of oppression. This work was sacred, and I remain deeply, soulfully
                  grateful to have been part of it.
                </p>

                <div className="my-8 p-6 border-l-4 border-rich-gold bg-midnight-blue/30 rounded-r-lg">
                  <p className="text-xl text-rich-gold font-serif italic">
                    "From the ashes of burnout, the trauma of activism, and the misdiagnosis of my being—I birthed
                    Midnight Magnolia. Not just a business. A sanctuary. A soft rebellion."
                  </p>
                </div>

                <p className="text-magnolia-white/90 font-lora mb-4">
                  But inside the movement, I found more harm. I experienced exploitation while preaching liberation. I
                  gave everything I had—my time, my mind, my heart—and still, I was used, plotted against, worn down. My
                  literal job was to free Black people. But I had to ask myself: who was freeing me?
                </p>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* The Power of Diagnosis */}
      <section className="py-16 md:py-24 bg-gradient-midnight relative overflow-hidden">
        <div className="absolute inset-0 bg-[url('/images/southern-gothic-2.jpeg')] bg-cover bg-center opacity-10" />
        <div className="absolute inset-0 bg-gradient-midnight opacity-90" />

        <div className="container relative z-10 px-4">
          <div className="max-w-3xl mx-auto">
            <h2 className="text-3xl font-serif font-bold text-rich-gold mb-6 text-center">The Power of Diagnosis</h2>

            <div className="prose prose-lg prose-invert max-w-none">
              <p className="text-magnolia-white/90 font-lora mb-4">
                At 42 years old, I received a diagnosis that changed everything: ADHD. Suddenly, the pieces of my life
                that never quite fit together began to make sense. The overwhelm, the burnout cycles, the intense
                hyperfocus followed by complete exhaustion—these weren't character flaws or signs of weakness. They were
                neurological realities I'd been fighting against my entire life.
              </p>

              <p className="text-magnolia-white/90 font-lora mb-4">
                This diagnosis became both liberation and launchpad. I wasn't broken. I was wired differently in a world
                that never learned to listen. With this understanding, I began to create systems and approaches that
                worked with my brain instead of against it.
              </p>

              <p className="text-magnolia-white/90 font-lora mb-4">
                And I realized I wasn't alone. So many other creative entrepreneurs—particularly Black women—were
                struggling with similar challenges, often undiagnosed and unsupported. The intersection of
                neurodivergence, racial identity, and entrepreneurship became the foundation for Midnight Magnolia's
                approach.
              </p>
            </div>
          </div>
        </div>

        {/* Decorative elements */}
        <FloatingMagnolia size="sm" color="gold" className="top-1/4 right-[15%]" />
        <FloatingMagnolia size="md" color="white" className="bottom-1/4 left-[10%]" delay={1.2} />
      </section>

      {/* Mission & Values */}
      <section className="py-16 md:py-24">
        <div className="container px-4">
          <div className="text-center mb-16">
            <h2 className="text-3xl md:text-4xl font-serif font-bold text-rich-gold mb-4">Our Mission & Values</h2>
            <p className="text-lg text-foreground/80 max-w-2xl mx-auto font-lora">
              Midnight Magnolia exists at the intersection of neurodivergent entrepreneurship, digital innovation, and
              Southern resilience.
            </p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
            <div className="bg-midnight-blue/20 border border-rich-gold/20 rounded-lg p-6 hover:bg-midnight-blue/30 transition-colors">
              <div className="w-12 h-12 rounded-full bg-rich-gold/20 flex items-center justify-center mb-4">
                <span className="text-2xl text-rich-gold">✦</span>
              </div>
              <h3 className="text-xl font-serif font-bold text-rich-gold mb-2">Authentic Expression</h3>
              <p className="text-foreground/80 font-lora">
                We believe in the power of showing up as your full, unmasked self. Our approach honors neurodivergent
                thinking as a creative advantage, not a limitation.
              </p>
            </div>

            <div className="bg-midnight-blue/20 border border-rich-gold/20 rounded-lg p-6 hover:bg-midnight-blue/30 transition-colors">
              <div className="w-12 h-12 rounded-full bg-rich-gold/20 flex items-center justify-center mb-4">
                <span className="text-2xl text-rich-gold">✧</span>
              </div>
              <h3 className="text-xl font-serif font-bold text-rich-gold mb-2">Sustainable Success</h3>
              <p className="text-foreground/80 font-lora">
                We reject hustle culture and burnout cycles. Our frameworks are designed for long-term sustainability,
                honoring rest as essential to creativity.
              </p>
            </div>

            <div className="bg-midnight-blue/20 border border-rich-gold/20 rounded-lg p-6 hover:bg-midnight-blue/30 transition-colors">
              <div className="w-12 h-12 rounded-full bg-rich-gold/20 flex items-center justify-center mb-4">
                <span className="text-2xl text-rich-gold">✦</span>
              </div>
              <h3 className="text-xl font-serif font-bold text-rich-gold mb-2">Digital Liberation</h3>
              <p className="text-foreground/80 font-lora">
                We empower creators to build digital assets that generate wealth and freedom, particularly for
                communities historically excluded from traditional paths to financial independence.
              </p>
            </div>
          </div>
        </div>
      </section>

      {/* CTA */}
      <section className="py-16 bg-gradient-midnight relative overflow-hidden">
        <div className="absolute inset-0 bg-[url('/images/southern-gothic-1.jpeg')] bg-cover bg-center opacity-10" />
        <div className="absolute inset-0 bg-gradient-midnight opacity-90" />

        <div className="container relative z-10 px-4 text-center">
          <h2 className="text-3xl md:text-4xl font-serif font-bold text-rich-gold mb-6">Join Our Journey</h2>
          <p className="text-xl text-magnolia-white/90 font-lora max-w-2xl mx-auto mb-8">
            Whether you're seeking transformation in your business or looking to create digital products that honor your
            unique gifts, Midnight Magnolia offers a path forward rooted in authenticity and resilience.
          </p>
          <Button size="lg" className="bg-rich-gold hover:bg-rich-gold/90 text-midnight-blue font-medium">
            Explore Our Services
          </Button>
        </div>
      </section>

      <Footer />
    </main>
  )
}

