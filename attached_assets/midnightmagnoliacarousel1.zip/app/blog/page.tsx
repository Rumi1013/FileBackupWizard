import { Navigation } from "@/components/navigation"
import { Footer } from "@/components/footer"
import { FloatingMagnolia } from "@/components/floating-magnolia"
import Image from "next/image"
import Link from "next/link"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardFooter, CardHeader, CardTitle } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"

const blogPosts = [
  {
    id: 1,
    title: "The Neurodivergent Entrepreneur's Guide to Sustainable Success",
    excerpt:
      "Discover how to build business systems that work with your brain instead of against it. This guide offers practical strategies for ADHD and autistic entrepreneurs seeking sustainable growth.",
    date: "May 15, 2023",
    category: "Business Strategy",
    image: "/images/southern-gothic-1.jpeg",
    slug: "neurodivergent-entrepreneurs-guide",
    featured: true,
  },
  {
    id: 2,
    title: "From Burnout to Brilliance: Reclaiming Your Creative Power",
    excerpt:
      "My personal journey from activism burnout to building a business that honors my whole self. Learn the warning signs of burnout and the steps I took to reclaim my creative energy.",
    date: "April 3, 2023",
    category: "Personal Growth",
    image: "/images/southern-gothic-2.jpeg",
    slug: "burnout-to-brilliance",
  },
  {
    id: 3,
    title: "Digital Products for Passive Income: A Neurodivergent Approach",
    excerpt:
      "Creating digital products doesn't have to follow the neurotypical formula. Discover how to leverage your unique thinking patterns to create products that sell while you sleep.",
    date: "March 12, 2023",
    category: "Digital Products",
    image: "/images/southern-gothic-3.jpeg",
    slug: "digital-products-passive-income",
  },
  {
    id: 4,
    title: "The Power of Diagnosis: How ADHD Changed My Business",
    excerpt:
      "Being diagnosed with ADHD at 42 transformed not just my personal life, but my entire approach to business. Here's how understanding your neurodivergence can become your superpower.",
    date: "February 28, 2023",
    category: "Neurodiversity",
    image: "/placeholder.svg?height=400&width=600",
    slug: "power-of-diagnosis-adhd",
  },
  {
    id: 5,
    title: "Southern Gothic Aesthetics: Embracing Darkness in Your Brand",
    excerpt:
      "How the Southern Gothic tradition influences Midnight Magnolia's visual identity, and how you can incorporate these elements into your own brand for depth and distinction.",
    date: "January 15, 2023",
    category: "Branding",
    image: "/placeholder.svg?height=400&width=600",
    slug: "southern-gothic-aesthetics",
  },
  {
    id: 6,
    title: "Rest as Resistance: Building a Business That Honors Your Health",
    excerpt:
      "In a world that glorifies hustle culture, choosing rest becomes a radical act. Learn how to build a profitable business that prioritizes your wellbeing and sustainability.",
    date: "December 10, 2022",
    category: "Wellness",
    image: "/placeholder.svg?height=400&width=600",
    slug: "rest-as-resistance",
  },
]

export default function BlogPage() {
  return (
    <main className="min-h-screen bg-background">
      <Navigation />

      {/* Hero Section */}
      <section className="relative pt-20 pb-16 overflow-hidden">
        <div className="absolute inset-0 bg-gradient-midnight opacity-95" />

        <div className="container relative z-10 px-4">
          <div className="max-w-4xl mx-auto text-center">
            <h1 className="text-4xl md:text-5xl lg:text-6xl font-serif font-bold text-rich-gold mb-6">
              Midnight Musings
            </h1>
            <p className="text-xl text-magnolia-white/90 font-lora italic mb-8">
              Insights on neurodivergent entrepreneurship, digital product creation, and sustainable business practices.
            </p>
          </div>
        </div>

        {/* Decorative elements */}
        <FloatingMagnolia size="lg" color="gold" className="top-12 right-[10%]" />
        <FloatingMagnolia size="md" color="white" className="bottom-24 left-[15%]" delay={1.5} />
      </section>

      {/* Featured Post */}
      {blogPosts
        .filter((post) => post.featured)
        .map((featuredPost) => (
          <section key={featuredPost.id} className="py-12">
            <div className="container px-4">
              <div className="relative overflow-hidden rounded-xl">
                <div className="absolute inset-0 bg-gradient-midnight opacity-90" />
                <div className="absolute inset-0">
                  <Image
                    src={featuredPost.image || "/placeholder.svg"}
                    alt={featuredPost.title}
                    fill
                    className="object-cover opacity-40"
                  />
                </div>

                <div className="relative z-10 p-8 md:p-12 lg:p-16">
                  <div className="max-w-2xl">
                    <div className="inline-block px-3 py-1 mb-4 text-xs font-medium text-midnight-blue bg-rich-gold rounded-full">
                      Featured Post
                    </div>
                    <h2 className="text-3xl md:text-4xl font-serif font-bold text-rich-gold mb-4">
                      {featuredPost.title}
                    </h2>
                    <p className="text-lg text-magnolia-white/90 font-lora mb-6">{featuredPost.excerpt}</p>
                    <div className="flex items-center gap-4 mb-6">
                      <div className="w-10 h-10 rounded-full bg-rich-gold/20 flex items-center justify-center">
                        <span className="text-sm text-rich-gold">LV</span>
                      </div>
                      <div>
                        <p className="font-serif font-bold text-rich-gold">Latisha Vincent-Waters</p>
                        <p className="text-sm text-magnolia-white/70">{featuredPost.date} • 8 min read</p>
                      </div>
                    </div>
                    <Link href={`/blog/${featuredPost.slug}`}>
                      <Button className="bg-rich-gold hover:bg-rich-gold/90 text-midnight-blue">Read Article</Button>
                    </Link>
                  </div>
                </div>
              </div>
            </div>
          </section>
        ))}

      {/* Blog Posts Grid */}
      <section className="py-16">
        <div className="container px-4">
          <div className="flex justify-between items-center mb-8">
            <h2 className="text-2xl md:text-3xl font-serif font-bold text-rich-gold">Latest Articles</h2>

            <div className="flex gap-2">
              <Button variant="outline" className="border-rich-gold/30 text-rich-gold hover:bg-rich-gold/10">
                All
              </Button>
              <Button variant="ghost" className="text-foreground/70 hover:text-rich-gold">
                Business
              </Button>
              <Button variant="ghost" className="text-foreground/70 hover:text-rich-gold">
                Neurodiversity
              </Button>
            </div>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
            {blogPosts.map((post) => (
              <Card
                key={post.id}
                className="bg-midnight-blue/20 border-rich-gold/20 overflow-hidden h-full flex flex-col"
              >
                <div className="relative aspect-[16/9] overflow-hidden">
                  <Image
                    src={post.image || "/placeholder.svg"}
                    alt={post.title}
                    fill
                    className="object-cover transition-transform duration-500 hover:scale-110"
                  />
                </div>
                <CardHeader>
                  <div className="flex items-center justify-between mb-2">
                    <Badge variant="outline" className="bg-rich-gold/10 text-rich-gold border-rich-gold/30">
                      {post.category}
                    </Badge>
                    <div className="text-xs text-foreground/60">{post.date}</div>
                  </div>
                  <CardTitle className="text-rich-gold">{post.title}</CardTitle>
                </CardHeader>
                <CardContent className="flex-grow">
                  <p className="text-foreground/80 font-lora line-clamp-3">{post.excerpt}</p>
                </CardContent>
                <CardFooter>
                  <Link href={`/blog/${post.slug}`} className="text-rich-gold hover:text-rich-gold/80 font-medium">
                    Read More →
                  </Link>
                </CardFooter>
              </Card>
            ))}
          </div>

          <div className="mt-12 text-center">
            <Button variant="outline" className="border-rich-gold text-rich-gold hover:bg-rich-gold/10">
              Load More Articles
            </Button>
          </div>
        </div>
      </section>

      {/* Newsletter */}
      <section className="py-16 bg-gradient-midnight relative overflow-hidden">
        <div className="absolute inset-0 bg-[url('/images/southern-gothic-3.jpeg')] bg-cover bg-center opacity-10" />
        <div className="absolute inset-0 bg-gradient-midnight opacity-90" />

        <div className="container relative z-10 px-4">
          <div className="max-w-2xl mx-auto text-center">
            <h2 className="text-3xl font-serif font-bold text-rich-gold mb-4">Join the Midnight Letter</h2>
            <p className="text-lg text-magnolia-white/90 font-lora mb-8">
              Subscribe to receive monthly insights, exclusive content, and special offers delivered directly to your
              inbox.
            </p>

            <form className="flex flex-col sm:flex-row gap-2 max-w-md mx-auto">
              <input
                type="email"
                placeholder="Your email address"
                className="px-4 py-2 bg-midnight-teal/50 border border-rich-gold/20 rounded-md focus:outline-none focus:ring-2 focus:ring-rich-gold/50 text-magnolia-white flex-1"
                required
              />
              <Button type="submit" className="bg-rich-gold hover:bg-rich-gold/90 text-midnight-blue">
                Subscribe
              </Button>
            </form>

            <p className="mt-4 text-sm text-magnolia-white/60 font-lora">
              We respect your privacy. Unsubscribe at any time.
            </p>
          </div>
        </div>

        {/* Decorative elements */}
        <FloatingMagnolia size="sm" color="gold" className="top-1/4 right-[15%]" />
        <FloatingMagnolia size="md" color="white" className="bottom-1/4 left-[10%]" delay={1.2} />
      </section>

      <Footer />
    </main>
  )
}

