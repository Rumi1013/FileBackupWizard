import { Navigation } from "@/components/navigation"
import { Footer } from "@/components/footer"
import { FloatingMagnolia } from "@/components/floating-magnolia"
import { PortfolioGallery } from "@/components/portfolio/portfolio-gallery"

export default function PortfolioPage() {
  return (
    <main className="min-h-screen bg-background">
      <Navigation />

      {/* Hero Section */}
      <section className="relative pt-20 pb-16 overflow-hidden">
        <div className="absolute inset-0 bg-gradient-midnight opacity-95" />

        <div className="container relative z-10 px-4">
          <div className="max-w-4xl mx-auto text-center">
            <h1 className="text-4xl md:text-5xl lg:text-6xl font-serif font-bold text-rich-gold mb-6">Our Portfolio</h1>
            <p className="text-xl text-magnolia-white/90 font-lora italic mb-8">
              Explore our collection of projects showcasing Southern Gothic elegance paired with digital innovation.
            </p>
          </div>
        </div>

        {/* Decorative elements */}
        <FloatingMagnolia size="lg" color="gold" className="top-12 right-[10%]" />
        <FloatingMagnolia size="md" color="white" className="bottom-24 left-[15%]" delay={1.5} />
      </section>

      {/* Portfolio Gallery */}
      <PortfolioGallery />

      <Footer />
    </main>
  )
}

