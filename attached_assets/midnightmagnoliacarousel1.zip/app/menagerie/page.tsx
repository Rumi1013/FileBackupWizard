import { Navigation } from "@/components/navigation"
import { Footer } from "@/components/footer"
import { FloatingMagnolia } from "@/components/floating-magnolia"
import Image from "next/image"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardFooter, CardHeader, CardTitle } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"

// Product data based on the concept document
const featuredProducts = [
  {
    id: 1,
    name: "Moonlit Dreams Pet Bed",
    description: "Plush circular bed with midnight blue exterior and gold-accented magnolia pattern interior",
    price: "$65-95",
    image: "/placeholder.svg?height=300&width=300",
    bestseller: true,
    category: "beds",
    petTypes: ["cats", "dogs"],
    theme: "Moonlit Silhouettes",
  },
  {
    id: 2,
    name: "Southern Charm Bandana Collection",
    description: "Set of three reversible bandanas featuring magnolia patterns, constellations, and silhouette designs",
    price: "$28",
    image: "/placeholder.svg?height=300&width=300",
    bestseller: true,
    category: "accessories",
    petTypes: ["cats", "dogs", "small_pets"],
    theme: "Magnolia Gardens",
  },
  {
    id: 3,
    name: "Midnight Manor Custom Pet Portrait",
    description:
      "Personalized digital art of your pet in silhouette against a Southern mansion backdrop with moonlit sky",
    price: "$75-125",
    image: "/placeholder.svg?height=300&width=300",
    bestseller: false,
    category: "portraits",
    petTypes: ["cats", "dogs", "small_pets"],
    theme: "Southern Gothic",
  },
  {
    id: 4,
    name: "Gold Crescent Collar & Leash Set",
    description: "Premium midnight blue collar with gold crescent moon hardware and matching leash",
    price: "$45-65",
    image: "/placeholder.svg?height=300&width=300",
    bestseller: true,
    category: "collars",
    petTypes: ["cats", "dogs"],
    theme: "Midnight Zodiac",
  },
  {
    id: 5,
    name: "Magnolia Medallion Food Bowl",
    description: "Ceramic pet bowl with raised design featuring magnolia pattern and gold rim",
    price: "$35",
    image: "/placeholder.svg?height=300&width=300",
    bestseller: false,
    category: "bowls",
    petTypes: ["cats", "dogs", "small_pets"],
    theme: "Magnolia Gardens",
  },
  {
    id: 6,
    name: "Zodiac Pet Tag Collection",
    description: "Custom engraved pet tags featuring your pet's zodiac constellation in gold on midnight blue",
    price: "$18",
    image: "/placeholder.svg?height=300&width=300",
    bestseller: false,
    category: "accessories",
    petTypes: ["cats", "dogs"],
    theme: "Midnight Zodiac",
  },
]

const designThemes = [
  {
    name: "Moonlit Silhouettes",
    description: "Pet silhouettes against midnight blue backgrounds with gold crescent moons",
    image: "/placeholder.svg?height=400&width=600",
  },
  {
    name: "Magnolia Gardens",
    description: "Elegant magnolia patterns with sage green accents on cream backgrounds",
    image: "/placeholder.svg?height=400&width=600",
  },
  {
    name: "Southern Gothic",
    description: "Sophisticated pet accessories featuring Spanish moss and historic imagery",
    image: "/placeholder.svg?height=400&width=600",
  },
  {
    name: "Midnight Zodiac",
    description: "Astrological pet designs with constellation patterns in gold on deep blue",
    image: "/placeholder.svg?height=400&width=600",
  },
]

export default function MenageriePage() {
  return (
    <main className="min-h-screen bg-background">
      <Navigation />

      {/* Hero Section */}
      <section className="relative pt-20 pb-16 overflow-hidden">
        <div className="absolute inset-0 bg-gradient-midnight opacity-95" />

        <div className="container relative z-10 px-4">
          <div className="max-w-4xl mx-auto text-center">
            <h1 className="text-4xl md:text-5xl lg:text-6xl font-serif font-bold text-rich-gold mb-6">
              Midnight Menagerie
            </h1>
            <p className="text-xl text-magnolia-white/90 font-lora italic mb-8">
              Elegant pet accessories with Southern Gothic flair
            </p>
            <Button className="bg-rich-gold hover:bg-rich-gold/90 text-midnight-blue">Shop Collection</Button>
          </div>
        </div>

        {/* Decorative elements */}
        <FloatingMagnolia size="lg" color="gold" className="top-12 right-[10%]" />
        <FloatingMagnolia size="md" color="white" className="bottom-24 left-[15%]" delay={1.5} />
      </section>

      {/* Collection Introduction */}
      <section className="py-16 md:py-24 relative overflow-hidden">
        <div className="container px-4">
          <div className="grid grid-cols-1 md:grid-cols-2 gap-12 items-center">
            <div className="relative">
              <div className="relative aspect-square overflow-hidden rounded-lg">
                <div className="absolute inset-0 bg-gradient-to-t from-midnight-blue/80 via-transparent to-transparent z-10" />
                <Image
                  src="/images/southern-gothic-1.jpeg"
                  alt="Elegant pet accessories with Southern Gothic flair"
                  fill
                  className="object-cover"
                />
              </div>
              <div className="absolute -bottom-6 -right-6 w-32 h-32 rounded-full bg-rich-gold/10 animate-glow" />
              <div className="absolute -top-6 -left-6 w-24 h-24 rounded-full bg-rich-gold/10 animate-glow" />
            </div>

            <div>
              <h2 className="text-3xl font-serif font-bold text-rich-gold mb-6">Elevate Your Pet's Experience</h2>

              <div className="prose prose-lg prose-invert max-w-none">
                <p className="text-magnolia-white/90 font-lora mb-4">
                  Midnight Menagerie brings the elegant Southern Gothic aesthetic of Midnight Magnolia to your beloved
                  pets. Each piece in our collection is thoughtfully designed to complement your home while providing
                  comfort and style for your furry companions.
                </p>

                <p className="text-magnolia-white/90 font-lora mb-4">
                  From plush beds adorned with magnolia patterns to collars featuring crescent moon hardware, our
                  accessories transform everyday pet items into statement pieces that tell a story of Southern elegance
                  and timeless beauty.
                </p>

                <div className="my-8 p-6 border-l-4 border-rich-gold bg-midnight-blue/30 rounded-r-lg">
                  <p className="text-xl text-rich-gold font-serif italic">
                    "I created Midnight Menagerie because our pets deserve the same thoughtful design and quality
                    craftsmanship that we seek for ourselves."
                  </p>
                  <p className="text-magnolia-white/80 mt-2">— Latisha Waters, Designer</p>
                </div>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Design Themes */}
      <section className="py-16 md:py-24 bg-gradient-midnight relative overflow-hidden">
        <div className="absolute inset-0 bg-[url('/images/southern-gothic-2.jpeg')] bg-cover bg-center opacity-10" />
        <div className="absolute inset-0 bg-gradient-midnight opacity-90" />

        <div className="container relative z-10 px-4">
          <div className="text-center mb-16">
            <h2 className="text-3xl md:text-4xl font-serif font-bold text-rich-gold mb-4">Design Themes</h2>
            <p className="text-lg text-magnolia-white/80 max-w-2xl mx-auto font-lora">
              Our collection features four distinct themes, each capturing a different facet of Southern Gothic
              elegance.
            </p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
            {designThemes.map((theme, index) => (
              <Card key={index} className="bg-midnight-blue/30 border-rich-gold/20 backdrop-blur-sm overflow-hidden">
                <div className="relative aspect-[4/3] overflow-hidden">
                  <Image src={theme.image || "/placeholder.svg"} alt={theme.name} fill className="object-cover" />
                  <div className="absolute inset-0 bg-gradient-to-t from-midnight-blue via-midnight-blue/50 to-transparent" />
                  <div className="absolute bottom-0 left-0 right-0 p-4">
                    <h3 className="text-xl font-serif font-bold text-rich-gold">{theme.name}</h3>
                  </div>
                </div>
                <CardContent className="p-4">
                  <p className="text-magnolia-white/90 font-lora text-sm">{theme.description}</p>
                </CardContent>
              </Card>
            ))}
          </div>
        </div>

        {/* Decorative elements */}
        <FloatingMagnolia size="sm" color="gold" className="top-1/4 right-[15%]" />
        <FloatingMagnolia size="md" color="white" className="bottom-1/4 left-[10%]" delay={1.2} />
      </section>

      {/* Featured Products */}
      <section className="py-16 md:py-24">
        <div className="container px-4">
          <div className="text-center mb-16">
            <h2 className="text-3xl md:text-4xl font-serif font-bold text-rich-gold mb-4">Featured Products</h2>
            <p className="text-lg text-foreground/80 max-w-2xl mx-auto font-lora">
              Discover our most beloved pieces, each crafted with attention to detail and Southern-inspired elegance.
            </p>
          </div>

          <Tabs defaultValue="all" className="w-full">
            <div className="flex justify-center mb-8">
              <TabsList className="bg-midnight-blue/30">
                <TabsTrigger
                  value="all"
                  className="data-[state=active]:bg-rich-gold/20 data-[state=active]:text-rich-gold"
                >
                  All Products
                </TabsTrigger>
                <TabsTrigger
                  value="beds"
                  className="data-[state=active]:bg-rich-gold/20 data-[state=active]:text-rich-gold"
                >
                  Beds & Blankets
                </TabsTrigger>
                <TabsTrigger
                  value="accessories"
                  className="data-[state=active]:bg-rich-gold/20 data-[state=active]:text-rich-gold"
                >
                  Accessories
                </TabsTrigger>
                <TabsTrigger
                  value="collars"
                  className="data-[state=active]:bg-rich-gold/20 data-[state=active]:text-rich-gold"
                >
                  Collars & Leashes
                </TabsTrigger>
              </TabsList>
            </div>

            <TabsContent value="all" className="mt-0">
              <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
                {featuredProducts.map((product) => (
                  <ProductCard key={product.id} product={product} />
                ))}
              </div>
            </TabsContent>

            <TabsContent value="beds" className="mt-0">
              <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
                {featuredProducts
                  .filter((product) => product.category === "beds")
                  .map((product) => (
                    <ProductCard key={product.id} product={product} />
                  ))}
              </div>
            </TabsContent>

            <TabsContent value="accessories" className="mt-0">
              <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
                {featuredProducts
                  .filter((product) => product.category === "accessories")
                  .map((product) => (
                    <ProductCard key={product.id} product={product} />
                  ))}
              </div>
            </TabsContent>

            <TabsContent value="collars" className="mt-0">
              <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
                {featuredProducts
                  .filter((product) => product.category === "collars")
                  .map((product) => (
                    <ProductCard key={product.id} product={product} />
                  ))}
              </div>
            </TabsContent>
          </Tabs>

          <div className="text-center mt-12">
            <Button className="bg-rich-gold hover:bg-rich-gold/90 text-midnight-blue">View All Products</Button>
          </div>
        </div>
      </section>

      {/* Custom Pet Portraits */}
      <section className="py-16 md:py-24 bg-gradient-midnight relative overflow-hidden">
        <div className="absolute inset-0 bg-[url('/images/southern-gothic-3.jpeg')] bg-cover bg-center opacity-10" />
        <div className="absolute inset-0 bg-gradient-midnight opacity-90" />

        <div className="container relative z-10 px-4">
          <div className="max-w-4xl mx-auto">
            <div className="grid grid-cols-1 md:grid-cols-2 gap-12 items-center">
              <div>
                <h2 className="text-3xl md:text-4xl font-serif font-bold text-rich-gold mb-6">Custom Pet Portraits</h2>
                <p className="text-lg text-magnolia-white/90 font-lora mb-6">
                  Immortalize your beloved companion with a custom portrait featuring our signature Southern Gothic
                  aesthetic. Each piece is individually created to capture your pet's unique personality against a
                  backdrop of moonlit Southern elegance.
                </p>
                <ul className="space-y-3 mb-8">
                  <li className="flex items-start gap-2 text-magnolia-white/80 font-lora">
                    <span className="text-rich-gold">✦</span>
                    <span>Digital or framed print options available</span>
                  </li>
                  <li className="flex items-start gap-2 text-magnolia-white/80 font-lora">
                    <span className="text-rich-gold">✦</span>
                    <span>Personalized with your pet's name and details</span>
                  </li>
                  <li className="flex items-start gap-2 text-magnolia-white/80 font-lora">
                    <span className="text-rich-gold">✦</span>
                    <span>Choose from multiple Southern Gothic backgrounds</span>
                  </li>
                  <li className="flex items-start gap-2 text-magnolia-white/80 font-lora">
                    <span className="text-rich-gold">✦</span>
                    <span>Perfect as a memorial or celebration of your pet</span>
                  </li>
                </ul>
                <Button className="bg-rich-gold hover:bg-rich-gold/90 text-midnight-blue">Commission a Portrait</Button>
              </div>

              <div className="relative">
                <div className="relative aspect-square overflow-hidden rounded-lg">
                  <Image
                    src="/placeholder.svg?height=400&width=400"
                    alt="Custom pet portrait in Southern Gothic style"
                    fill
                    className="object-cover"
                  />
                </div>
                <div className="absolute -bottom-6 -right-6 w-32 h-32 rounded-full bg-rich-gold/10 animate-glow" />
                <div className="absolute -top-6 -left-6 w-24 h-24 rounded-full bg-rich-gold/10 animate-glow" />
              </div>
            </div>
          </div>
        </div>

        {/* Decorative elements */}
        <FloatingMagnolia size="sm" color="gold" className="top-1/4 right-[15%]" />
        <FloatingMagnolia size="md" color="white" className="bottom-1/4 left-[10%]" delay={1.2} />
      </section>

      {/* Pet of the Month */}
      <section className="py-16 md:py-24">
        <div className="container px-4">
          <div className="text-center mb-16">
            <h2 className="text-3xl md:text-4xl font-serif font-bold text-rich-gold mb-4">Pet of the Month</h2>
            <p className="text-lg text-foreground/80 max-w-2xl mx-auto font-lora">
              Each month we celebrate one of our beloved customers and their Midnight Menagerie style.
            </p>
          </div>

          <div className="max-w-4xl mx-auto">
            <Card className="bg-midnight-blue/20 border-rich-gold/20 overflow-hidden">
              <div className="grid grid-cols-1 md:grid-cols-2">
                <div className="relative aspect-square md:aspect-auto">
                  <Image
                    src="/placeholder.svg?height=400&width=400"
                    alt="Luna, a black cat wearing a Midnight Zodiac collar"
                    fill
                    className="object-cover"
                  />
                </div>

                <CardContent className="p-6 md:p-8 flex flex-col justify-center">
                  <div className="mb-4">
                    <Badge className="bg-rich-gold text-midnight-blue">May 2023</Badge>
                  </div>
                  <h3 className="text-2xl font-serif font-bold text-rich-gold mb-2">Luna</h3>
                  <p className="text-foreground/80 font-lora italic mb-4">
                    A 3-year-old Scottish Fold from Charleston, SC
                  </p>

                  <p className="text-foreground/90 font-lora mb-6">
                    "Luna absolutely adores her Midnight Zodiac collar and matching bed. As a Scorpio cat, she's
                    naturally mysterious and loves to lounge in style. The deep blues complement her silver coat
                    perfectly, and the gold accents catch the light beautifully when she's prowling around at night."
                  </p>

                  <div className="flex items-center gap-4">
                    <div className="w-10 h-10 rounded-full bg-rich-gold/20 flex items-center justify-center">
                      <span className="text-sm text-rich-gold">EJ</span>
                    </div>
                    <div>
                      <p className="font-serif font-bold text-rich-gold">Eleanor James</p>
                      <p className="text-sm text-foreground/60">Luna's Human</p>
                    </div>
                  </div>
                </CardContent>
              </div>
            </Card>

            <div className="text-center mt-8">
              <p className="text-foreground/70 font-lora">
                Want your pet to be featured? Tag us on Instagram with #MidnightMenagerie
              </p>
            </div>
          </div>
        </div>
      </section>

      {/* CTA */}
      <section className="py-16 bg-gradient-midnight relative overflow-hidden">
        <div className="absolute inset-0 bg-[url('/images/southern-gothic-1.jpeg')] bg-cover bg-center opacity-10" />
        <div className="absolute inset-0 bg-gradient-midnight opacity-90" />

        <div className="container relative z-10 px-4 text-center">
          <h2 className="text-3xl md:text-4xl font-serif font-bold text-rich-gold mb-6">Join Our Menagerie</h2>
          <p className="text-xl text-magnolia-white/90 font-lora max-w-2xl mx-auto mb-8">
            Subscribe to receive updates on new collections, limited editions, and exclusive offers for your beloved
            companions.
          </p>

          <div className="flex flex-col sm:flex-row gap-2 max-w-md mx-auto">
            <input
              type="email"
              placeholder="Your email address"
              className="px-4 py-2 bg-midnight-teal/50 border border-rich-gold/20 rounded-md focus:outline-none focus:ring-2 focus:ring-rich-gold/50 text-magnolia-white flex-1"
              required
            />
            <Button className="bg-rich-gold hover:bg-rich-gold/90 text-midnight-blue">Subscribe</Button>
          </div>

          <p className="mt-4 text-sm text-magnolia-white/60 font-lora">
            A portion of all Midnight Menagerie sales is donated to Southern animal shelters.
          </p>
        </div>
      </section>

      <Footer />
    </main>
  )
}

// Product Card Component
function ProductCard({ product }: { product: any }) {
  return (
    <Card className="bg-midnight-blue/20 border-rich-gold/20 overflow-hidden h-full flex flex-col">
      <div className="relative">
        <div className="relative aspect-square overflow-hidden">
          <Image
            src={product.image || "/placeholder.svg"}
            alt={product.name}
            fill
            className="object-cover transition-transform duration-500 group-hover:scale-110"
          />

          {product.bestseller && (
            <div className="absolute top-2 right-2 bg-rich-gold text-midnight-blue text-xs font-bold px-2 py-1 rounded-full">
              Bestseller
            </div>
          )}
        </div>
      </div>

      <CardHeader className="p-4 pb-2">
        <div className="flex gap-2 mb-2">
          {product.petTypes.includes("cats") && (
            <Badge variant="outline" className="border-sage-green/50 text-sage-green text-xs">
              Cats
            </Badge>
          )}
          {product.petTypes.includes("dogs") && (
            <Badge variant="outline" className="border-rich-gold/50 text-rich-gold text-xs">
              Dogs
            </Badge>
          )}
          {product.petTypes.includes("small_pets") && (
            <Badge variant="outline" className="border-magnolia-white/50 text-magnolia-white/90 text-xs">
              Small Pets
            </Badge>
          )}
        </div>
        <CardTitle className="text-rich-gold text-lg">{product.name}</CardTitle>
      </CardHeader>

      <CardContent className="p-4 pt-0 flex-grow">
        <p className="text-foreground/80 font-lora text-sm line-clamp-3">{product.description}</p>
      </CardContent>

      <CardFooter className="p-4 pt-0 flex justify-between items-center">
        <p className="font-serif font-bold text-rich-gold">{product.price}</p>
        <Button variant="outline" size="sm" className="border-rich-gold/50 text-rich-gold hover:bg-rich-gold/10">
          View Details
        </Button>
      </CardFooter>
    </Card>
  )
}

