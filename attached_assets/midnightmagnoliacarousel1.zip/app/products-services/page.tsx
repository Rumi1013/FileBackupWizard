import { Navigation } from "@/components/navigation"
import { Footer } from "@/components/footer"
import { FloatingMagnolia } from "@/components/floating-magnolia"
import Image from "next/image"
import Link from "next/link"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardFooter, CardHeader, CardTitle } from "@/components/ui/card"
import { Check, Star } from "lucide-react"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"

// Featured digital products
const featuredProducts = [
  {
    id: 1,
    name: "Midnight Entrepreneur Planner",
    description:
      "Digital planner with income tracking, automation checklists, and strategy frameworks designed for neurodivergent entrepreneurs.",
    price: "$49",
    image: "/placeholder.svg?height=400&width=600",
    margin: "85%",
    creationTime: "3-day creation time",
    format: "PDF format with Midnight Magnolia branding and fillable fields",
    category: "digital",
    featured: true,
    badge: "Bestseller",
  },
  {
    id: 2,
    name: "Southern Digital Brand Kit",
    description:
      "Complete brand template system with mood boards, logo placeholders, and color palettes inspired by Southern Gothic aesthetics.",
    price: "$79",
    image: "/placeholder.svg?height=400&width=600",
    margin: "90%",
    creationTime: "5-day creation time",
    format: "Includes Canva templates and Notion database",
    category: "digital",
    featured: true,
    badge: "Popular",
  },
  {
    id: 3,
    name: "Magnolia AI Prompt Collection",
    description:
      "100+ curated prompts for business automation, content creation, and digital product development to enhance your creative workflow.",
    price: "$37",
    image: "/placeholder.svg?height=400&width=600",
    margin: "95%",
    creationTime: "2-day creation time",
    format: "Searchable PDF organized by business function",
    category: "digital",
    featured: false,
    badge: "New",
  },
]

// Add a new array for all products categorized by type

const allProducts = [
  // Digital Products
  {
    id: 1,
    name: "Midnight Entrepreneur Planner",
    description:
      "Digital planner with income tracking, automation checklists, and strategy frameworks designed for neurodivergent entrepreneurs.",
    price: "$49",
    image: "/placeholder.svg?height=400&width=600",
    margin: "85%",
    creationTime: "3-day creation time",
    format: "PDF format with Midnight Magnolia branding and fillable fields",
    category: "digital",
    badge: "Bestseller",
  },
  {
    id: 2,
    name: "Southern Digital Brand Kit",
    description:
      "Complete brand template system with mood boards, logo placeholders, and color palettes inspired by Southern Gothic aesthetics.",
    price: "$79",
    image: "/placeholder.svg?height=400&width=600",
    margin: "90%",
    creationTime: "5-day creation time",
    format: "Includes Canva templates and Notion database",
    category: "digital",
    badge: "Popular",
  },
  {
    id: 3,
    name: "Magnolia AI Prompt Collection",
    description:
      "100+ curated prompts for business automation, content creation, and digital product development to enhance your creative workflow.",
    price: "$37",
    image: "/placeholder.svg?height=400&width=600",
    margin: "95%",
    creationTime: "2-day creation time",
    format: "Searchable PDF organized by business function",
    category: "digital",
    badge: "New",
  },
  // Print-on-Demand Products
  {
    id: 4,
    name: "Midnight Magnolia Journal",
    description:
      "Hardcover journal with Southern Gothic aesthetic, cream pages, and gold accents to capture your entrepreneurial journey.",
    price: "$32",
    image: "/placeholder.svg?height=400&width=600",
    margin: "45%",
    creationTime: "Print-on-demand through KDP or Lulu",
    format: "Premium positioning with inspirational quotes and planning pages",
    category: "print",
    badge: "Bestseller",
  },
  {
    id: 5,
    name: "Resilience Art Prints",
    description:
      "Southern-inspired silhouette art on premium paper, perfect for adding a touch of Southern Gothic elegance to your space.",
    price: "$24-45",
    image: "/placeholder.svg?height=400&width=600",
    margin: "60%",
    creationTime: "Print-on-demand through Printful",
    format: "Available in multiple sizes with gold foil accents",
    category: "print",
    badge: null,
  },
  // Subscription/Bundled Content
  {
    id: 6,
    name: "Midnight Strategy Vault",
    description:
      "Digital business template bundle with Notion, Airtable, and spreadsheet systems designed for neurodivergent entrepreneurs.",
    price: "$97",
    image: "/placeholder.svg?height=400&width=600",
    margin: "92%",
    creationTime: "7-day creation time",
    format: "Automation focus with implementation guides",
    category: "bundle",
    badge: "Best Value",
  },
  {
    id: 7,
    name: "Southern Digital Newsletter",
    description:
      "Premium email content on digital entrepreneurship with Southern Gothic aesthetic delivered monthly to your inbox.",
    price: "$9/month",
    image: "/placeholder.svg?height=400&width=600",
    margin: "98%",
    creationTime: "Ongoing content creation",
    format: "Includes monthly digital asset downloads",
    category: "subscription",
    badge: "Subscription",
  },
  {
    id: 8,
    name: "Magnolia Mentorship Templates",
    description:
      "Client onboarding system with service templates and automation workflows to elevate your client experience.",
    price: "$67",
    image: "/placeholder.svg?height=400&width=600",
    margin: "88%",
    creationTime: "4-day creation time",
    format: "Complete client experience framework",
    category: "bundle",
    badge: null,
  },
]

// Featured services
const featuredServices = [
  {
    id: 1,
    name: "Digital Product Mastery",
    description: "Create and launch digital products aligned with your unique gifts and expertise.",
    price: "$1,997",
    image: "/placeholder.svg?height=400&width=600",
    duration: "8-week program",
    badge: "Signature Program",
  },
  {
    id: 2,
    name: "Midnight Magnolia Membership",
    description: "Ongoing support for neurodivergent entrepreneurs building sustainable businesses.",
    price: "$97/month",
    image: "/placeholder.svg?height=400&width=600",
    duration: "Monthly subscription",
    badge: "Most Popular",
  },
  {
    id: 3,
    name: "VIP Strategy Day",
    description: "Intensive 1:1 support to transform your business with personalized strategies.",
    price: "$3,500",
    image: "/placeholder.svg?height=400&width=600",
    duration: "6-hour intensive",
    badge: "Limited Availability",
  },
]

export default function ProductsServicesPage() {
  return (
    <main className="min-h-screen bg-background">
      <Navigation />

      {/* Hero Section */}
      <section className="relative pt-20 pb-16 overflow-hidden">
        <div className="absolute inset-0 bg-gradient-midnight opacity-95" />

        <div className="container relative z-10 px-4">
          <div className="max-w-4xl mx-auto text-center">
            <h1 className="text-4xl md:text-5xl lg:text-6xl font-serif font-bold text-rich-gold mb-6">
              Products & Services
            </h1>
            <p className="text-xl text-magnolia-white/90 font-lora italic mb-8">
              Transformative offerings designed for neurodivergent entrepreneurs seeking sustainable success
            </p>
          </div>
        </div>

        {/* Decorative elements */}
        <FloatingMagnolia size="lg" color="gold" className="top-12 right-[10%]" />
        <FloatingMagnolia size="md" color="white" className="bottom-24 left-[15%]" delay={1.5} />
      </section>

      {/* Overview Section */}
      <section className="py-16 md:py-24 relative overflow-hidden">
        <div className="container px-4">
          <div className="grid grid-cols-1 md:grid-cols-2 gap-12 items-center">
            <div className="relative">
              <div className="relative aspect-square overflow-hidden rounded-lg">
                <div className="absolute inset-0 bg-gradient-to-t from-midnight-blue/80 via-transparent to-transparent z-10" />
                <Image
                  src="/images/southern-gothic-1.jpeg"
                  alt="Midnight Magnolia Products and Services"
                  fill
                  className="object-cover"
                />
              </div>
              <div className="absolute -bottom-6 -right-6 w-32 h-32 rounded-full bg-rich-gold/10 animate-glow" />
              <div className="absolute -top-6 -left-6 w-24 h-24 rounded-full bg-rich-gold/10 animate-glow" />
            </div>

            <div>
              <h2 className="text-3xl font-serif font-bold text-rich-gold mb-6">Our Transformative Offerings</h2>

              <div className="prose prose-lg prose-invert max-w-none">
                <p className="text-magnolia-white/90 font-lora mb-4">
                  At Midnight Magnolia, we offer a carefully curated collection of digital products and personalized
                  services designed specifically for neurodivergent entrepreneurs seeking sustainable success.
                </p>

                <p className="text-magnolia-white/90 font-lora mb-4">
                  Whether you're looking for self-paced digital tools to enhance your business systems or high-touch
                  services to provide personalized guidance, our offerings are designed to work with your unique brain,
                  not against it.
                </p>

                <div className="my-8 p-6 border-l-4 border-rich-gold bg-midnight-blue/30 rounded-r-lg">
                  <p className="text-xl text-rich-gold font-serif italic">
                    "I created these offerings because I needed them myself—tools and support systems that honor
                    neurodivergent thinking as a creative advantage, not a limitation."
                  </p>
                  <p className="text-magnolia-white/80 mt-2">— Latisha Waters, Founder</p>
                </div>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* High-Margin Benefits Section */}
      <section className="py-16 md:py-24 bg-gradient-midnight relative overflow-hidden">
        <div className="absolute inset-0 bg-[url('/images/southern-gothic-3.jpeg')] bg-cover bg-center opacity-10" />
        <div className="absolute inset-0 bg-gradient-midnight opacity-90" />

        <div className="container relative z-10 px-4">
          <div className="text-center mb-16">
            <h2 className="text-3xl md:text-4xl font-serif font-bold text-rich-gold mb-4">
              High-Margin Digital Products
            </h2>
            <p className="text-lg text-magnolia-white/80 max-w-2xl mx-auto font-lora">
              Create sustainable income with our carefully crafted digital products designed for maximum profitability.
            </p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-3 gap-8 max-w-5xl mx-auto">
            <Card className="bg-midnight-blue/30 border-rich-gold/20 backdrop-blur-sm overflow-hidden">
              <CardHeader>
                <div className="w-12 h-12 rounded-full bg-rich-gold/20 flex items-center justify-center mb-4">
                  <span className="text-2xl text-rich-gold">✦</span>
                </div>
                <CardTitle className="text-rich-gold">High Profit Margins</CardTitle>
              </CardHeader>
              <CardContent>
                <p className="text-magnolia-white/90 font-lora">
                  Our digital products offer exceptional profit margins ranging from 85% to 98%, allowing you to
                  maximize your revenue while minimizing costs.
                </p>
              </CardContent>
            </Card>

            <Card className="bg-midnight-blue/30 border-rich-gold/20 backdrop-blur-sm overflow-hidden">
              <CardHeader>
                <div className="w-12 h-12 rounded-full bg-rich-gold/20 flex items-center justify-center mb-4">
                  <span className="text-2xl text-rich-gold">✧</span>
                </div>
                <CardTitle className="text-rich-gold">Quick Creation Time</CardTitle>
              </CardHeader>
              <CardContent>
                <p className="text-magnolia-white/90 font-lora">
                  Most of our digital products can be created in 2-7 days, allowing you to launch quickly and start
                  generating income without lengthy development cycles.
                </p>
              </CardContent>
            </Card>

            <Card className="bg-midnight-blue/30 border-rich-gold/20 backdrop-blur-sm overflow-hidden">
              <CardHeader>
                <div className="w-12 h-12 rounded-full bg-rich-gold/20 flex items-center justify-center mb-4">
                  <span className="text-2xl text-rich-gold">✦</span>
                </div>
                <CardTitle className="text-rich-gold">Scalable Income</CardTitle>
              </CardHeader>
              <CardContent>
                <p className="text-magnolia-white/90 font-lora">
                  Create once, sell infinitely. Our digital products are designed to provide passive income that scales
                  without requiring additional time or resources.
                </p>
              </CardContent>
            </Card>
          </div>

          <div className="mt-12 text-center">
            <p className="text-magnolia-white/90 font-lora italic max-w-2xl mx-auto mb-6">
              Each product incorporates Midnight Magnolia's signature colors, typography, and Southern Gothic Digital
              aesthetic, enabling rapid launch while establishing your brand presence.
            </p>
          </div>
        </div>

        {/* Decorative elements */}
        <FloatingMagnolia size="sm" color="gold" className="top-1/4 right-[15%]" />
        <FloatingMagnolia size="md" color="white" className="bottom-1/4 left-[10%]" delay={1.2} />
      </section>

      {/* All Digital Products */}
      <section className="py-16 md:py-24 bg-gradient-midnight relative overflow-hidden">
        <div className="absolute inset-0 bg-[url('/images/southern-gothic-2.jpeg')] bg-cover bg-center opacity-10" />
        <div className="absolute inset-0 bg-gradient-midnight opacity-90" />

        <div className="container relative z-10 px-4">
          <div className="text-center mb-16">
            <h2 className="text-3xl md:text-4xl font-serif font-bold text-rich-gold mb-4">
              Digital Products Collection
            </h2>
            <p className="text-lg text-magnolia-white/80 max-w-2xl mx-auto font-lora">
              High-margin digital tools designed to enhance your business systems and creative workflow.
            </p>
          </div>

          <Tabs defaultValue="all" className="w-full">
            <div className="flex justify-center mb-8">
              <TabsList className="bg-midnight-blue/30">
                <TabsTrigger
                  value="all"
                  className="data-[state=active]:bg-rich-gold/20 data-[state=active]:text-rich-gold"
                >
                  All Products
                </TabsTrigger>
                <TabsTrigger
                  value="digital"
                  className="data-[state=active]:bg-rich-gold/20 data-[state=active]:text-rich-gold"
                >
                  Digital Products
                </TabsTrigger>
                <TabsTrigger
                  value="print"
                  className="data-[state=active]:bg-rich-gold/20 data-[state=active]:text-rich-gold"
                >
                  Print-on-Demand
                </TabsTrigger>
                <TabsTrigger
                  value="bundle"
                  className="data-[state=active]:bg-rich-gold/20 data-[state=active]:text-rich-gold"
                >
                  Bundles & Subscriptions
                </TabsTrigger>
              </TabsList>
            </div>

            <TabsContent value="all" className="mt-0">
              <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
                {allProducts.map((product) => (
                  <ProductCard key={product.id} product={product} />
                ))}
              </div>
            </TabsContent>

            <TabsContent value="digital" className="mt-0">
              <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
                {allProducts
                  .filter((product) => product.category === "digital")
                  .map((product) => (
                    <ProductCard key={product.id} product={product} />
                  ))}
              </div>
            </TabsContent>

            <TabsContent value="print" className="mt-0">
              <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
                {allProducts
                  .filter((product) => product.category === "print")
                  .map((product) => (
                    <ProductCard key={product.id} product={product} />
                  ))}
              </div>
            </TabsContent>

            <TabsContent value="bundle" className="mt-0">
              <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
                {allProducts
                  .filter((product) => product.category === "bundle" || product.category === "subscription")
                  .map((product) => (
                    <ProductCard key={product.id} product={product} />
                  ))}
              </div>
            </TabsContent>
          </Tabs>

          <div className="text-center mt-12">
            <Link href="/shop">
              <Button size="lg" className="bg-rich-gold hover:bg-rich-gold/90 text-midnight-blue">
                Explore All Digital Products
              </Button>
            </Link>
          </div>
        </div>

        {/* Decorative elements */}
        <FloatingMagnolia size="sm" color="gold" className="top-1/4 right-[15%]" />
        <FloatingMagnolia size="md" color="white" className="bottom-1/4 left-[10%]" delay={1.2} />
      </section>

      {/* Print-on-Demand Section */}
      <section className="py-16 md:py-24 relative overflow-hidden">
        <div className="container px-4">
          <div className="grid grid-cols-1 md:grid-cols-2 gap-12 items-center">
            <div>
              <h2 className="text-3xl font-serif font-bold text-rich-gold mb-6">Print-on-Demand Elegance</h2>

              <div className="prose prose-lg prose-invert max-w-none">
                <p className="text-foreground/80 font-lora mb-4">
                  Extend your digital presence into the physical world with our carefully curated print-on-demand
                  products. Each item embodies the Southern Gothic elegance of Midnight Magnolia while offering
                  attractive profit margins.
                </p>

                <p className="text-foreground/80 font-lora mb-4">
                  From our premium hardcover journals with gold accents to our Southern-inspired silhouette art prints,
                  these products allow you to create tangible touchpoints for your brand without inventory or
                  fulfillment concerns.
                </p>

                <div className="space-y-4 mt-6">
                  <div className="flex items-start gap-2">
                    <Check className="h-5 w-5 text-rich-gold shrink-0 mt-0.5" />
                    <div>
                      <p className="font-serif font-bold text-rich-gold">No inventory management</p>
                      <p className="text-foreground/70 font-lora text-sm">
                        Products are printed and shipped only when ordered
                      </p>
                    </div>
                  </div>

                  <div className="flex items-start gap-2">
                    <Check className="h-5 w-5 text-rich-gold shrink-0 mt-0.5" />
                    <div>
                      <p className="font-serif font-bold text-rich-gold">Premium quality materials</p>
                      <p className="text-foreground/70 font-lora text-sm">
                        Hardcover journals, premium paper, gold foil accents
                      </p>
                    </div>
                  </div>

                  <div className="flex items-start gap-2">
                    <Check className="h-5 w-5 text-rich-gold shrink-0 mt-0.5" />
                    <div>
                      <p className="font-serif font-bold text-rich-gold">Attractive profit margins</p>
                      <p className="text-foreground/70 font-lora text-sm">
                        45-60% margins without handling fulfillment
                      </p>
                    </div>
                  </div>
                </div>
              </div>
            </div>

            <div className="grid grid-cols-2 gap-4">
              <div className="space-y-4">
                <div className="relative aspect-[3/4] overflow-hidden rounded-lg">
                  <Image
                    src="/placeholder.svg?height=400&width=300"
                    alt="Midnight Magnolia Journal"
                    fill
                    className="object-cover"
                  />
                  <div className="absolute inset-0 bg-gradient-to-t from-midnight-blue/80 via-transparent to-transparent" />
                  <div className="absolute bottom-0 left-0 right-0 p-4">
                    <p className="text-rich-gold font-serif font-bold">Magnolia Journal</p>
                    <p className="text-foreground/80 text-sm">$32</p>
                  </div>
                </div>
              </div>

              <div className="space-y-4 mt-8">
                <div className="relative aspect-[3/4] overflow-hidden rounded-lg">
                  <Image
                    src="/placeholder.svg?height=400&width=300"
                    alt="Resilience Art Prints"
                    fill
                    className="object-cover"
                  />
                  <div className="absolute inset-0 bg-gradient-to-t from-midnight-blue/80 via-transparent to-transparent" />
                  <div className="absolute bottom-0 left-0 right-0 p-4">
                    <p className="text-rich-gold font-serif font-bold">Art Prints</p>
                    <p className="text-foreground/80 text-sm">$24-45</p>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Subscription & Bundled Content Section */}
      <section className="py-16 md:py-24 bg-gradient-midnight relative overflow-hidden">
        <div className="absolute inset-0 bg-[url('/images/southern-gothic-1.jpeg')] bg-cover bg-center opacity-10" />
        <div className="absolute inset-0 bg-gradient-midnight opacity-90" />

        <div className="container relative z-10 px-4">
          <div className="text-center mb-16">
            <h2 className="text-3xl md:text-4xl font-serif font-bold text-rich-gold mb-4">
              Subscription & Bundled Content
            </h2>
            <p className="text-lg text-magnolia-white/80 max-w-2xl mx-auto font-lora">
              Create recurring revenue and higher-value offerings with our subscription and bundled content options.
            </p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
            {allProducts
              .filter((product) => product.category === "bundle" || product.category === "subscription")
              .map((product) => (
                <Card
                  key={product.id}
                  className="bg-midnight-blue/30 border-rich-gold/20 backdrop-blur-sm overflow-hidden h-full flex flex-col transform hover:-translate-y-2 transition-transform duration-300"
                >
                  <div className="relative">
                    <div className="relative aspect-[4/3] overflow-hidden">
                      <Image
                        src={product.image || "/placeholder.svg"}
                        alt={product.name}
                        fill
                        className="object-cover transition-transform duration-500 hover:scale-105"
                      />

                      {product.badge && (
                        <div className="absolute top-2 right-2 bg-rich-gold text-midnight-blue text-xs font-bold px-2 py-1 rounded-full">
                          {product.badge}
                        </div>
                      )}
                    </div>
                  </div>

                  <CardHeader className="p-4 pb-2">
                    <CardTitle className="text-rich-gold text-xl">{product.name}</CardTitle>
                  </CardHeader>

                  <CardContent className="p-4 pt-0 flex-grow">
                    <p className="text-magnolia-white/90 font-lora text-sm mb-4">{product.description}</p>

                    <div className="space-y-2 text-xs text-magnolia-white/60">
                      {product.format && (
                        <p className="flex items-start gap-1">
                          <Check className="h-3 w-3 text-rich-gold shrink-0 mt-0.5" />
                          <span>{product.format}</span>
                        </p>
                      )}
                      {product.creationTime && (
                        <p className="flex items-start gap-1">
                          <Check className="h-3 w-3 text-rich-gold shrink-0 mt-0.5" />
                          <span>{product.creationTime}</span>
                        </p>
                      )}
                      {product.margin && (
                        <p className="flex items-start gap-1">
                          <Check className="h-3 w-3 text-rich-gold shrink-0 mt-0.5" />
                          <span>Profit margin: {product.margin}</span>
                        </p>
                      )}
                    </div>
                  </CardContent>

                  <CardFooter className="p-4 pt-0 flex justify-between items-center">
                    <p className="font-serif font-bold text-rich-gold text-xl">{product.price}</p>
                    <Button className="bg-rich-gold hover:bg-rich-gold/90 text-midnight-blue">View Details</Button>
                  </CardFooter>
                </Card>
              ))}
          </div>

          <div className="mt-12 text-center">
            <p className="text-magnolia-white/90 font-lora italic max-w-2xl mx-auto mb-6">
              Bundled and subscription products offer the highest profit margins (88-98%) while providing ongoing value
              to your customers.
            </p>
          </div>
        </div>

        {/* Decorative elements */}
        <FloatingMagnolia size="sm" color="gold" className="top-1/4 right-[15%]" />
        <FloatingMagnolia size="md" color="white" className="bottom-1/4 left-[10%]" delay={1.2} />
      </section>

      {/* Featured Services */}
      <section className="py-16 md:py-24">
        <div className="container px-4">
          <div className="text-center mb-16">
            <h2 className="text-3xl md:text-4xl font-serif font-bold text-rich-gold mb-4">Personalized Services</h2>
            <p className="text-lg text-foreground/80 max-w-2xl mx-auto font-lora">
              High-touch support and guidance tailored to your unique entrepreneurial journey.
            </p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
            {featuredServices.map((service) => (
              <Card
                key={service.id}
                className="bg-midnight-blue/20 border-rich-gold/20 overflow-hidden h-full flex flex-col transform hover:-translate-y-2 transition-transform duration-300"
              >
                <div className="relative">
                  <div className="relative aspect-[4/3] overflow-hidden">
                    <Image
                      src={service.image || "/placeholder.svg"}
                      alt={service.name}
                      fill
                      className="object-cover transition-transform duration-500 hover:scale-105"
                    />

                    {service.badge && (
                      <div className="absolute top-2 right-2 bg-rich-gold text-midnight-blue text-xs font-bold px-2 py-1 rounded-full">
                        {service.badge}
                      </div>
                    )}
                  </div>
                </div>

                <CardHeader className="p-4 pb-2">
                  <CardTitle className="text-rich-gold text-xl">{service.name}</CardTitle>
                </CardHeader>

                <CardContent className="p-4 pt-0 flex-grow">
                  <p className="text-foreground/80 font-lora text-sm mb-4">{service.description}</p>
                  <p className="text-sm text-foreground/60">{service.duration}</p>
                </CardContent>

                <CardFooter className="p-4 pt-0 flex justify-between items-center">
                  <p className="font-serif font-bold text-rich-gold text-xl">{service.price}</p>
                  <Button className="bg-rich-gold hover:bg-rich-gold/90 text-midnight-blue">View Details</Button>
                </CardFooter>
              </Card>
            ))}
          </div>

          <div className="text-center mt-12">
            <Link href="/services">
              <Button size="lg" className="bg-rich-gold hover:bg-rich-gold/90 text-midnight-blue">
                Explore All Services
              </Button>
            </Link>
          </div>
        </div>
      </section>

      {/* Comparison Section */}
      <section className="py-16 md:py-24 bg-gradient-midnight relative overflow-hidden">
        <div className="absolute inset-0 bg-[url('/images/southern-gothic-3.jpeg')] bg-cover bg-center opacity-10" />
        <div className="absolute inset-0 bg-gradient-midnight opacity-90" />

        <div className="container relative z-10 px-4">
          <div className="text-center mb-16">
            <h2 className="text-3xl md:text-4xl font-serif font-bold text-rich-gold mb-4">
              Which Option Is Right For You?
            </h2>
            <p className="text-lg text-magnolia-white/80 max-w-2xl mx-auto font-lora">
              Compare our digital products and personalized services to find the perfect fit for your needs.
            </p>
          </div>

          <div className="max-w-4xl mx-auto">
            <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
              <Card className="bg-midnight-blue/30 border-rich-gold/20 backdrop-blur-sm overflow-hidden">
                <CardHeader className="text-center border-b border-rich-gold/20 pb-4">
                  <CardTitle className="text-rich-gold text-2xl">Digital Products</CardTitle>
                  <p className="text-magnolia-white/70 font-lora mt-2">Self-paced digital tools</p>
                </CardHeader>

                <CardContent className="p-6">
                  <ul className="space-y-4">
                    <li className="flex items-start gap-2">
                      <Check className="h-5 w-5 text-rich-gold shrink-0 mt-0.5" />
                      <p className="text-magnolia-white/90 font-lora">Immediate access to tools and resources</p>
                    </li>
                    <li className="flex items-start gap-2">
                      <Check className="h-5 w-5 text-rich-gold shrink-0 mt-0.5" />
                      <p className="text-magnolia-white/90 font-lora">Work at your own pace and on your own schedule</p>
                    </li>
                    <li className="flex items-start gap-2">
                      <Check className="h-5 w-5 text-rich-gold shrink-0 mt-0.5" />
                      <p className="text-magnolia-white/90 font-lora">Lower investment with high-value return</p>
                    </li>
                    <li className="flex items-start gap-2">
                      <Check className="h-5 w-5 text-rich-gold shrink-0 mt-0.5" />
                      <p className="text-magnolia-white/90 font-lora">Perfect for self-motivated entrepreneurs</p>
                    </li>
                    <li className="flex items-start gap-2">
                      <Check className="h-5 w-5 text-rich-gold shrink-0 mt-0.5" />
                      <p className="text-magnolia-white/90 font-lora">Lifetime access to materials and updates</p>
                    </li>
                  </ul>
                </CardContent>

                <CardFooter className="border-t border-rich-gold/20 pt-6 flex justify-center">
                  <Link href="/shop">
                    <Button className="bg-rich-gold hover:bg-rich-gold/90 text-midnight-blue">
                      Browse Digital Products
                    </Button>
                  </Link>
                </CardFooter>
              </Card>

              <Card className="bg-midnight-blue/30 border-rich-gold/20 backdrop-blur-sm overflow-hidden">
                <CardHeader className="text-center border-b border-rich-gold/20 pb-4">
                  <CardTitle className="text-rich-gold text-2xl">Personalized Services</CardTitle>
                  <p className="text-magnolia-white/70 font-lora mt-2">High-touch support and guidance</p>
                </CardHeader>

                <CardContent className="p-6">
                  <ul className="space-y-4">
                    <li className="flex items-start gap-2">
                      <Check className="h-5 w-5 text-rich-gold shrink-0 mt-0.5" />
                      <p className="text-magnolia-white/90 font-lora">
                        Direct access to Latisha's expertise and guidance
                      </p>
                    </li>
                    <li className="flex items-start gap-2">
                      <Check className="h-5 w-5 text-rich-gold shrink-0 mt-0.5" />
                      <p className="text-magnolia-white/90 font-lora">
                        Personalized strategies tailored to your specific needs
                      </p>
                    </li>
                    <li className="flex items-start gap-2">
                      <Check className="h-5 w-5 text-rich-gold shrink-0 mt-0.5" />
                      <p className="text-magnolia-white/90 font-lora">
                        Accountability and support throughout your journey
                      </p>
                    </li>
                    <li className="flex items-start gap-2">
                      <Check className="h-5 w-5 text-rich-gold shrink-0 mt-0.5" />
                      <p className="text-magnolia-white/90 font-lora">
                        Community connection with like-minded entrepreneurs
                      </p>
                    </li>
                    <li className="flex items-start gap-2">
                      <Check className="h-5 w-5 text-rich-gold shrink-0 mt-0.5" />
                      <p className="text-magnolia-white/90 font-lora">Faster results through guided implementation</p>
                    </li>
                  </ul>
                </CardContent>

                <CardFooter className="border-t border-rich-gold/20 pt-6 flex justify-center">
                  <Link href="/services">
                    <Button className="bg-rich-gold hover:bg-rich-gold/90 text-midnight-blue">Explore Services</Button>
                  </Link>
                </CardFooter>
              </Card>
            </div>

            <div className="mt-12 text-center">
              <p className="text-magnolia-white/90 font-lora italic max-w-2xl mx-auto mb-6">
                Not sure which option is right for you? Schedule a complimentary discovery call to discuss your needs
                and get personalized recommendations.
              </p>
              <Button variant="outline" className="border-rich-gold text-rich-gold hover:bg-rich-gold/10">
                Book a Discovery Call
              </Button>
            </div>
          </div>
        </div>

        {/* Decorative elements */}
        <FloatingMagnolia size="sm" color="gold" className="top-1/4 right-[15%]" />
        <FloatingMagnolia size="md" color="white" className="bottom-1/4 left-[10%]" delay={1.2} />
      </section>

      {/* Testimonials */}
      <section className="py-16 md:py-24">
        <div className="container px-4">
          <div className="text-center mb-16">
            <h2 className="text-3xl md:text-4xl font-serif font-bold text-rich-gold mb-4">Client Success Stories</h2>
            <p className="text-lg text-foreground/80 max-w-2xl mx-auto font-lora">
              Hear from entrepreneurs who have experienced transformation through our products and services.
            </p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-3 gap-8 max-w-5xl mx-auto">
            <Card className="bg-midnight-blue/20 border-rich-gold/20">
              <CardContent className="pt-6">
                <div className="flex items-center gap-4 mb-4">
                  <div className="w-12 h-12 rounded-full bg-rich-gold/20 flex items-center justify-center">
                    <span className="text-xl text-rich-gold">EM</span>
                  </div>
                  <div>
                    <p className="font-serif font-bold text-rich-gold">Elena Martinez</p>
                    <p className="text-sm text-foreground/60">Digital Product Creator</p>
                  </div>
                </div>
                <p className="text-foreground/80 font-lora italic mb-4">
                  "The Midnight Entrepreneur Planner completely transformed my approach to business planning. As someone
                  with ADHD, I finally found a system that works with my brain instead of against it. Within 3 months of
                  implementing the strategies, I launched two new digital products that generated $8K in passive
                  income."
                </p>
                <div className="flex gap-1">
                  {[...Array(5)].map((_, i) => (
                    <Star key={i} className="w-5 h-5 text-rich-gold fill-rich-gold" />
                  ))}
                </div>
              </CardContent>
            </Card>

            <Card className="bg-midnight-blue/20 border-rich-gold/20">
              <CardContent className="pt-6">
                <div className="flex items-center gap-4 mb-4">
                  <div className="w-12 h-12 rounded-full bg-rich-gold/20 flex items-center justify-center">
                    <span className="text-xl text-rich-gold">JW</span>
                  </div>
                  <div>
                    <p className="font-serif font-bold text-rich-gold">James Wilson</p>
                    <p className="text-sm text-foreground/60">Membership Community Member</p>
                  </div>
                </div>
                <p className="text-foreground/80 font-lora italic mb-4">
                  "Joining the Midnight Magnolia Membership was the best decision I made for my business. The monthly
                  coaching calls and community support have been invaluable. What sets this apart is how Latisha truly
                  understands neurodivergent entrepreneurs. I've found my people and my business has grown 40% since
                  joining."
                </p>
                <div className="flex gap-1">
                  {[...Array(5)].map((_, i) => (
                    <Star key={i} className="w-5 h-5 text-rich-gold fill-rich-gold" />
                  ))}
                </div>
              </CardContent>
            </Card>

            <Card className="bg-midnight-blue/20 border-rich-gold/20">
              <CardContent className="pt-6">
                <div className="flex items-center gap-4 mb-4">
                  <div className="w-12 h-12 rounded-full bg-rich-gold/20 flex items-center justify-center">
                    <span className="text-xl text-rich-gold">SB</span>
                  </div>
                  <div>
                    <p className="font-serif font-bold text-rich-gold">Sophia Brooks</p>
                    <p className="text-sm text-foreground/60">VIP Strategy Day Client</p>
                  </div>
                </div>
                <p className="text-foreground/80 font-lora italic mb-4">
                  "My VIP Strategy Day with Latisha was transformative. In just 6 hours, we completely restructured my
                  business systems to work with my neurodivergent brain. The follow-up support ensured I implemented
                  everything successfully. Three months later, I've doubled my income while working fewer hours. Worth
                  every penny!"
                </p>
                <div className="flex gap-1">
                  {[...Array(5)].map((_, i) => (
                    <Star key={i} className="w-5 h-5 text-rich-gold fill-rich-gold" />
                  ))}
                </div>
              </CardContent>
            </Card>
          </div>
        </div>
      </section>

      {/* CTA */}
      <section className="py-16 bg-gradient-midnight relative overflow-hidden">
        <div className="absolute inset-0 bg-[url('/images/southern-gothic-1.jpeg')] bg-cover bg-center opacity-10" />
        <div className="absolute inset-0 bg-gradient-midnight opacity-90" />

        <div className="container relative z-10 px-4 text-center">
          <h2 className="text-3xl md:text-4xl font-serif font-bold text-rich-gold mb-6">
            Ready to Transform Your Business?
          </h2>
          <p className="text-xl text-magnolia-white/90 font-lora max-w-2xl mx-auto mb-8">
            Whether you prefer self-paced digital products or high-touch services, Midnight Magnolia offers the support
            you need to create a sustainable, profitable business that honors your neurodivergent mind.
          </p>
          <div className="flex flex-col sm:flex-row gap-4 justify-center">
            <Link href="/shop">
              <Button size="lg" className="bg-rich-gold hover:bg-rich-gold/90 text-midnight-blue font-medium">
                Explore Digital Products
              </Button>
            </Link>
            <Link href="/services">
              <Button size="lg" variant="outline" className="border-rich-gold text-rich-gold hover:bg-rich-gold/10">
                View Services
              </Button>
            </Link>
          </div>
        </div>
      </section>

      <Footer />
    </main>
  )
}

// Product Card Component
function ProductCard({ product, featured = false }: { product: any; featured?: boolean }) {
  return (
    <Card
      className={`bg-midnight-blue/20 border-rich-gold/20 overflow-hidden h-full flex flex-col ${featured ? "transform hover:-translate-y-2 transition-transform duration-300" : ""}`}
    >
      <div className="relative">
        <div className="relative aspect-[4/3] overflow-hidden">
          <Image
            src={product.image || "/placeholder.svg"}
            alt={product.name}
            fill
            className="object-cover transition-transform duration-500 hover:scale-105"
          />

          {product.badge && (
            <div className="absolute top-2 right-2 bg-rich-gold text-midnight-blue text-xs font-bold px-2 py-1 rounded-full">
              {product.badge}
            </div>
          )}
        </div>
      </div>

      <CardHeader className="p-4 pb-2">
        <CardTitle className="text-rich-gold text-xl">{product.name}</CardTitle>
      </CardHeader>

      <CardContent className="p-4 pt-0 flex-grow">
        <p className="text-foreground/80 font-lora text-sm mb-4">{product.description}</p>

        <div className="space-y-2 text-xs text-foreground/60">
          {product.format && (
            <p className="flex items-start gap-1">
              <Check className="h-3 w-3 text-rich-gold shrink-0 mt-0.5" />
              <span>{product.format}</span>
            </p>
          )}
          {product.creationTime && (
            <p className="flex items-start gap-1">
              <Check className="h-3 w-3 text-rich-gold shrink-0 mt-0.5" />
              <span>{product.creationTime}</span>
            </p>
          )}
          {product.margin && (
            <p className="flex items-start gap-1">
              <Check className="h-3 w-3 text-rich-gold shrink-0 mt-0.5" />
              <span>Profit margin: {product.margin}</span>
            </p>
          )}
        </div>
      </CardContent>

      <CardFooter className="p-4 pt-0 flex justify-between items-center">
        <p className="font-serif font-bold text-rich-gold text-xl">{product.price}</p>
        <Button className="bg-rich-gold hover:bg-rich-gold/90 text-midnight-blue">View Details</Button>
      </CardFooter>
    </Card>
  )
}

