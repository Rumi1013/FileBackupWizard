import { Navigation } from "@/components/navigation"
import { Footer } from "@/components/footer"
import { FloatingMagnolia } from "@/components/floating-magnolia"
import Image from "next/image"

export default function GalleryPage() {
  return (
    <main className="min-h-screen bg-background">
      <Navigation />

      {/* Hero Section */}
      <section className="relative pt-20 pb-16 overflow-hidden">
        <div className="absolute inset-0 bg-gradient-midnight opacity-95" />

        <div className="container relative z-10 px-4">
          <div className="max-w-4xl mx-auto text-center">
            <h1 className="text-4xl md:text-5xl lg:text-6xl font-serif font-bold text-rich-gold mb-6">
              Visual Journey
            </h1>
            <p className="text-xl text-magnolia-white/90 font-lora italic mb-8">
              Explore the Southern Gothic elegance and transformative essence of Midnight Magnolia through our curated
              gallery.
            </p>
          </div>
        </div>

        {/* Decorative elements */}
        <FloatingMagnolia size="lg" color="gold" className="top-12 right-[10%]" />
        <FloatingMagnolia size="md" color="white" className="bottom-24 left-[15%]" delay={1.5} />
      </section>

      {/* Gallery Grid */}
      <section className="py-16 md:py-24">
        <div className="container px-4">
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            {/* Gallery Item 1 */}
            <div className="group relative overflow-hidden rounded-lg aspect-[4/5]">
              <Image
                src="/images/southern-gothic-1.jpeg"
                alt="Southern Gothic mansion with golden moon"
                fill
                className="object-cover transition-transform duration-500 group-hover:scale-110"
              />
              <div className="absolute inset-0 bg-gradient-to-t from-midnight-blue/80 via-midnight-blue/30 to-transparent opacity-80 group-hover:opacity-100 transition-opacity" />

              <div className="absolute bottom-0 left-0 right-0 p-4 transform translate-y-2 group-hover:translate-y-0 transition-transform">
                <h3 className="text-xl font-serif font-bold text-rich-gold mb-1">Golden Moon Sanctuary</h3>
                <p className="text-sm text-magnolia-white/90">
                  The ancestral home illuminated by the golden light of transformation.
                </p>
              </div>
            </div>

            {/* Gallery Item 2 */}
            <div className="group relative overflow-hidden rounded-lg aspect-[4/5]">
              <Image
                src="/images/southern-gothic-2.jpeg"
                alt="Woman overlooking a Southern mansion"
                fill
                className="object-cover transition-transform duration-500 group-hover:scale-110"
              />
              <div className="absolute inset-0 bg-gradient-to-t from-midnight-blue/80 via-midnight-blue/30 to-transparent opacity-80 group-hover:opacity-100 transition-opacity" />

              <div className="absolute bottom-0 left-0 right-0 p-4 transform translate-y-2 group-hover:translate-y-0 transition-transform">
                <h3 className="text-xl font-serif font-bold text-rich-gold mb-1">Midnight Blooms</h3>
                <p className="text-sm text-magnolia-white/90">
                  Magnolias glow with ethereal light, symbolizing resilience in darkness.
                </p>
              </div>
            </div>

            {/* Gallery Item 3 */}
            <div className="group relative overflow-hidden rounded-lg aspect-[4/5]">
              <Image
                src="/images/southern-gothic-3.jpeg"
                alt="Southern Gothic scene with crescent moon"
                fill
                className="object-cover transition-transform duration-500 group-hover:scale-110"
              />
              <div className="absolute inset-0 bg-gradient-to-t from-midnight-blue/80 via-midnight-blue/30 to-transparent opacity-80 group-hover:opacity-100 transition-opacity" />

              <div className="absolute bottom-0 left-0 right-0 p-4 transform translate-y-2 group-hover:translate-y-0 transition-transform">
                <h3 className="text-xl font-serif font-bold text-rich-gold mb-1">Crescent Journey</h3>
                <p className="text-sm text-magnolia-white/90">
                  The path forward illuminated by both celestial and earthly light.
                </p>
              </div>
            </div>

            {/* Additional Gallery Items */}
            <div className="group relative overflow-hidden rounded-lg aspect-[4/5] bg-midnight-blue/30">
              <div className="absolute inset-0 flex items-center justify-center">
                <div className="w-24 h-24 rounded-full bg-rich-gold/20 flex items-center justify-center animate-glow">
                  <span className="text-4xl text-rich-gold">MM</span>
                </div>
              </div>
              <div className="absolute inset-0 bg-gradient-to-t from-midnight-blue/80 via-midnight-blue/30 to-transparent opacity-80 group-hover:opacity-100 transition-opacity" />

              <div className="absolute bottom-0 left-0 right-0 p-4 transform translate-y-2 group-hover:translate-y-0 transition-transform">
                <h3 className="text-xl font-serif font-bold text-rich-gold mb-1">Brand Essence</h3>
                <p className="text-sm text-magnolia-white/90">
                  The core elements that define the Midnight Magnolia aesthetic.
                </p>
              </div>
            </div>

            <div className="group relative overflow-hidden rounded-lg aspect-[4/5] bg-midnight-blue/30">
              <div className="absolute inset-0 flex items-center justify-center">
                <div className="text-rich-gold">
                  <svg
                    className="w-24 h-24 opacity-30"
                    viewBox="0 0 100 100"
                    fill="none"
                    xmlns="http://www.w3.org/2000/svg"
                  >
                    <path
                      d="M50,20 C60,35 80,40 90,55 C80,75 60,85 50,90 C40,85 20,75 10,55 C20,40 40,35 50,20"
                      stroke="currentColor"
                      strokeWidth="2"
                    />
                  </svg>
                </div>
              </div>
              <div className="absolute inset-0 bg-gradient-to-t from-midnight-blue/80 via-midnight-blue/30 to-transparent opacity-80 group-hover:opacity-100 transition-opacity" />

              <div className="absolute bottom-0 left-0 right-0 p-4 transform translate-y-2 group-hover:translate-y-0 transition-transform">
                <h3 className="text-xl font-serif font-bold text-rich-gold mb-1">Magnolia Motif</h3>
                <p className="text-sm text-magnolia-white/90">
                  The symbolic flower representing resilience and Southern elegance.
                </p>
              </div>
            </div>

            <div className="group relative overflow-hidden rounded-lg aspect-[4/5] bg-midnight-blue/30">
              <div className="absolute inset-0 flex items-center justify-center">
                <div className="text-rich-gold">
                  <svg
                    className="w-24 h-24 opacity-30"
                    viewBox="0 0 100 100"
                    fill="none"
                    xmlns="http://www.w3.org/2000/svg"
                  >
                    <path d="M50,10 A40,40 0 0 1 50,90 A40,40 0 0 1 50,10" stroke="currentColor" strokeWidth="2" />
                  </svg>
                </div>
              </div>
              <div className="absolute inset-0 bg-gradient-to-t from-midnight-blue/80 via-midnight-blue/30 to-transparent opacity-80 group-hover:opacity-100 transition-opacity" />

              <div className="absolute bottom-0 left-0 right-0 p-4 transform translate-y-2 group-hover:translate-y-0 transition-transform">
                <h3 className="text-xl font-serif font-bold text-rich-gold mb-1">Crescent Moon</h3>
                <p className="text-sm text-magnolia-white/90">
                  Symbol of transformation and the cyclical nature of growth.
                </p>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Video Section */}
      <section className="py-16 md:py-24 bg-gradient-midnight relative overflow-hidden">
        <div className="absolute inset-0 bg-gradient-midnight opacity-95" />

        <div className="container relative z-10 px-4">
          <div className="text-center mb-16">
            <h2 className="text-3xl md:text-4xl font-serif font-bold text-rich-gold mb-4">Behind the Scenes</h2>
            <p className="text-lg text-magnolia-white/80 max-w-2xl mx-auto font-lora">
              Glimpse into the creative process and philosophy behind Midnight Magnolia.
            </p>
          </div>

          <div className="max-w-3xl mx-auto">
            <div className="relative aspect-video rounded-lg overflow-hidden bg-midnight-blue/50 border border-rich-gold/20">
              <div className="absolute inset-0 flex items-center justify-center">
                <div className="w-20 h-20 rounded-full bg-rich-gold/20 flex items-center justify-center">
                  <svg
                    className="w-10 h-10 text-rich-gold"
                    viewBox="0 0 24 24"
                    fill="none"
                    xmlns="http://www.w3.org/2000/svg"
                  >
                    <path d="M8 5V19L19 12L8 5Z" fill="currentColor" />
                  </svg>
                </div>
              </div>
            </div>

            <div className="mt-8 text-center">
              <p className="text-magnolia-white/70 font-lora italic">
                Click to watch "The Making of Midnight Magnolia: A Journey of Transformation"
              </p>
            </div>
          </div>
        </div>

        {/* Decorative elements */}
        <FloatingMagnolia size="sm" color="gold" className="top-1/4 right-[15%]" />
        <FloatingMagnolia size="md" color="white" className="bottom-1/4 left-[10%]" delay={1.2} />
      </section>

      <Footer />
    </main>
  )
}

