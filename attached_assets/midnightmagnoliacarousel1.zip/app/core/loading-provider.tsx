"use client"

import { createContext, useContext, useState, type ReactNode } from "react"

interface LoadingContextType {
  isLoading: boolean
  setLoading: (loading: boolean) => void
  loadingMessage: string
  setLoadingMessage: (message: string) => void
}

const LoadingContext = createContext<LoadingContextType | undefined>(undefined)

export function useLoading() {
  const context = useContext(LoadingContext)
  if (context === undefined) {
    throw new Error("useLoading must be used within a LoadingProvider")
  }
  return context
}

interface LoadingProviderProps {
  children: ReactNode
}

export function LoadingProvider({ children }: LoadingProviderProps) {
  const [isLoading, setLoading] = useState(false)
  const [loadingMessage, setLoadingMessage] = useState("Loading...")

  return (
    <LoadingContext.Provider value={{ isLoading, setLoading, loadingMessage, setLoadingMessage }}>
      {isLoading && (
        <div className="fixed inset-0 bg-midnight-blue/80 backdrop-blur-sm z-50 flex items-center justify-center">
          <div className="bg-midnight-blue/50 border border-rich-gold/20 rounded-lg p-6 max-w-sm w-full text-center">
            <div className="w-16 h-16 border-4 border-rich-gold/20 border-t-rich-gold rounded-full animate-spin mx-auto mb-4"></div>
            <p className="text-magnolia-white font-serif">{loadingMessage}</p>
          </div>
        </div>
      )}
      {children}
    </LoadingContext.Provider>
  )
}

