"use client"

import { createContext, useContext, type ReactNode } from "react"

interface BrandGuidelines {
  colors: {
    midnightBlue: string
    midnightTeal: string
    magnoliaWhite: string
    richGold: string
    sageGreen: string
  }
  typography: {
    headers: string
    body: string
    accents: string
  }
  spacing: {
    xs: string
    sm: string
    md: string
    lg: string
    xl: string
  }
  borderRadius: {
    sm: string
    md: string
    lg: string
    full: string
  }
  shadows: {
    sm: string
    md: string
    lg: string
  }
  animations: {
    fadeIn: string
    slideIn: string
    pulse: string
  }
}

const brandGuidelines: BrandGuidelines = {
  colors: {
    midnightBlue: "#0A192F",
    midnightTeal: "#0A3B4D",
    magnoliaWhite: "#FAF3E0",
    richGold: "#D4AF37",
    sageGreen: "#A3B18A",
  },
  typography: {
    headers: "Playfair Display, serif",
    body: "Lora, serif",
    accents: "Montserrat, sans-serif",
  },
  spacing: {
    xs: "0.25rem",
    sm: "0.5rem",
    md: "1rem",
    lg: "2rem",
    xl: "4rem",
  },
  borderRadius: {
    sm: "0.25rem",
    md: "0.5rem",
    lg: "1rem",
    full: "9999px",
  },
  shadows: {
    sm: "0 1px 3px rgba(0, 0, 0, 0.12), 0 1px 2px rgba(0, 0, 0, 0.24)",
    md: "0 4px 6px rgba(0, 0, 0, 0.1), 0 1px 3px rgba(0, 0, 0, 0.08)",
    lg: "0 10px 25px rgba(0, 0, 0, 0.15), 0 5px 10px rgba(0, 0, 0, 0.05)",
  },
  animations: {
    fadeIn: "fade-in 0.5s ease-in-out",
    slideIn: "slide-in 0.5s ease-out",
    pulse: "pulse 2s cubic-bezier(0.4, 0, 0.6, 1) infinite",
  },
}

interface BrandGuidelinesContextType {
  guidelines: BrandGuidelines
  applyColor: (colorName: keyof BrandGuidelines["colors"]) => string
  applyFont: (fontName: keyof BrandGuidelines["typography"]) => string
  applySpacing: (spacingName: keyof BrandGuidelines["spacing"]) => string
  applyRadius: (radiusName: keyof BrandGuidelines["borderRadius"]) => string
  applyShadow: (shadowName: keyof BrandGuidelines["shadows"]) => string
  applyAnimation: (animationName: keyof BrandGuidelines["animations"]) => string
}

const BrandGuidelinesContext = createContext<BrandGuidelinesContextType | undefined>(undefined)

export function useBrandGuidelines() {
  const context = useContext(BrandGuidelinesContext)
  if (context === undefined) {
    throw new Error("useBrandGuidelines must be used within a BrandGuidelinesManager")
  }
  return context
}

interface BrandGuidelinesManagerProps {
  children: ReactNode
}

export function BrandGuidelinesManager({ children }: BrandGuidelinesManagerProps) {
  const applyColor = (colorName: keyof BrandGuidelines["colors"]) => {
    return brandGuidelines.colors[colorName]
  }

  const applyFont = (fontName: keyof BrandGuidelines["typography"]) => {
    return brandGuidelines.typography[fontName]
  }

  const applySpacing = (spacingName: keyof BrandGuidelines["spacing"]) => {
    return brandGuidelines.spacing[spacingName]
  }

  const applyRadius = (radiusName: keyof BrandGuidelines["borderRadius"]) => {
    return brandGuidelines.borderRadius[radiusName]
  }

  const applyShadow = (shadowName: keyof BrandGuidelines["shadows"]) => {
    return brandGuidelines.shadows[shadowName]
  }

  const applyAnimation = (animationName: keyof BrandGuidelines["animations"]) => {
    return brandGuidelines.animations[animationName]
  }

  return (
    <BrandGuidelinesContext.Provider
      value={{
        guidelines: brandGuidelines,
        applyColor,
        applyFont,
        applySpacing,
        applyRadius,
        applyShadow,
        applyAnimation,
      }}
    >
      {children}
    </BrandGuidelinesContext.Provider>
  )
}

