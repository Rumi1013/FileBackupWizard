"use client"

import type React from "react"

import { createContext, useContext, useReducer, type ReactNode } from "react"

// Define the state structure
interface AppState {
  products: any[]
  content: any[]
  analytics: any
  marketing: any
  inventory: any
  socialMediaCalendar: any
}

// Define action types
type Action =
  | { type: "SET_PRODUCTS"; payload: any[] }
  | { type: "SET_CONTENT"; payload: any[] }
  | { type: "SET_ANALYTICS"; payload: any }
  | { type: "SET_MARKETING"; payload: any }
  | { type: "SET_INVENTORY"; payload: any }
  | { type: "SET_SOCIAL_MEDIA_CALENDAR"; payload: any }

// Initial state
const initialState: AppState = {
  products: [],
  content: [],
  analytics: {},
  marketing: {},
  inventory: {},
  socialMediaCalendar: {},
}

// Reducer function
function reducer(state: AppState, action: Action): AppState {
  switch (action.type) {
    case "SET_PRODUCTS":
      return { ...state, products: action.payload }
    case "SET_CONTENT":
      return { ...state, content: action.payload }
    case "SET_ANALYTICS":
      return { ...state, analytics: action.payload }
    case "SET_MARKETING":
      return { ...state, marketing: action.payload }
    case "SET_INVENTORY":
      return { ...state, inventory: action.payload }
    case "SET_SOCIAL_MEDIA_CALENDAR":
      return { ...state, socialMediaCalendar: action.payload }
    default:
      return state
  }
}

// Create context
interface StateContextType {
  state: AppState
  dispatch: React.Dispatch<Action>
}

const StateContext = createContext<StateContextType | undefined>(undefined)

// Custom hook to use the state
export function useAppState() {
  const context = useContext(StateContext)
  if (context === undefined) {
    throw new Error("useAppState must be used within a StateManager")
  }
  return context
}

// Provider component
interface StateManagerProps {
  children: ReactNode
}

export function StateManager({ children }: StateManagerProps) {
  const [state, dispatch] = useReducer(reducer, initialState)

  return <StateContext.Provider value={{ state, dispatch }}>{children}</StateContext.Provider>
}

