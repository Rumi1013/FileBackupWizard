"use client"

import { createContext, useContext, useEffect, useState, type ReactNode } from "react"

type Breakpoint = "xs" | "sm" | "md" | "lg" | "xl" | "2xl"

interface ResponsiveContextType {
  breakpoint: Breakpoint
  isMobile: boolean
  isTablet: boolean
  isDesktop: boolean
}

const ResponsiveContext = createContext<ResponsiveContextType | undefined>(undefined)

export function useResponsive() {
  const context = useContext(ResponsiveContext)
  if (context === undefined) {
    throw new Error("useResponsive must be used within a ResponsiveProvider")
  }
  return context
}

interface ResponsiveProviderProps {
  children: ReactNode
}

export function ResponsiveProvider({ children }: ResponsiveProviderProps) {
  const [breakpoint, setBreakpoint] = useState<Breakpoint>("lg")
  const [isMobile, setIsMobile] = useState(false)
  const [isTablet, setIsTablet] = useState(false)
  const [isDesktop, setIsDesktop] = useState(true)

  useEffect(() => {
    const handleResize = () => {
      const width = window.innerWidth

      if (width < 640) {
        setBreakpoint("xs")
        setIsMobile(true)
        setIsTablet(false)
        setIsDesktop(false)
      } else if (width < 768) {
        setBreakpoint("sm")
        setIsMobile(true)
        setIsTablet(false)
        setIsDesktop(false)
      } else if (width < 1024) {
        setBreakpoint("md")
        setIsMobile(false)
        setIsTablet(true)
        setIsDesktop(false)
      } else if (width < 1280) {
        setBreakpoint("lg")
        setIsMobile(false)
        setIsTablet(false)
        setIsDesktop(true)
      } else if (width < 1536) {
        setBreakpoint("xl")
        setIsMobile(false)
        setIsTablet(false)
        setIsDesktop(true)
      } else {
        setBreakpoint("2xl")
        setIsMobile(false)
        setIsTablet(false)
        setIsDesktop(true)
      }
    }

    // Initial check
    handleResize()

    // Add event listener
    window.addEventListener("resize", handleResize)

    // Clean up
    return () => window.removeEventListener("resize", handleResize)
  }, [])

  return (
    <ResponsiveContext.Provider value={{ breakpoint, isMobile, isTablet, isDesktop }}>
      {children}
    </ResponsiveContext.Provider>
  )
}

