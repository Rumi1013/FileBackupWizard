"use client"

import { createContext, useContext, useState, type ReactNode } from "react"

interface Message {
  id: string
  role: "user" | "assistant"
  content: string
  timestamp: Date
}

interface AIAssistantContextType {
  messages: Message[]
  isLoading: boolean
  sendMessage: (content: string) => Promise<void>
  clearMessages: () => void
}

const AIAssistantContext = createContext<AIAssistantContextType | undefined>(undefined)

export function useAIAssistant() {
  const context = useContext(AIAssistantContext)
  if (context === undefined) {
    throw new Error("useAIAssistant must be used within an AIAssistantProvider")
  }
  return context
}

interface AIAssistantProviderProps {
  children: ReactNode
}

export function AIAssistantProvider({ children }: AIAssistantProviderProps) {
  const [messages, setMessages] = useState<Message[]>([
    {
      id: "1",
      role: "assistant",
      content: "Hello! I'm your Midnight Magnolia assistant. How can I help you today?",
      timestamp: new Date(),
    },
  ])
  const [isLoading, setIsLoading] = useState(false)

  const sendMessage = async (content: string) => {
    if (!content.trim()) return

    // Add user message
    const userMessage: Message = {
      id: Date.now().toString(),
      role: "user",
      content,
      timestamp: new Date(),
    }

    setMessages((prev) => [...prev, userMessage])
    setIsLoading(true)

    try {
      // This would normally be an API call to OpenAI or similar
      // Simulating API call for demo purposes
      await new Promise((resolve) => setTimeout(resolve, 1500))

      // Mock response
      const responses = [
        "I'd be happy to help you with that! Let me know if you need more information.",
        "That's a great question about Midnight Magnolia. Here's what you should know...",
        "I can definitely assist with your digital product needs. Midnight Magnolia specializes in high-margin digital products.",
        "Looking for Southern Gothic design elements? Our brand guidelines include several options you might like.",
        "The Midnight Magnolia approach focuses on sustainable income through digital entrepreneurship.",
      ]

      const randomResponse = responses[Math.floor(Math.random() * responses.length)]

      const assistantMessage: Message = {
        id: (Date.now() + 1).toString(),
        role: "assistant",
        content: randomResponse,
        timestamp: new Date(),
      }

      setMessages((prev) => [...prev, assistantMessage])
    } catch (error) {
      console.error("Error sending message to AI assistant:", error)

      // Add error message
      const errorMessage: Message = {
        id: (Date.now() + 1).toString(),
        role: "assistant",
        content: "I apologize, but I encountered an error. Please try again later.",
        timestamp: new Date(),
      }

      setMessages((prev) => [...prev, errorMessage])
    } finally {
      setIsLoading(false)
    }
  }

  const clearMessages = () => {
    setMessages([
      {
        id: "1",
        role: "assistant",
        content: "Hello! I'm your Midnight Magnolia assistant. How can I help you today?",
        timestamp: new Date(),
      },
    ])
  }

  return (
    <AIAssistantContext.Provider
      value={{
        messages,
        isLoading,
        sendMessage,
        clearMessages,
      }}
    >
      {children}
    </AIAssistantContext.Provider>
  )
}

