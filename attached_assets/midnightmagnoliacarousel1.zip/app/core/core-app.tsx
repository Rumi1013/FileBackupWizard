"use client"

import { type ReactNode, useEffect } from "react"
import { ThemeProvider } from "@/components/theme-provider"
import { ErrorBoundary } from "@/app/core/error-boundary"
import { LoadingProvider } from "@/app/core/loading-provider"
import { ResponsiveProvider } from "@/app/core/responsive-provider"
import { StateManager } from "@/app/core/state-manager"
import { BrandGuidelinesManager } from "@/app/core/brand-guidelines-manager"
import { AuthProvider } from "@/app/core/auth-provider"
import { AIAssistantProvider } from "@/contexts/ai-assistant-context"

interface CoreAppProps {
  children: ReactNode
}

export function CoreApp({ children }: CoreAppProps) {
  useEffect(() => {
    // Initialize analytics or other core services
    console.log("Core application initialized")
  }, [])

  return (
    <ErrorBoundary>
      <ThemeProvider defaultTheme="dark" attribute="class">
        <ResponsiveProvider>
          <LoadingProvider>
            <StateManager>
              <AuthProvider>
                <BrandGuidelinesManager>
                  <AIAssistantProvider>{children}</AIAssistantProvider>
                </BrandGuidelinesManager>
              </AuthProvider>
            </StateManager>
          </LoadingProvider>
        </ResponsiveProvider>
      </ThemeProvider>
    </ErrorBoundary>
  )
}

