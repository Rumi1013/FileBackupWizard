"use client"

import { usePathname, useRouter } from "next/navigation"
import { createContext, useContext, type ReactNode, useCallback } from "react"
import { useAuth } from "@/app/core/auth-provider"

interface Route {
  path: string
  requiresAuth: boolean
  requiredRole?: "admin" | "client"
}

const routes: Record<string, Route> = {
  home: { path: "/", requiresAuth: false },
  about: { path: "/about", requiresAuth: false },
  services: { path: "/services", requiresAuth: false },
  brand: { path: "/brand", requiresAuth: false },
  developer: { path: "/developer", requiresAuth: false },
  magical: { path: "/magical-experience", requiresAuth: false },
  marketing: { path: "/marketing", requiresAuth: false },
  blog: { path: "/blog", requiresAuth: false },
  seo: { path: "/seo", requiresAuth: true, requiredRole: "admin" },
  launch: { path: "/launch", requiresAuth: false },
  products: { path: "/products", requiresAuth: false },
  clientPortal: { path: "/client", requiresAuth: true, requiredRole: "client" },
  adminPortal: { path: "/admin", requiresAuth: true, requiredRole: "admin" },
  login: { path: "/login", requiresAuth: false },
  register: { path: "/register", requiresAuth: false },
}

interface RouteManagerContextType {
  navigate: (routeName: keyof typeof routes) => void
  isActiveRoute: (routeName: keyof typeof routes) => boolean
  canAccess: (routeName: keyof typeof routes) => boolean
}

const RouteManagerContext = createContext<RouteManagerContextType | undefined>(undefined)

export function useRouteManager() {
  const context = useContext(RouteManagerContext)
  if (context === undefined) {
    throw new Error("useRouteManager must be used within a RouteManager")
  }
  return context
}

interface RouteManagerProps {
  children: ReactNode
}

export function RouteManager({ children }: RouteManagerProps) {
  const router = useRouter()
  const pathname = usePathname()
  const { user, isAuthenticated } = useAuth()

  const navigate = useCallback(
    (routeName: keyof typeof routes) => {
      const route = routes[routeName]
      if (!route) {
        console.error(`Route "${routeName}" not found`)
        return
      }

      if (route.requiresAuth && !isAuthenticated) {
        router.push("/login")
        return
      }

      if (route.requiredRole && user?.role !== route.requiredRole) {
        router.push("/")
        return
      }

      router.push(route.path)
    },
    [router, isAuthenticated, user],
  )

  const isActiveRoute = useCallback(
    (routeName: keyof typeof routes) => {
      const route = routes[routeName]
      if (!route) return false

      return pathname === route.path
    },
    [pathname],
  )

  const canAccess = useCallback(
    (routeName: keyof typeof routes) => {
      const route = routes[routeName]
      if (!route) return false

      if (!route.requiresAuth) return true

      if (!isAuthenticated) return false

      if (route.requiredRole && user?.role !== route.requiredRole) return false

      return true
    },
    [isAuthenticated, user],
  )

  return (
    <RouteManagerContext.Provider value={{ navigate, isActiveRoute, canAccess }}>
      {children}
    </RouteManagerContext.Provider>
  )
}

