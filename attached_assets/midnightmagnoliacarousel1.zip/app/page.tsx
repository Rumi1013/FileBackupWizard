import { Navigation } from "@/components/navigation"
import { Footer } from "@/components/footer"
import { EnhancedHeroSlider } from "@/components/hero/enhanced-hero-slider"
import { SouthernGothicGallery } from "@/components/gallery/southern-gothic-gallery"
import { SocialMediaReviews } from "@/components/testimonials/social-media-reviews"
import { MidnightMagnoliaCarousel } from "@/components/carousel/midnight-magnolia-carousel"
import { NewsletterSignup } from "@/components/newsletter-signup"
import { AIAssistantChatV2 } from "@/components/chat/ai-assistant-chat-v2"
import Link from "next/link"
import { Button } from "@/components/ui/button"
import { FloatingMagnolia } from "@/components/floating-magnolia"

export default function HomePage() {
  return (
    <main className="min-h-screen bg-background">
      <Navigation />
      <EnhancedHeroSlider />
      <section className="py-16 md:py-24 container px-4">
        <div className="text-center mb-12">
          <h2 className="text-3xl md:text-4xl font-serif font-bold text-rich-gold mb-4">Our Journey</h2>
          <p className="text-lg text-foreground/80 max-w-2xl mx-auto font-lora">
            Explore the transformation story that birthed Midnight Magnolia.
          </p>
        </div>
        <MidnightMagnoliaCarousel />
      </section>
      <section className="py-16 md:py-24 bg-gradient-midnight relative overflow-hidden">
        <div className="absolute inset-0 bg-[url('/images/southern-gothic-1.jpeg')] bg-cover bg-center opacity-10" />
        <div className="absolute inset-0 bg-gradient-midnight opacity-90" />

        <div className="container relative z-10 px-4">
          <div className="text-center mb-16">
            <h2 className="text-3xl md:text-4xl font-serif font-bold text-rich-gold mb-4">Explore Our Offerings</h2>
            <p className="text-lg text-magnolia-white/80 max-w-2xl mx-auto font-lora">
              Discover our range of services, digital products, and insights designed to support your entrepreneurial
              journey.
            </p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-3 gap-8 max-w-5xl mx-auto">
            <div className="bg-midnight-blue/20 border border-rich-gold/20 rounded-lg p-6 hover:bg-midnight-blue/30 transition-colors">
              <h3 className="text-xl font-serif font-bold text-rich-gold mb-4">Services</h3>
              <p className="text-magnolia-white/80 font-lora mb-6">
                High-touch support and guidance tailored to your unique entrepreneurial journey.
              </p>
              <Link href="/services">
                <Button className="bg-rich-gold hover:bg-rich-gold/90 text-midnight-blue">Explore Services</Button>
              </Link>
            </div>

            <div className="bg-midnight-blue/20 border border-rich-gold/20 rounded-lg p-6 hover:bg-midnight-blue/30 transition-colors">
              <h3 className="text-xl font-serif font-bold text-rich-gold mb-4">Digital Products</h3>
              <p className="text-magnolia-white/80 font-lora mb-6">
                Self-paced digital tools designed to enhance your business systems and creative workflow.
              </p>
              <Link href="/digital-products">
                <Button className="bg-rich-gold hover:bg-rich-gold/90 text-midnight-blue">Browse Products</Button>
              </Link>
            </div>

            <div className="bg-midnight-blue/20 border border-rich-gold/20 rounded-lg p-6 hover:bg-midnight-blue/30 transition-colors">
              <h3 className="text-xl font-serif font-bold text-rich-gold mb-4">Blog</h3>
              <p className="text-magnolia-white/80 font-lora mb-6">
                Insights on neurodivergent entrepreneurship, digital product creation, and sustainable business
                practices.
              </p>
              <Link href="/blog">
                <Button className="bg-rich-gold hover:bg-rich-gold/90 text-midnight-blue">Read Articles</Button>
              </Link>
            </div>
          </div>
        </div>

        {/* Decorative elements */}
        <FloatingMagnolia size="sm" color="gold" className="top-1/4 right-[15%]" />
        <FloatingMagnolia size="md" color="white" className="bottom-1/4 left-[10%]" delay={1.2} />
      </section>
      <SouthernGothicGallery />
      <SocialMediaReviews />
      <NewsletterSignup />
      <Footer />
      <AIAssistantChatV2 />
    </main>
  )
}

