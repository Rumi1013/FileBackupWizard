import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { DockerComposeDiagram } from "@/components/diagrams/docker-compose-diagram"
import { DockerComposeViewer } from "@/components/code/docker-compose-viewer"

const DeploymentPage = () => {
  return (
    <div className="container mx-auto py-10">
      <h1 className="text-3xl font-playfair text-magnolia-white mb-6">Deployment Guide</h1>

      <Tabs defaultValue="overview" className="w-[90%] mx-auto">
        <TabsList>
          <TabsTrigger value="overview">Overview</TabsTrigger>
          <TabsTrigger value="setup">Setup</TabsTrigger>
          <TabsTrigger value="configuration">Configuration</TabsTrigger>
          <TabsTrigger value="troubleshooting">Troubleshooting</TabsTrigger>
        </TabsList>
        <TabsContent value="overview">
          <Card>
            <CardHeader>
              <CardTitle className="font-playfair text-2xl">Architecture Overview</CardTitle>
              <CardDescription className="font-lora">
                A high-level overview of the application architecture.
              </CardDescription>
            </CardHeader>
            <CardContent>
              <p className="font-lora">
                This application is designed with a microservices architecture, comprising of several independent
                services that communicate with each other.
              </p>
            </CardContent>
          </Card>
          <div className="mt-6">
            <DockerComposeDiagram />
          </div>
        </TabsContent>
        <TabsContent value="setup">
          <Card>
            <CardHeader>
              <CardTitle className="font-playfair text-2xl">Prerequisites</CardTitle>
              <CardDescription className="font-lora">Software and tools required before deployment.</CardDescription>
            </CardHeader>
            <CardContent>
              <ul className="list-disc list-inside font-lora">
                <li>Docker</li>
                <li>Docker Compose</li>
                <li>A cloud provider account (e.g., AWS, Google Cloud, Azure)</li>
              </ul>
            </CardContent>
          </Card>

          <Card className="mt-6">
            <CardHeader>
              <CardTitle className="font-playfair text-2xl">Configure Nginx</CardTitle>
              <CardDescription className="font-lora">Steps to configure Nginx as a reverse proxy.</CardDescription>
            </CardHeader>
            <CardContent>
              <p className="font-lora">Configure Nginx to route traffic to the appropriate backend services.</p>
            </CardContent>
          </Card>

          <div className="mt-6">
            <h3 className="font-playfair text-xl text-magnolia-white mb-3">Docker Compose Configuration</h3>
            <p className="font-lora mb-4">Here's the complete Docker Compose configuration:</p>
            <DockerComposeViewer />
          </div>
        </TabsContent>
        <TabsContent value="configuration">
          <Card>
            <CardHeader>
              <CardTitle className="font-playfair text-2xl">Environment Variables</CardTitle>
              <CardDescription className="font-lora">Configuration options for the application.</CardDescription>
            </CardHeader>
            <CardContent>
              <p className="font-lora">Configure environment variables to customize the application behavior.</p>
            </CardContent>
          </Card>
        </TabsContent>
        <TabsContent value="troubleshooting">
          <Card>
            <CardHeader>
              <CardTitle className="font-playfair text-2xl">Common Issues</CardTitle>
              <CardDescription className="font-lora">Solutions to common deployment problems.</CardDescription>
            </CardHeader>
            <CardContent>
              <p className="font-lora">Troubleshooting tips for common deployment issues.</p>
            </CardContent>
          </Card>
        </TabsContent>
      </Tabs>
    </div>
  )
}

export default DeploymentPage

