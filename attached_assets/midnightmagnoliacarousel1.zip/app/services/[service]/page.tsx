import { Navigation } from "@/components/navigation"
import { Footer } from "@/components/footer"
import { FloatingMagnolia } from "@/components/floating-magnolia"
import Image from "next/image"
import Link from "next/link"
import { Button } from "@/components/ui/button"
import { ArrowLeft, Check, Star } from "lucide-react"
import { Card, CardContent } from "@/components/ui/card"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"

export default function ServiceDetailPage({ params }: { params: { service: string } }) {
  // This would normally fetch the service data based on the slug
  const service = {
    id: 1,
    name: "Digital Product Mastery",
    description: "Create and launch digital products aligned with your unique gifts and expertise.",
    longDescription: `
      <p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Sed euismod, nisl vel ultricies lacinia, nisl nisl aliquam nisl, eu aliquam nisl nisl sit amet nisl. Sed euismod, nisl vel ultricies lacinia, nisl nisl aliquam nisl, eu aliquam nisl nisl sit amet nisl.</p>
      
      <p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Nullam in dui mauris. Vivamus hendrerit arcu sed erat molestie vehicula. Sed auctor neque eu tellus rhoncus ut eleifend nibh porttitor. Ut in nulla enim. Phasellus molestie magna non est bibendum non venenatis nisl tempor. Suspendisse dictum feugiat nisl ut dapibus.</p>
    `,
    price: "$1,997",
    image: "/placeholder.svg?height=600&width=600",
    duration: "8-week program",
    badge: "Signature Program",
    features: [
      "8-week guided program with neurodivergent-friendly pacing",
      "Templates and frameworks for creating, pricing, and launching",
      "Bi-weekly group coaching calls with personalized feedback",
      "Private community for ongoing support and accountability",
      "Lifetime access to course materials and future updates",
    ],
    curriculum: [
      {
        week: 1,
        title: "Foundation & Ideation",
        description: "Lorem ipsum dolor sit amet, consectetur adipiscing elit. Nullam in dui mauris.",
      },
      {
        week: 2,
        title: "Market Research & Validation",
        description: "Lorem ipsum dolor sit amet, consectetur adipiscing elit. Nullam in dui mauris.",
      },
      {
        week: 3,
        title: "Product Creation Framework",
        description: "Lorem ipsum dolor sit amet, consectetur adipiscing elit. Nullam in dui mauris.",
      },
      {
        week: 4,
        title: "Pricing & Positioning",
        description: "Lorem ipsum dolor sit amet, consectetur adipiscing elit. Nullam in dui mauris.",
      },
      {
        week: 5,
        title: "Launch Strategy",
        description: "Lorem ipsum dolor sit amet, consectetur adipiscing elit. Nullam in dui mauris.",
      },
      {
        week: 6,
        title: "Marketing & Promotion",
        description: "Lorem ipsum dolor sit amet, consectetur adipiscing elit. Nullam in dui mauris.",
      },
      {
        week: 7,
        title: "Sales Systems & Automation",
        description: "Lorem ipsum dolor sit amet, consectetur adipiscing elit. Nullam in dui mauris.",
      },
      {
        week: 8,
        title: "Scaling & Future Planning",
        description: "Lorem ipsum dolor sit amet, consectetur adipiscing elit. Nullam in dui mauris.",
      },
    ],
    testimonials: [
      {
        name: "Elena Martinez",
        role: "Digital Product Creator",
        quote:
          "The Digital Product Mastery program completely transformed my business. As someone with ADHD, I finally found a system that works with my brain instead of against it.",
        rating: 5,
      },
      {
        name: "Marcus Thompson",
        role: "Marketing Consultant",
        quote:
          "This program is unlike anything I've tried before. The templates and frameworks alone have helped me increase my revenue by 300% in just two months.",
        rating: 5,
      },
    ],
    relatedServices: [
      {
        id: 2,
        name: "Midnight Magnolia Membership",
        price: "$97/month",
        image: "/placeholder.svg?height=300&width=300",
      },
      {
        id: 3,
        name: "VIP Strategy Day",
        price: "$3,500",
        image: "/placeholder.svg?height=300&width=300",
      },
    ],
  }

  return (
    <main className="min-h-screen bg-background">
      <Navigation />

      {/* Service Detail Section */}
      <section className="relative pt-20 pb-16">
        <div className="container px-4">
          <Link href="/services" className="inline-flex items-center text-rich-gold hover:text-rich-gold/80 mb-6">
            <ArrowLeft className="h-4 w-4 mr-2" />
            Back to Services
          </Link>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-12">
            <div className="relative">
              <div className="relative aspect-square overflow-hidden rounded-lg bg-midnight-blue/20 border border-rich-gold/20">
                <Image
                  src={service.image || "/placeholder.svg"}
                  alt={service.name}
                  fill
                  className="object-contain p-4"
                />

                {service.badge && (
                  <div className="absolute top-4 right-4 bg-rich-gold text-midnight-blue text-xs font-bold px-3 py-1 rounded-full">
                    {service.badge}
                  </div>
                )}
              </div>
            </div>

            <div>
              <h1 className="text-3xl md:text-4xl font-serif font-bold text-rich-gold mb-4">{service.name}</h1>

              <p className="text-xl font-serif font-bold text-rich-gold mb-6">{service.price}</p>

              <p className="text-foreground/80 font-lora mb-6">{service.description}</p>

              <div className="space-y-4 mb-8">
                {service.features.map((feature, index) => (
                  <div key={index} className="flex items-start gap-2">
                    <Check className="h-5 w-5 text-rich-gold shrink-0 mt-0.5" />
                    <p className="text-foreground/80 font-lora">{feature}</p>
                  </div>
                ))}
              </div>

              <div className="space-y-2 text-sm text-foreground/60 mb-8">
                <p className="flex items-start gap-1">
                  <Check className="h-3 w-3 text-rich-gold shrink-0 mt-0.5" />
                  <span>{service.duration}</span>
                </p>
                <p className="flex items-start gap-1">
                  <Check className="h-3 w-3 text-rich-gold shrink-0 mt-0.5" />
                  <span>Payment plans available</span>
                </p>
                <p className="flex items-start gap-1">
                  <Check className="h-3 w-3 text-rich-gold shrink-0 mt-0.5" />
                  <span>Limited spots available each month</span>
                </p>
              </div>

              <Button size="lg" className="w-full bg-rich-gold hover:bg-rich-gold/90 text-midnight-blue mb-4">
                Apply Now
              </Button>

              <Button
                size="lg"
                variant="outline"
                className="w-full border-rich-gold text-rich-gold hover:bg-rich-gold/10"
              >
                Book a Discovery Call
              </Button>
            </div>
          </div>
        </div>
      </section>

      {/* Program Curriculum */}
      <section className="py-16 bg-gradient-midnight relative overflow-hidden">
        <div className="absolute inset-0 bg-[url('/images/southern-gothic-2.jpeg')] bg-cover bg-center opacity-10" />
        <div className="absolute inset-0 bg-gradient-midnight opacity-90" />

        <div className="container relative z-10 px-4">
          <div className="max-w-4xl mx-auto">
            <Tabs defaultValue="overview" className="w-full">
              <TabsList className="w-full grid grid-cols-2 mb-8 bg-midnight-blue/30">
                <TabsTrigger
                  value="overview"
                  className="data-[state=active]:bg-rich-gold/20 data-[state=active]:text-rich-gold"
                >
                  Program Overview
                </TabsTrigger>
                <TabsTrigger
                  value="curriculum"
                  className="data-[state=active]:bg-rich-gold/20 data-[state=active]:text-rich-gold"
                >
                  Curriculum
                </TabsTrigger>
              </TabsList>

              <TabsContent value="overview" className="mt-0">
                <div
                  className="prose prose-lg prose-invert max-w-none"
                  dangerouslySetInnerHTML={{ __html: service.longDescription }}
                />

                <div className="mt-12">
                  <h3 className="text-xl font-serif font-bold text-rich-gold mb-4">Who This Program Is For</h3>

                  <ul className="space-y-4">
                    <li className="flex items-start gap-2">
                      <Check className="h-5 w-5 text-rich-gold shrink-0 mt-0.5" />
                      <p className="text-magnolia-white/90 font-lora">
                        Neurodivergent entrepreneurs who want to create digital products
                      </p>
                    </li>
                    <li className="flex items-start gap-2">
                      <Check className="h-5 w-5 text-rich-gold shrink-0 mt-0.5" />
                      <p className="text-magnolia-white/90 font-lora">
                        Service providers looking to scale beyond trading time for money
                      </p>
                    </li>
                    <li className="flex items-start gap-2">
                      <Check className="h-5 w-5 text-rich-gold shrink-0 mt-0.5" />
                      <p className="text-magnolia-white/90 font-lora">
                        Creative entrepreneurs who want to monetize their expertise
                      </p>
                    </li>
                    <li className="flex items-start gap-2">
                      <Check className="h-5 w-5 text-rich-gold shrink-0 mt-0.5" />
                      <p className="text-magnolia-white/90 font-lora">
                        Business owners seeking to create passive income streams
                      </p>
                    </li>
                    <li className="flex items-start gap-2">
                      <Check className="h-5 w-5 text-rich-gold shrink-0 mt-0.5" />
                      <p className="text-magnolia-white/90 font-lora">
                        Anyone who has struggled with traditional business programs
                      </p>
                    </li>
                  </ul>
                </div>
              </TabsContent>

              <TabsContent value="curriculum" className="mt-0">
                <h3 className="text-xl font-serif font-bold text-rich-gold mb-6">8-Week Program Curriculum</h3>

                <div className="space-y-6">
                  {service.curriculum.map((week) => (
                    <div key={week.week} className="bg-midnight-blue/30 border border-rich-gold/20 rounded-lg p-4">
                      <h4 className="font-serif font-bold text-rich-gold mb-2">
                        Week {week.week}: {week.title}
                      </h4>
                      <p className="text-magnolia-white/90 font-lora">{week.description}</p>
                    </div>
                  ))}
                </div>
              </TabsContent>
            </Tabs>
          </div>
        </div>

        {/* Decorative elements */}
        <FloatingMagnolia size="sm" color="gold" className="top-1/4 right-[15%]" />
        <FloatingMagnolia size="md" color="white" className="bottom-1/4 left-[10%]" delay={1.2} />
      </section>

      {/* Testimonials */}
      <section className="py-16">
        <div className="container px-4">
          <h2 className="text-2xl md:text-3xl font-serif font-bold text-rich-gold mb-8 text-center">
            Client Success Stories
          </h2>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-8 max-w-4xl mx-auto">
            {service.testimonials.map((testimonial, index) => (
              <Card key={index} className="bg-midnight-blue/20 border-rich-gold/20">
                <CardContent className="pt-6">
                  <div className="flex items-center gap-4 mb-4">
                    <div className="w-12 h-12 rounded-full bg-rich-gold/20 flex items-center justify-center">
                      <span className="text-xl text-rich-gold">{testimonial.name.substring(0, 2)}</span>
                    </div>
                    <div>
                      <p className="font-serif font-bold text-rich-gold">{testimonial.name}</p>
                      <p className="text-sm text-foreground/60">{testimonial.role}</p>
                    </div>
                  </div>
                  <p className="text-foreground/80 font-lora italic mb-4">"{testimonial.quote}"</p>
                  <div className="flex gap-1">
                    {[...Array(testimonial.rating)].map((_, i) => (
                      <Star key={i} className="w-5 h-5 text-rich-gold fill-rich-gold" />
                    ))}
                  </div>
                </CardContent>
              </Card>
            ))}
          </div>
        </div>
      </section>

      {/* Related Services */}
      <section className="py-16 bg-gradient-midnight relative overflow-hidden">
        <div className="absolute inset-0 bg-[url('/images/southern-gothic-3.jpeg')] bg-cover bg-center opacity-10" />
        <div className="absolute inset-0 bg-gradient-midnight opacity-90" />

        <div className="container relative z-10 px-4">
          <h2 className="text-2xl md:text-3xl font-serif font-bold text-rich-gold mb-8 text-center">
            Related Services
          </h2>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-8 max-w-4xl mx-auto">
            {service.relatedServices.map((relatedService) => (
              <div
                key={relatedService.id}
                className="bg-midnight-blue/20 border border-rich-gold/20 rounded-lg overflow-hidden"
              >
                <div className="relative aspect-[4/3] overflow-hidden">
                  <Image
                    src={relatedService.image || "/placeholder.svg"}
                    alt={relatedService.name}
                    fill
                    className="object-cover"
                  />
                </div>
                <div className="p-4">
                  <h3 className="font-serif font-bold text-rich-gold mb-2">{relatedService.name}</h3>
                  <p className="text-foreground/80 font-serif mb-4">{relatedService.price}</p>
                  <Link href={`/services/${relatedService.id}`}>
                    <Button className="w-full bg-rich-gold hover:bg-rich-gold/90 text-midnight-blue">
                      View Details
                    </Button>
                  </Link>
                </div>
              </div>
            ))}
          </div>
        </div>

        {/* Decorative elements */}
        <FloatingMagnolia size="sm" color="gold" className="top-1/4 right-[15%]" />
        <FloatingMagnolia size="md" color="white" className="bottom-1/4 left-[10%]" delay={1.2} />
      </section>

      {/* CTA Section */}
      <section className="py-16">
        <div className="container px-4">
          <div className="max-w-3xl mx-auto text-center">
            <h2 className="text-2xl md:text-3xl font-serif font-bold text-rich-gold mb-4">
              Ready to Transform Your Business?
            </h2>
            <p className="text-lg text-foreground/80 font-lora mb-8">
              Join the Digital Product Mastery program and create sustainable income streams that honor your
              neurodivergent mind.
            </p>
            <div className="flex flex-col sm:flex-row gap-4 justify-center">
              <Button size="lg" className="bg-rich-gold hover:bg-rich-gold/90 text-midnight-blue">
                Apply Now
              </Button>
              <Button size="lg" variant="outline" className="border-rich-gold text-rich-gold hover:bg-rich-gold/10">
                Book a Discovery Call
              </Button>
            </div>
          </div>
        </div>
      </section>

      <Footer />
    </main>
  )
}

