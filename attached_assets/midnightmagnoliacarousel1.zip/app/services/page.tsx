import { Navigation } from "@/components/navigation"
import { Footer } from "@/components/footer"
import { FloatingMagnolia } from "@/components/floating-magnolia"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card"
import { Check } from "lucide-react"

export default function ServicesPage() {
  return (
    <main className="min-h-screen bg-background">
      <Navigation />

      {/* Hero Section */}
      <section className="relative pt-20 pb-16 overflow-hidden">
        <div className="absolute inset-0 bg-gradient-midnight opacity-95" />

        <div className="container relative z-10 px-4">
          <div className="max-w-4xl mx-auto text-center">
            <h1 className="text-4xl md:text-5xl lg:text-6xl font-serif font-bold text-rich-gold mb-6">
              Services & Offerings
            </h1>
            <p className="text-xl text-magnolia-white/90 font-lora italic mb-8">
              Transformative experiences designed for neurodivergent creatives and entrepreneurs seeking sustainable
              success.
            </p>
          </div>
        </div>

        {/* Decorative elements */}
        <FloatingMagnolia size="lg" color="gold" className="top-12 right-[10%]" />
        <FloatingMagnolia size="md" color="white" className="bottom-24 left-[15%]" delay={1.5} />
      </section>

      {/* Services Overview */}
      <section className="py-16 md:py-24">
        <div className="container px-4">
          <div className="text-center mb-16">
            <h2 className="text-3xl md:text-4xl font-serif font-bold text-rich-gold mb-4">Our Signature Offerings</h2>
            <p className="text-lg text-foreground/80 max-w-2xl mx-auto font-lora">
              Each service is designed with neurodivergent minds in mind, providing structure without rigidity and
              support without overwhelm.
            </p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
            {/* Digital Product Mastery */}
            <Card className="bg-midnight-blue/20 border-rich-gold/20 overflow-hidden">
              <div className="h-2 bg-rich-gold" />
              <CardHeader>
                <CardTitle className="text-rich-gold">Digital Product Mastery</CardTitle>
                <CardDescription className="font-lora">
                  Create and launch digital products aligned with your unique gifts
                </CardDescription>
              </CardHeader>
              <CardContent>
                <div className="space-y-4 mb-6">
                  <div className="flex items-start gap-2">
                    <Check className="h-5 w-5 text-rich-gold shrink-0 mt-0.5" />
                    <p className="text-foreground/80 font-lora">
                      8-week guided program with neurodivergent-friendly pacing
                    </p>
                  </div>
                  <div className="flex items-start gap-2">
                    <Check className="h-5 w-5 text-rich-gold shrink-0 mt-0.5" />
                    <p className="text-foreground/80 font-lora">
                      Templates and frameworks for creating, pricing, and launching
                    </p>
                  </div>
                  <div className="flex items-start gap-2">
                    <Check className="h-5 w-5 text-rich-gold shrink-0 mt-0.5" />
                    <p className="text-foreground/80 font-lora">
                      Bi-weekly group coaching calls with personalized feedback
                    </p>
                  </div>
                  <div className="flex items-start gap-2">
                    <Check className="h-5 w-5 text-rich-gold shrink-0 mt-0.5" />
                    <p className="text-foreground/80 font-lora">
                      Private community for ongoing support and accountability
                    </p>
                  </div>
                </div>
                <p className="text-2xl font-serif font-bold text-rich-gold">$1,997</p>
                <p className="text-sm text-foreground/60 font-lora">Payment plans available</p>
              </CardContent>
              <CardFooter>
                <Button className="w-full bg-rich-gold hover:bg-rich-gold/90 text-midnight-blue">Learn More</Button>
              </CardFooter>
            </Card>

            {/* Midnight Magnolia Membership */}
            <Card className="bg-midnight-blue/20 border-rich-gold/20 overflow-hidden relative">
              <div className="absolute top-6 right-6 bg-rich-gold text-midnight-blue text-xs font-bold px-2 py-1 rounded-full">
                Most Popular
              </div>
              <div className="h-2 bg-rich-gold" />
              <CardHeader>
                <CardTitle className="text-rich-gold">Midnight Magnolia Membership</CardTitle>
                <CardDescription className="font-lora">
                  Ongoing support for neurodivergent entrepreneurs
                </CardDescription>
              </CardHeader>
              <CardContent>
                <div className="space-y-4 mb-6">
                  <div className="flex items-start gap-2">
                    <Check className="h-5 w-5 text-rich-gold shrink-0 mt-0.5" />
                    <p className="text-foreground/80 font-lora">Monthly live coaching calls with Latisha</p>
                  </div>
                  <div className="flex items-start gap-2">
                    <Check className="h-5 w-5 text-rich-gold shrink-0 mt-0.5" />
                    <p className="text-foreground/80 font-lora">Access to all mini-courses and workshops</p>
                  </div>
                  <div className="flex items-start gap-2">
                    <Check className="h-5 w-5 text-rich-gold shrink-0 mt-0.5" />
                    <p className="text-foreground/80 font-lora">Private community of like-minded entrepreneurs</p>
                  </div>
                  <div className="flex items-start gap-2">
                    <Check className="h-5 w-5 text-rich-gold shrink-0 mt-0.5" />
                    <p className="text-foreground/80 font-lora">Quarterly planning sessions and implementation days</p>
                  </div>
                </div>
                <p className="text-2xl font-serif font-bold text-rich-gold">$97/month</p>
                <p className="text-sm text-foreground/60 font-lora">or $997 annually (save $167)</p>
              </CardContent>
              <CardFooter>
                <Button className="w-full bg-rich-gold hover:bg-rich-gold/90 text-midnight-blue">Join Now</Button>
              </CardFooter>
            </Card>

            {/* VIP Strategy Day */}
            <Card className="bg-midnight-blue/20 border-rich-gold/20 overflow-hidden">
              <div className="h-2 bg-rich-gold" />
              <CardHeader>
                <CardTitle className="text-rich-gold">VIP Strategy Day</CardTitle>
                <CardDescription className="font-lora">
                  Intensive 1:1 support to transform your business
                </CardDescription>
              </CardHeader>
              <CardContent>
                <div className="space-y-4 mb-6">
                  <div className="flex items-start gap-2">
                    <Check className="h-5 w-5 text-rich-gold shrink-0 mt-0.5" />
                    <p className="text-foreground/80 font-lora">6-hour virtual intensive with Latisha</p>
                  </div>
                  <div className="flex items-start gap-2">
                    <Check className="h-5 w-5 text-rich-gold shrink-0 mt-0.5" />
                    <p className="text-foreground/80 font-lora">Custom strategy tailored to your specific needs</p>
                  </div>
                  <div className="flex items-start gap-2">
                    <Check className="h-5 w-5 text-rich-gold shrink-0 mt-0.5" />
                    <p className="text-foreground/80 font-lora">30-day Voxer access for implementation support</p>
                  </div>
                  <div className="flex items-start gap-2">
                    <Check className="h-5 w-5 text-rich-gold shrink-0 mt-0.5" />
                    <p className="text-foreground/80 font-lora">Follow-up session 30 days after your intensive</p>
                  </div>
                </div>
                <p className="text-2xl font-serif font-bold text-rich-gold">$3,500</p>
                <p className="text-sm text-foreground/60 font-lora">Limited availability each month</p>
              </CardContent>
              <CardFooter>
                <Button className="w-full bg-rich-gold hover:bg-rich-gold/90 text-midnight-blue">Apply Now</Button>
              </CardFooter>
            </Card>
          </div>
        </div>
      </section>

      {/* Workshops & Events */}
      <section className="py-16 md:py-24 bg-gradient-midnight relative overflow-hidden">
        <div className="absolute inset-0 bg-[url('/images/southern-gothic-2.jpeg')] bg-cover bg-center opacity-10" />
        <div className="absolute inset-0 bg-gradient-midnight opacity-90" />

        <div className="container relative z-10 px-4">
          <div className="text-center mb-16">
            <h2 className="text-3xl md:text-4xl font-serif font-bold text-rich-gold mb-4">Workshops & Events</h2>
            <p className="text-lg text-magnolia-white/80 max-w-2xl mx-auto font-lora">
              Join us for transformative experiences designed to nurture your creative spirit and entrepreneurial
              journey.
            </p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
            <Card className="bg-midnight-blue/30 border-rich-gold/20 backdrop-blur-sm">
              <CardHeader>
                <CardTitle className="text-rich-gold">Neurodivergent Business Systems</CardTitle>
                <CardDescription className="font-lora text-magnolia-white/70">
                  Virtual Workshop • June 15, 2023
                </CardDescription>
              </CardHeader>
              <CardContent>
                <p className="text-magnolia-white/90 font-lora mb-4">
                  Learn how to create business systems that work with your neurodivergent brain instead of against it.
                  This workshop covers project management, client workflows, and content creation strategies
                  specifically designed for ADHD and autistic entrepreneurs.
                </p>
                <p className="text-xl font-serif font-bold text-rich-gold">$97</p>
              </CardContent>
              <CardFooter>
                <Button variant="outline" className="border-rich-gold text-rich-gold hover:bg-rich-gold/10">
                  Register Now
                </Button>
              </CardFooter>
            </Card>

            <Card className="bg-midnight-blue/30 border-rich-gold/20 backdrop-blur-sm">
              <CardHeader>
                <CardTitle className="text-rich-gold">Southern Gothic Retreat</CardTitle>
                <CardDescription className="font-lora text-magnolia-white/70">
                  In-Person • New Orleans • October 12-15, 2023
                </CardDescription>
              </CardHeader>
              <CardContent>
                <p className="text-magnolia-white/90 font-lora mb-4">
                  Join us for a transformative 4-day retreat in the heart of New Orleans. Immerse yourself in the magic
                  of the South while developing your business strategy, connecting with like-minded entrepreneurs, and
                  experiencing deep personal growth.
                </p>
                <p className="text-xl font-serif font-bold text-rich-gold">$2,497</p>
              </CardContent>
              <CardFooter>
                <Button variant="outline" className="border-rich-gold text-rich-gold hover:bg-rich-gold/10">
                  Join Waitlist
                </Button>
              </CardFooter>
            </Card>
          </div>
        </div>

        {/* Decorative elements */}
        <FloatingMagnolia size="sm" color="gold" className="top-1/4 right-[15%]" />
        <FloatingMagnolia size="md" color="white" className="bottom-1/4 left-[10%]" delay={1.2} />
      </section>

      {/* Testimonials */}
      <section className="py-16 md:py-24">
        <div className="container px-4">
          <div className="text-center mb-16">
            <h2 className="text-3xl md:text-4xl font-serif font-bold text-rich-gold mb-4">Client Transformations</h2>
            <p className="text-lg text-foreground/80 max-w-2xl mx-auto font-lora">
              Hear from entrepreneurs who have experienced the Midnight Magnolia approach.
            </p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
            <Card className="bg-midnight-blue/20 border-rich-gold/20">
              <CardContent className="pt-6">
                <div className="flex items-center gap-4 mb-4">
                  <div className="w-12 h-12 rounded-full bg-rich-gold/20 flex items-center justify-center">
                    <span className="text-xl text-rich-gold">JB</span>
                  </div>
                  <div>
                    <p className="font-serif font-bold text-rich-gold">Jasmine Brooks</p>
                    <p className="text-sm text-foreground/60">Digital Product Creator</p>
                  </div>
                </div>
                <p className="text-foreground/80 font-lora italic mb-4">
                  "As someone with ADHD, I've always struggled with traditional business advice. Latisha's approach
                  changed everything for me. The Digital Product Mastery program helped me create and launch my first
                  digital product that generated $12K in its first month. But more importantly, I did it in a way that
                  honored my neurodivergent brain."
                </p>
                <div className="flex gap-1">
                  {[...Array(5)].map((_, i) => (
                    <svg key={i} className="w-5 h-5 text-rich-gold" fill="currentColor" viewBox="0 0 20 20">
                      <path d="M9.049 2.927c.3-.921 1.603-.921 1.902 0l1.07 3.292a1 1 0 00.95.69h3.462c.969 0 1.371 1.24.588 1.81l-2.8 2.034a1 1 0 00-.364 1.118l1.07 3.292c.3.921-.755 1.688-1.54 1.118l-2.8-2.034a1 1 0 00-1.175 0l-2.8 2.034c-.784.57-1.838-.197-1.539-1.118l1.07-3.292a1 1 0 00-.364-1.118L2.98 8.72c-.783-.57-.38-1.81.588-1.81h3.461a1 1 0 00.951-.69l1.07-3.292z" />
                    </svg>
                  ))}
                </div>
              </CardContent>
            </Card>

            <Card className="bg-midnight-blue/20 border-rich-gold/20">
              <CardContent className="pt-6">
                <div className="flex items-center gap-4 mb-4">
                  <div className="w-12 h-12 rounded-full bg-rich-gold/20 flex items-center justify-center">
                    <span className="text-xl text-rich-gold">MT</span>
                  </div>
                  <div>
                    <p className="font-serif font-bold text-rich-gold">Marcus Thompson</p>
                    <p className="text-sm text-foreground/60">Creative Entrepreneur</p>
                  </div>
                </div>
                <p className="text-foreground/80 font-lora italic mb-4">
                  "The VIP Strategy Day with Latisha was transformative. She helped me see how my creative gifts could
                  be channeled into a sustainable business model. What sets Midnight Magnolia apart is the deep
                  understanding of both business strategy AND the unique challenges faced by neurodivergent
                  entrepreneurs. I've tripled my income while working fewer hours."
                </p>
                <div className="flex gap-1">
                  {[...Array(5)].map((_, i) => (
                    <svg key={i} className="w-5 h-5 text-rich-gold" fill="currentColor" viewBox="0 0 20 20">
                      <path d="M9.049 2.927c.3-.921 1.603-.921 1.902 0l1.07 3.292a1 1 0 00.95.69h3.462c.969 0 1.371 1.24.588 1.81l-2.8 2.034a1 1 0 00-.364 1.118l1.07 3.292c.3.921-.755 1.688-1.54 1.118l-2.8-2.034a1 1 0 00-1.175 0l-2.8 2.034c-.784.57-1.838-.197-1.539-1.118l1.07-3.292a1 1 0 00-.364-1.118L2.98 8.72c-.783-.57-.38-1.81.588-1.81h3.461a1 1 0 00.951-.69l1.07-3.292z" />
                    </svg>
                  ))}
                </div>
              </CardContent>
            </Card>
          </div>
        </div>
      </section>

      {/* CTA */}
      <section className="py-16 bg-gradient-midnight relative overflow-hidden">
        <div className="absolute inset-0 bg-[url('/images/southern-gothic-1.jpeg')] bg-cover bg-center opacity-10" />
        <div className="absolute inset-0 bg-gradient-midnight opacity-90" />

        <div className="container relative z-10 px-4 text-center">
          <h2 className="text-3xl md:text-4xl font-serif font-bold text-rich-gold mb-6">
            Ready to Transform Your Business?
          </h2>
          <p className="text-xl text-magnolia-white/90 font-lora max-w-2xl mx-auto mb-8">
            Schedule a complimentary discovery call to explore how Midnight Magnolia's services can support your unique
            entrepreneurial journey.
          </p>
          <Button size="lg" className="bg-rich-gold hover:bg-rich-gold/90 text-midnight-blue font-medium">
            Book Your Call
          </Button>
        </div>
      </section>

      <Footer />
    </main>
  )
}

