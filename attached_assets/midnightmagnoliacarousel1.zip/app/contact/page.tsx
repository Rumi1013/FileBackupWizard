import { Navigation } from "@/components/navigation"
import { Footer } from "@/components/footer"
import { FloatingMagnolia } from "@/components/floating-magnolia"
import { Button } from "@/components/ui/button"
import { Card, CardContent } from "@/components/ui/card"
import { Input } from "@/components/ui/input"
import { Textarea } from "@/components/ui/textarea"
import { Instagram, Facebook, Linkedin, Mail, MapPin, Phone } from "lucide-react"

export default function ContactPage() {
  return (
    <main className="min-h-screen bg-background">
      <Navigation />

      {/* Hero Section */}
      <section className="relative pt-20 pb-16 overflow-hidden">
        <div className="absolute inset-0 bg-gradient-midnight opacity-95" />

        <div className="container relative z-10 px-4">
          <div className="max-w-4xl mx-auto text-center">
            <h1 className="text-4xl md:text-5xl lg:text-6xl font-serif font-bold text-rich-gold mb-6">
              Connect With Us
            </h1>
            <p className="text-xl text-magnolia-white/90 font-lora italic mb-8">
              Reach out to explore how Midnight Magnolia can support your entrepreneurial journey.
            </p>
          </div>
        </div>

        {/* Decorative elements */}
        <FloatingMagnolia size="lg" color="gold" className="top-12 right-[10%]" />
        <FloatingMagnolia size="md" color="white" className="bottom-24 left-[15%]" delay={1.5} />
      </section>

      {/* Contact Form & Info */}
      <section className="py-16 md:py-24">
        <div className="container px-4">
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-12">
            <div>
              <h2 className="text-3xl font-serif font-bold text-rich-gold mb-6">Get in Touch</h2>
              <p className="text-foreground/80 font-lora mb-8">
                Have questions about our services or want to explore how we can work together? Fill out the form below
                and we'll get back to you within 48 hours.
              </p>

              <Card className="bg-midnight-blue/20 border-rich-gold/20">
                <CardContent className="p-6">
                  <form className="space-y-6">
                    <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                      <div className="space-y-2">
                        <label htmlFor="name" className="text-sm font-medium text-foreground/80">
                          Name
                        </label>
                        <Input
                          id="name"
                          placeholder="Your name"
                          className="bg-midnight-blue/30 border-rich-gold/20 text-foreground focus-visible:ring-rich-gold/50"
                          required
                        />
                      </div>
                      <div className="space-y-2">
                        <label htmlFor="email" className="text-sm font-medium text-foreground/80">
                          Email
                        </label>
                        <Input
                          id="email"
                          type="email"
                          placeholder="Your email"
                          className="bg-midnight-blue/30 border-rich-gold/20 text-foreground focus-visible:ring-rich-gold/50"
                          required
                        />
                      </div>
                    </div>

                    <div className="space-y-2">
                      <label htmlFor="subject" className="text-sm font-medium text-foreground/80">
                        Subject
                      </label>
                      <Input
                        id="subject"
                        placeholder="How can we help you?"
                        className="bg-midnight-blue/30 border-rich-gold/20 text-foreground focus-visible:ring-rich-gold/50"
                        required
                      />
                    </div>

                    <div className="space-y-2">
                      <label htmlFor="message" className="text-sm font-medium text-foreground/80">
                        Message
                      </label>
                      <Textarea
                        id="message"
                        placeholder="Tell us more about your inquiry..."
                        className="bg-midnight-blue/30 border-rich-gold/20 text-foreground focus-visible:ring-rich-gold/50 min-h-[150px]"
                        required
                      />
                    </div>

                    <Button type="submit" className="w-full bg-rich-gold hover:bg-rich-gold/90 text-midnight-blue">
                      Send Message
                    </Button>
                  </form>
                </CardContent>
              </Card>
            </div>

            <div>
              <h2 className="text-3xl font-serif font-bold text-rich-gold mb-6">Contact Information</h2>
              <p className="text-foreground/80 font-lora mb-8">
                Connect with us through various channels or schedule a discovery call to discuss your specific needs.
              </p>

              <div className="space-y-6">
                <Card className="bg-midnight-blue/20 border-rich-gold/20">
                  <CardContent className="p-6 flex items-start gap-4">
                    <div className="w-10 h-10 rounded-full bg-rich-gold/20 flex items-center justify-center shrink-0">
                      <Mail className="h-5 w-5 text-rich-gold" />
                    </div>
                    <div>
                      <h3 className="font-serif font-bold text-rich-gold mb-1">Email</h3>
                      <p className="text-foreground/80 font-lora">contact@midnightmagnolia.com</p>
                    </div>
                  </CardContent>
                </Card>

                <Card className="bg-midnight-blue/20 border-rich-gold/20">
                  <CardContent className="p-6 flex items-start gap-4">
                    <div className="w-10 h-10 rounded-full bg-rich-gold/20 flex items-center justify-center shrink-0">
                      <Phone className="h-5 w-5 text-rich-gold" />
                    </div>
                    <div>
                      <h3 className="font-serif font-bold text-rich-gold mb-1">Phone</h3>
                      <p className="text-foreground/80 font-lora">(555) 123-4567</p>
                      <p className="text-sm text-foreground/60">Monday-Friday, 9am-5pm CST</p>
                    </div>
                  </CardContent>
                </Card>

                <Card className="bg-midnight-blue/20 border-rich-gold/20">
                  <CardContent className="p-6 flex items-start gap-4">
                    <div className="w-10 h-10 rounded-full bg-rich-gold/20 flex items-center justify-center shrink-0">
                      <MapPin className="h-5 w-5 text-rich-gold" />
                    </div>
                    <div>
                      <h3 className="font-serif font-bold text-rich-gold mb-1">Location</h3>
                      <p className="text-foreground/80 font-lora">New Orleans, Louisiana</p>
                      <p className="text-sm text-foreground/60">Virtual services available worldwide</p>
                    </div>
                  </CardContent>
                </Card>

                <div className="mt-8">
                  <h3 className="font-serif font-bold text-rich-gold mb-4">Connect on Social Media</h3>
                  <div className="flex gap-4">
                    <a
                      href="https://www.instagram.com/rumi_nationz"
                      target="_blank"
                      rel="noopener noreferrer"
                      className="w-10 h-10 rounded-full bg-rich-gold/20 flex items-center justify-center text-rich-gold hover:bg-rich-gold/30 transition-colors"
                    >
                      <Instagram className="h-5 w-5" />
                      <span className="sr-only">Instagram</span>
                    </a>
                    <a
                      href="https://www.facebook.com/ruminationsshop"
                      target="_blank"
                      rel="noopener noreferrer"
                      className="w-10 h-10 rounded-full bg-rich-gold/20 flex items-center justify-center text-rich-gold hover:bg-rich-gold/30 transition-colors"
                    >
                      <Facebook className="h-5 w-5" />
                      <span className="sr-only">Facebook</span>
                    </a>
                    <a
                      href="https://www.linkedin.com/in/latishavwaters"
                      target="_blank"
                      rel="noopener noreferrer"
                      className="w-10 h-10 rounded-full bg-rich-gold/20 flex items-center justify-center text-rich-gold hover:bg-rich-gold/30 transition-colors"
                    >
                      <Linkedin className="h-5 w-5" />
                      <span className="sr-only">LinkedIn</span>
                    </a>
                  </div>
                </div>
              </div>

              <div className="mt-12">
                <Card className="bg-gradient-midnight border-rich-gold/20 overflow-hidden">
                  <CardContent className="p-6">
                    <h3 className="font-serif font-bold text-rich-gold mb-4">Schedule a Discovery Call</h3>
                    <p className="text-magnolia-white/90 font-lora mb-6">
                      Book a complimentary 30-minute discovery call to explore how we can support your entrepreneurial
                      journey.
                    </p>
                    <Button className="w-full bg-rich-gold hover:bg-rich-gold/90 text-midnight-blue">
                      Book Your Call
                    </Button>
                  </CardContent>
                </Card>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* FAQ Section */}
      <section className="py-16 bg-gradient-midnight relative overflow-hidden">
        <div className="absolute inset-0 bg-[url('/images/southern-gothic-2.jpeg')] bg-cover bg-center opacity-10" />
        <div className="absolute inset-0 bg-gradient-midnight opacity-90" />

        <div className="container relative z-10 px-4">
          <div className="text-center mb-16">
            <h2 className="text-3xl md:text-4xl font-serif font-bold text-rich-gold mb-4">
              Frequently Asked Questions
            </h2>
            <p className="text-lg text-magnolia-white/80 max-w-2xl mx-auto font-lora">
              Find answers to common questions about our services and approach.
            </p>
          </div>

          <div className="max-w-3xl mx-auto grid gap-6">
            <Card className="bg-midnight-blue/30 border-rich-gold/20 backdrop-blur-sm">
              <CardContent className="p-6">
                <h3 className="font-serif font-bold text-rich-gold mb-2">
                  How do your services accommodate neurodivergent entrepreneurs?
                </h3>
                <p className="text-magnolia-white/90 font-lora">
                  All our services are designed with neurodivergent minds in mind. We provide flexible pacing, multiple
                  formats for consuming information (written, audio, video), and systems that work with different
                  thinking styles rather than against them. Our approach honors both hyperfocus periods and the need for
                  rest.
                </p>
              </CardContent>
            </Card>

            <Card className="bg-midnight-blue/30 border-rich-gold/20 backdrop-blur-sm">
              <CardContent className="p-6">
                <h3 className="font-serif font-bold text-rich-gold mb-2">
                  What types of digital products do you help entrepreneurs create?
                </h3>
                <p className="text-magnolia-white/90 font-lora">
                  We support the creation of various digital products including online courses, membership sites,
                  digital downloads, templates, e-books, and coaching programs. Our focus is on helping you leverage
                  your unique expertise in a format that aligns with your strengths and serves your audience
                  effectively.
                </p>
              </CardContent>
            </Card>

            <Card className="bg-midnight-blue/30 border-rich-gold/20 backdrop-blur-sm">
              <CardContent className="p-6">
                <h3 className="font-serif font-bold text-rich-gold mb-2">
                  Do you offer payment plans for your programs?
                </h3>
                <p className="text-magnolia-white/90 font-lora">
                  Yes, we offer flexible payment plans for all our programs and services. We believe in making
                  transformative business support accessible and understand that cash flow can vary for entrepreneurs.
                  Details on payment options are provided during the enrollment process.
                </p>
              </CardContent>
            </Card>

            <Card className="bg-midnight-blue/30 border-rich-gold/20 backdrop-blur-sm">
              <CardContent className="p-6">
                <h3 className="font-serif font-bold text-rich-gold mb-2">
                  How long does it typically take to see results from your programs?
                </h3>
                <p className="text-magnolia-white/90 font-lora">
                  Results vary based on your starting point, implementation pace, and specific goals. Many clients see
                  significant shifts in their business approach within the first month, while revenue growth typically
                  becomes evident within 2-3 months. Our focus is on sustainable, long-term success rather than quick
                  fixes.
                </p>
              </CardContent>
            </Card>
          </div>
        </div>

        {/* Decorative elements */}
        <FloatingMagnolia size="sm" color="gold" className="top-1/4 right-[15%]" />
        <FloatingMagnolia size="md" color="white" className="bottom-1/4 left-[10%]" delay={1.2} />
      </section>

      <Footer />
    </main>
  )
}

