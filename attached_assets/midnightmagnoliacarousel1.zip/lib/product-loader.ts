// Product loader utility that provides progressive loading with clear visual feedback
export class ProductLoader {
  private loadingStates: Map<string, { isLoading: boolean; error: Error | null }>
  private loadingIndicators: Record<string, HTMLElement | null>
  private listeners: Map<string, Array<() => void>>

  constructor() {
    this.loadingStates = new Map()
    this.loadingIndicators = {}
    this.listeners = new Map()
  }

  // Register a DOM element as a loading indicator for a specific product
  registerIndicator(productId: string, element: HTMLElement | null) {
    this.loadingIndicators[productId] = element

    // Initialize loading state if it doesn't exist
    if (!this.loadingStates.has(productId)) {
      this.loadingStates.set(productId, { isLoading: false, error: null })
    }

    // Update UI to reflect current state
    this.updateUI(productId)
  }

  // Add a listener for loading state changes
  addListener(productId: string, callback: () => void) {
    if (!this.listeners.has(productId)) {
      this.listeners.set(productId, [])
    }

    this.listeners.get(productId)?.push(callback)
  }

  // Remove a listener
  removeListener(productId: string, callback: () => void) {
    if (!this.listeners.has(productId)) return

    const callbacks = this.listeners.get(productId) || []
    this.listeners.set(
      productId,
      callbacks.filter((cb) => cb !== callback),
    )
  }

  // Get the current loading state for a product
  getLoadingState(productId: string) {
    return this.loadingStates.get(productId) || { isLoading: false, error: null }
  }

  // Load a product by ID
  async loadProduct(productId: string) {
    this.setLoadingState(productId, true)

    try {
      // Simulate API call to product service
      const product = await this.fetchProduct(productId)
      this.setLoadingState(productId, false)
      return product
    } catch (error) {
      this.setLoadingState(productId, false, error as Error)
      throw error
    }
  }

  // Simulate fetching a product from an API
  private async fetchProduct(productId: string) {
    // In a real app, this would call your API
    return new Promise((resolve, reject) => {
      setTimeout(
        () => {
          // Simulate occasional errors for testing
          if (Math.random() < 0.05) {
            reject(new Error("Failed to load product. Please try again."))
            return
          }

          // Mock product data
          resolve({
            id: productId,
            title: `Product ${productId}`,
            price: 49.99 + Number(productId) * 10,
            image: `/placeholder.svg?height=400&width=400&text=Product+${productId}`,
            imageAlt: `Product ${productId} image`,
            shortDescription: "A beautiful digital product for creative entrepreneurs.",
            type: Math.random() > 0.5 ? "digital" : "physical",
            isNew: Math.random() > 0.7,
            slug: `product-${productId}`,
          })
        },
        800 + Math.random() * 1200,
      ) // Random delay between 800-2000ms
    })
  }

  // Update the loading state for a product
  private setLoadingState(productId: string, isLoading: boolean, error: Error | null = null) {
    this.loadingStates.set(productId, { isLoading, error })
    this.updateUI(productId)

    // Notify listeners
    const callbacks = this.listeners.get(productId) || []
    callbacks.forEach((callback) => callback())
  }

  // Update the UI to reflect the current loading state
  private updateUI(productId: string) {
    const state = this.loadingStates.get(productId)
    const indicator = this.loadingIndicators[productId]

    if (!indicator || !state) return

    if (state.isLoading) {
      indicator.setAttribute("aria-busy", "true")
      indicator.classList.add("mm-loading")
    } else {
      indicator.setAttribute("aria-busy", "false")
      indicator.classList.remove("mm-loading")

      if (state.error) {
        indicator.setAttribute("aria-live", "assertive")
        indicator.innerHTML = `<div class="mm-error">${state.error.message}</div>`
      }
    }
  }
}

// Create a singleton instance
export const productLoader = new ProductLoader()

// Helper function to add a product to cart
export async function addToCart(productId: string, quantity = 1) {
  try {
    // In a real app, this would call your API
    console.log(`Adding product ${productId} to cart (quantity: ${quantity})`)

    // Simulate API call
    await new Promise((resolve) => setTimeout(resolve, 500))

    // Return mock cart data
    return {
      id: "cart123",
      items: [{ productId, quantity }],
      subtotal: 49.99 * quantity,
    }
  } catch (error) {
    console.error("Failed to add product to cart:", error)
    throw error
  }
}

