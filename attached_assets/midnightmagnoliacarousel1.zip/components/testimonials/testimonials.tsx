"use client"

import { useState } from "react"
import { motion } from "framer-motion"
import { ChevronLeft, ChevronRight, Quote } from "lucide-react"
import { Button } from "@/components/ui/button"

const testimonials = [
  {
    id: 1,
    quote:
      "Midnight Magnolia transformed not just my business strategy, but my relationship with myself. The Southern Gothic elegance of their approach helped me reclaim my power in ways I never thought possible.",
    author: "Eliza Montgomery",
    role: "Founder, Crescent Collective",
  },
  {
    id: 2,
    quote:
      "Working with Midnight Magnolia was like watching the moon illuminate a path I couldn't see before. Their guidance helped me navigate the shadows of entrepreneurship with grace and resilience.",
    author: "Josephine Bennett",
    role: "Creative Director, Moss & Whisper",
  },
  {
    id: 3,
    quote:
      "There's a certain magic that happens when you allow yourself to be guided by someone who has walked through fire and emerged stronger. That's the Midnight Magnolia experience—transformative, empowering, and deeply rooted in authenticity.",
    author: "Camille Laurent",
    role: "CEO, Bayou Brilliance",
  },
]

export function Testimonials() {
  const [current, setCurrent] = useState(0)

  const nextTestimonial = () => {
    setCurrent((current) => (current === testimonials.length - 1 ? 0 : current + 1))
  }

  const prevTestimonial = () => {
    setCurrent((current) => (current === 0 ? testimonials.length - 1 : current - 1))
  }

  return (
    <div className="py-20 relative overflow-hidden">
      <div className="absolute inset-0 bg-gradient-midnight opacity-95" />

      {/* Decorative elements */}
      <div className="absolute top-0 left-0 right-0 h-px bg-gradient-to-r from-transparent via-rich-gold/30 to-transparent" />
      <div className="absolute bottom-0 left-0 right-0 h-px bg-gradient-to-r from-transparent via-rich-gold/30 to-transparent" />

      <div className="container relative z-10 px-4">
        <div className="max-w-4xl mx-auto">
          <div className="text-center mb-12">
            <h2 className="text-3xl md:text-4xl font-serif font-bold text-rich-gold mb-4">Voices of Transformation</h2>
            <p className="text-lg text-magnolia-white/80 max-w-2xl mx-auto font-lora">
              Stories from those who have journeyed through their own midnight to find their magnolia.
            </p>
          </div>

          <div className="relative">
            <motion.div
              key={current}
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              exit={{ opacity: 0, y: -20 }}
              transition={{ duration: 0.5 }}
              className="text-center px-4 py-8"
            >
              <Quote className="mx-auto h-12 w-12 text-rich-gold/40 mb-6" />

              <blockquote className="text-xl md:text-2xl text-magnolia-white font-lora italic mb-8">
                "{testimonials[current].quote}"
              </blockquote>

              <div className="flex flex-col items-center">
                <div className="w-12 h-1 bg-rich-gold/50 mb-4" />
                <p className="font-serif font-bold text-rich-gold">{testimonials[current].author}</p>
                <p className="text-magnolia-white/70">{testimonials[current].role}</p>
              </div>
            </motion.div>

            <div className="flex justify-center gap-4 mt-8">
              <Button
                variant="ghost"
                size="icon"
                onClick={prevTestimonial}
                className="rounded-full border border-rich-gold/30 text-rich-gold hover:bg-rich-gold/10"
                aria-label="Previous testimonial"
              >
                <ChevronLeft className="h-5 w-5" />
              </Button>

              <Button
                variant="ghost"
                size="icon"
                onClick={nextTestimonial}
                className="rounded-full border border-rich-gold/30 text-rich-gold hover:bg-rich-gold/10"
                aria-label="Next testimonial"
              >
                <ChevronRight className="h-5 w-5" />
              </Button>
            </div>
          </div>
        </div>
      </div>

      {/* Floating particles */}
      <div className="absolute inset-0 pointer-events-none">
        {Array.from({ length: 30 }).map((_, i) => (
          <motion.div
            key={i}
            className="absolute w-1 h-1 rounded-full bg-rich-gold/60"
            style={{
              left: `${Math.random() * 100}%`,
              top: `${Math.random() * 100}%`,
            }}
            animate={{
              opacity: [0.2, 0.6, 0.2],
              y: [0, -10, 0],
            }}
            transition={{
              duration: 4 + Math.random() * 4,
              repeat: Number.POSITIVE_INFINITY,
              delay: Math.random() * 5,
            }}
          />
        ))}
      </div>
    </div>
  )
}

