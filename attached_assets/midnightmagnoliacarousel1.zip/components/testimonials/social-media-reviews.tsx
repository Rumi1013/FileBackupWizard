"use client"

import { useState } from "react"
import { motion, AnimatePresence } from "framer-motion"
import { Instagram, Facebook, Twitter, MessageCircle, Heart } from "lucide-react"
import { Tabs, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar"
import { Card, CardContent } from "@/components/ui/card"

// Social media reviews data
const instagramReviews = [
  {
    id: 1,
    username: "creative_blackwoman",
    handle: "@creative_blackwoman",
    avatar: "/placeholder.svg?height=40&width=40",
    content:
      "Latisha's Midnight Magnolia workshop changed everything for me. As a fellow neurodivergent creative, seeing someone who understands the unique challenges we face was like finding water in a desert. Her approach to financial autonomy while honoring our creative process is revolutionary. 💫 #MidnightMagnolia #ADHDCreatives",
    likes: 124,
    comments: 18,
    timestamp: "2 days ago",
    platform: "instagram",
  },
  {
    id: 2,
    username: "southern_creative",
    handle: "@southern_creative",
    avatar: "/placeholder.svg?height=40&width=40",
    content:
      "The way @rumi_nationz talks about transformation isn't just inspirational—it's actionable. Her 'Eulogy for the Life I Survived' carousel had me in tears because I SAW MYSELF in her journey. Then her workshop gave me the tools to actually make changes. Forever grateful for this space she's created. 🌙✨ #MidnightMagnolia",
    likes: 89,
    comments: 7,
    timestamp: "1 week ago",
    platform: "instagram",
  },
  {
    id: 3,
    username: "digital_nomad_mama",
    handle: "@digital_nomad_mama",
    avatar: "/placeholder.svg?height=40&width=40",
    content:
      "I've followed Latisha's journey from her activism days to Midnight Magnolia, and watching her reclaim her power while creating space for others to do the same has been nothing short of magnificent. Her course on digital product creation helped me launch my first $5K month! 🌸 #RootedInResilience",
    likes: 156,
    comments: 23,
    timestamp: "3 weeks ago",
    platform: "instagram",
  },
]

const facebookReviews = [
  {
    id: 1,
    username: "Amara Johnson",
    handle: "",
    avatar: "/placeholder.svg?height=40&width=40",
    content:
      "I've been following Midnight Magnolia since the beginning, and what Latisha has created is truly special. As someone who also struggled with undiagnosed ADHD for years, her framework for building sustainable creative businesses that honor our neurodivergent needs has been life-changing. The community she's built feels like coming home. Thank you for creating this sanctuary for us!",
    likes: 47,
    comments: 5,
    timestamp: "Yesterday at 2:15 PM",
    platform: "facebook",
  },
  {
    id: 2,
    username: "Tiana Brooks",
    handle: "",
    avatar: "/placeholder.svg?height=40&width=40",
    content:
      "⭐⭐⭐⭐⭐ Midnight Magnolia's 'Digital Product Mastery' course was exactly what I needed. Latisha doesn't just teach strategy—she helps you build systems that work WITH your brain instead of against it. As a chronically ill entrepreneur, finding someone who understands the need for sustainable business practices has been invaluable. My Etsy shop is finally thriving without burning me out!",
    likes: 32,
    comments: 8,
    timestamp: "Last week",
    platform: "facebook",
  },
  {
    id: 3,
    username: "Jasmine Reynolds",
    handle: "",
    avatar: "/placeholder.svg?height=40&width=40",
    content:
      "The Midnight Magnolia community has become my business lifeline. What sets this apart from other entrepreneurial spaces is how Latisha centers rest, boundaries, and authentic expression. There's no hustle culture here—just genuine support for building businesses that honor our whole selves. The monthly coaching calls alone are worth the membership fee!",
    likes: 65,
    comments: 12,
    timestamp: "About a month ago",
    platform: "facebook",
  },
]

const twitterReviews = [
  {
    id: 1,
    username: "Maya Wilson",
    handle: "@maya_creates",
    avatar: "/placeholder.svg?height=40&width=40",
    content:
      "Taking @latishavwaters' Midnight Magnolia masterclass was the best investment I've made in my business this year. Finally, business advice that doesn't require me to mask my ADHD or work myself to exhaustion. My digital product launch exceeded my goals by 200%! 🌙✨",
    likes: 78,
    retweets: 12,
    timestamp: "10:24 AM · May 15, 2023",
    platform: "twitter",
  },
  {
    id: 2,
    username: "Creative Black Girl",
    handle: "@creativeblkgirl",
    avatar: "/placeholder.svg?height=40&width=40",
    content:
      "The way Midnight Magnolia @rumi_nationz approaches business strategy for neurodivergent creatives is revolutionary. No more shame, no more forcing ourselves into neurotypical boxes. Just sustainable systems that actually WORK for our brains. Game changer. 🧠💫",
    likes: 103,
    retweets: 24,
    timestamp: "2:15 PM · Apr 3, 2023",
    platform: "twitter",
  },
  {
    id: 3,
    username: "Digital Nomad Queen",
    handle: "@digitalnomadqueen",
    avatar: "/placeholder.svg?height=40&width=40",
    content:
      "Thread: How @latishavwaters and Midnight Magnolia helped me turn my creative passion into a 6-figure business while managing chronic illness...\n\nI never thought I could build a business that honored my health needs until I found MM's framework. Now I work 20 hrs/week and earn more than my old 60 hr/week job! 1/5",
    likes: 215,
    retweets: 43,
    timestamp: "9:30 AM · Mar 12, 2023",
    platform: "twitter",
  },
]

export function SocialMediaReviews() {
  const [activeTab, setActiveTab] = useState("instagram")

  const getReviews = () => {
    switch (activeTab) {
      case "instagram":
        return instagramReviews
      case "facebook":
        return facebookReviews
      case "twitter":
        return twitterReviews
      default:
        return instagramReviews
    }
  }

  const renderSocialIcon = (platform: string) => {
    switch (platform) {
      case "instagram":
        return <Instagram className="h-5 w-5 text-rich-gold" />
      case "facebook":
        return <Facebook className="h-5 w-5 text-rich-gold" />
      case "twitter":
        return <Twitter className="h-5 w-5 text-rich-gold" />
      default:
        return <MessageCircle className="h-5 w-5 text-rich-gold" />
    }
  }

  return (
    <div className="py-20 relative overflow-hidden">
      <div className="absolute inset-0 bg-gradient-to-b from-midnight-blue via-midnight-blue to-midnight-teal opacity-95" />

      {/* Decorative elements */}
      <div className="absolute top-0 left-0 right-0 h-px bg-gradient-to-r from-transparent via-rich-gold/30 to-transparent" />
      <div className="absolute bottom-0 left-0 right-0 h-px bg-gradient-to-r from-transparent via-rich-gold/30 to-transparent" />

      <div className="container relative z-10 px-4">
        <div className="max-w-4xl mx-auto">
          <div className="text-center mb-12">
            <h2 className="text-3xl md:text-4xl font-serif font-bold text-rich-gold mb-4">Community Voices</h2>
            <p className="text-lg text-magnolia-white/80 max-w-2xl mx-auto font-lora">
              Real stories from our community across social media, sharing how Midnight Magnolia has transformed their
              creative journeys.
            </p>
          </div>

          <Tabs defaultValue="instagram" value={activeTab} onValueChange={setActiveTab} className="w-full">
            <TabsList className="grid w-full grid-cols-3 mb-8 bg-midnight-teal/30">
              <TabsTrigger
                value="instagram"
                className="data-[state=active]:bg-rich-gold/20 data-[state=active]:text-rich-gold"
              >
                <Instagram className="h-4 w-4 mr-2" />
                Instagram
              </TabsTrigger>
              <TabsTrigger
                value="facebook"
                className="data-[state=active]:bg-rich-gold/20 data-[state=active]:text-rich-gold"
              >
                <Facebook className="h-4 w-4 mr-2" />
                Facebook
              </TabsTrigger>
              <TabsTrigger
                value="twitter"
                className="data-[state=active]:bg-rich-gold/20 data-[state=active]:text-rich-gold"
              >
                <Twitter className="h-4 w-4 mr-2" />
                Twitter
              </TabsTrigger>
            </TabsList>

            <AnimatePresence mode="wait">
              <motion.div
                key={activeTab}
                initial={{ opacity: 0, y: 10 }}
                animate={{ opacity: 1, y: 0 }}
                exit={{ opacity: 0, y: -10 }}
                transition={{ duration: 0.3 }}
              >
                <div className="grid gap-6">
                  {getReviews().map((review) => (
                    <Card
                      key={review.id}
                      className="bg-midnight-blue/50 border-rich-gold/20 backdrop-blur-sm overflow-hidden"
                    >
                      <CardContent className="p-6">
                        <div className="flex items-start gap-4">
                          <Avatar className="h-10 w-10 border-2 border-rich-gold/30">
                            <AvatarImage src={review.avatar} alt={review.username} />
                            <AvatarFallback className="bg-rich-gold/20 text-rich-gold">
                              {review.username.substring(0, 2).toUpperCase()}
                            </AvatarFallback>
                          </Avatar>

                          <div className="flex-1">
                            <div className="flex justify-between items-start">
                              <div>
                                <p className="font-medium text-magnolia-white">{review.username}</p>
                                {review.handle && <p className="text-sm text-magnolia-white/60">{review.handle}</p>}
                              </div>
                              {renderSocialIcon(review.platform)}
                            </div>

                            <div className="mt-3 text-magnolia-white/90 font-lora">{review.content}</div>

                            <div className="mt-4 flex items-center text-sm text-magnolia-white/60">
                              <div className="flex items-center mr-4">
                                <Heart className="h-4 w-4 mr-1" />
                                <span>{review.likes}</span>
                              </div>

                              {review.comments && (
                                <div className="flex items-center mr-4">
                                  <MessageCircle className="h-4 w-4 mr-1" />
                                  <span>{review.comments}</span>
                                </div>
                              )}

                              {review.retweets && (
                                <div className="flex items-center mr-4">
                                  <svg
                                    className="h-4 w-4 mr-1"
                                    viewBox="0 0 24 24"
                                    fill="none"
                                    xmlns="http://www.w3.org/2000/svg"
                                  >
                                    <path
                                      d="M7 17L17 7M17 7H8M17 7V16"
                                      stroke="currentColor"
                                      strokeWidth="2"
                                      strokeLinecap="round"
                                      strokeLinejoin="round"
                                    />
                                  </svg>
                                  <span>{review.retweets}</span>
                                </div>
                              )}

                              <span className="ml-auto">{review.timestamp}</span>
                            </div>
                          </div>
                        </div>
                      </CardContent>
                    </Card>
                  ))}
                </div>
              </motion.div>
            </AnimatePresence>

            <div className="mt-8 text-center">
              <p className="text-magnolia-white/70 font-lora italic">
                Join our community on{" "}
                <a
                  href="https://www.instagram.com/rumi_nationz"
                  target="_blank"
                  rel="noopener noreferrer"
                  className="text-rich-gold hover:underline"
                >
                  Instagram
                </a>
                ,{" "}
                <a
                  href="https://www.facebook.com/ruminationsshop"
                  target="_blank"
                  rel="noopener noreferrer"
                  className="text-rich-gold hover:underline"
                >
                  Facebook
                </a>
                , and{" "}
                <a
                  href="https://twitter.com"
                  target="_blank"
                  rel="noopener noreferrer"
                  className="text-rich-gold hover:underline"
                >
                  Twitter
                </a>{" "}
                to share your Midnight Magnolia journey.
              </p>
            </div>
          </Tabs>
        </div>
      </div>

      {/* Floating particles */}
      <div className="absolute inset-0 pointer-events-none">
        {Array.from({ length: 30 }).map((_, i) => (
          <motion.div
            key={i}
            className="absolute w-1 h-1 rounded-full bg-rich-gold/60"
            style={{
              left: `${Math.random() * 100}%`,
              top: `${Math.random() * 100}%`,
            }}
            animate={{
              opacity: [0.2, 0.6, 0.2],
              y: [0, -10, 0],
            }}
            transition={{
              duration: 4 + Math.random() * 4,
              repeat: Number.POSITIVE_INFINITY,
              delay: Math.random() * 5,
            }}
          />
        ))}
      </div>
    </div>
  )
}

