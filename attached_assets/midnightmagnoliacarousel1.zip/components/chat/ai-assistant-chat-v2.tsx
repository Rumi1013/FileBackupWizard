"use client"

import type React from "react"

import { useRef, useEffect } from "react"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardFooter, CardHeader } from "@/components/ui/card"
import { Input } from "@/components/ui/input"
import { Send, X, Minimize2, Maximize2, Bot, Sparkles } from "lucide-react"
import { motion, AnimatePresence } from "framer-motion"
import { FloatingMagnolia } from "@/components/floating-magnolia"
import { useAIAssistant } from "@/contexts/ai-assistant-context"

export function AIAssistantChatV2() {
  const {
    messages,
    isOpen,
    isMinimized,
    isLoading,
    isTyping,
    input,
    setInput,
    setIsOpen,
    setIsMinimized,
    sendMessage,
  } = useAIAssistant()

  const messagesEndRef = useRef<HTMLDivElement>(null)

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault()
    if (input.trim() && !isLoading && !isTyping) {
      await sendMessage(input)
    }
  }

  const scrollToBottom = () => {
    messagesEndRef.current?.scrollIntoView({ behavior: "smooth" })
  }

  useEffect(() => {
    if (isOpen && !isMinimized) {
      scrollToBottom()
    }
  }, [messages, isOpen, isMinimized])

  if (!isOpen) {
    return (
      <motion.div
        initial={{ scale: 0.8, opacity: 0 }}
        animate={{ scale: 1, opacity: 1 }}
        transition={{ duration: 0.3 }}
      >
        <Button
          onClick={() => setIsOpen(true)}
          className="fixed bottom-4 right-4 rounded-full w-14 h-14 bg-rich-gold hover:bg-rich-gold/90 text-midnight-blue shadow-lg flex items-center justify-center"
        >
          <span className="sr-only">Open AI Assistant</span>
          <Bot className="h-6 w-6" />
        </Button>
      </motion.div>
    )
  }

  return (
    <motion.div
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      exit={{ opacity: 0, y: 20 }}
      transition={{ duration: 0.3 }}
      className={`fixed bottom-4 right-4 z-50 w-full max-w-md transition-all duration-300 ease-in-out ${isMinimized ? "h-16" : "h-[32rem]"}`}
    >
      <Card className="h-full flex flex-col bg-midnight-blue border-rich-gold/20 shadow-xl relative overflow-hidden">
        {/* Background decorative elements */}
        <div className="absolute inset-0 pointer-events-none">
          <div className="absolute top-0 left-0 right-0 h-px bg-gradient-to-r from-transparent via-rich-gold/30 to-transparent" />
          <div className="absolute bottom-0 left-0 right-0 h-px bg-gradient-to-r from-transparent via-rich-gold/30 to-transparent" />
          <FloatingMagnolia size="sm" color="gold" className="top-1/4 right-[15%] opacity-20" />
          <FloatingMagnolia size="md" color="white" className="bottom-1/4 left-[10%] opacity-10" delay={1.2} />
        </div>

        <CardHeader className="p-4 border-b border-rich-gold/20 flex flex-row items-center justify-between bg-midnight-blue/80 backdrop-blur-sm z-10">
          <div className="flex items-center">
            <div className="w-8 h-8 rounded-full bg-rich-gold/20 flex items-center justify-center mr-2">
              <Sparkles className="h-4 w-4 text-rich-gold" />
            </div>
            <h3 className="font-serif font-bold text-rich-gold">Midnight Magnolia Assistant</h3>
          </div>
          <div className="flex items-center gap-1">
            {isMinimized ? (
              <Button
                variant="ghost"
                size="icon"
                onClick={() => setIsMinimized(false)}
                className="h-8 w-8 text-rich-gold hover:text-rich-gold/80 hover:bg-midnight-blue/50"
              >
                <Maximize2 className="h-4 w-4" />
                <span className="sr-only">Maximize</span>
              </Button>
            ) : (
              <Button
                variant="ghost"
                size="icon"
                onClick={() => setIsMinimized(true)}
                className="h-8 w-8 text-rich-gold hover:text-rich-gold/80 hover:bg-midnight-blue/50"
              >
                <Minimize2 className="h-4 w-4" />
                <span className="sr-only">Minimize</span>
              </Button>
            )}
            <Button
              variant="ghost"
              size="icon"
              onClick={() => setIsOpen(false)}
              className="h-8 w-8 text-rich-gold hover:text-rich-gold/80 hover:bg-midnight-blue/50"
            >
              <X className="h-4 w-4" />
              <span className="sr-only">Close</span>
            </Button>
          </div>
        </CardHeader>

        {!isMinimized && (
          <>
            <CardContent className="flex-1 overflow-y-auto p-4 space-y-4 z-10">
              <AnimatePresence initial={false}>
                {messages.map((message) => (
                  <motion.div
                    key={message.id}
                    initial={{ opacity: 0, y: 10 }}
                    animate={{ opacity: 1, y: 0 }}
                    exit={{ opacity: 0 }}
                    transition={{ duration: 0.3 }}
                    className={`flex ${message.role === "assistant" ? "justify-start" : "justify-end"}`}
                  >
                    <div
                      className={`max-w-[80%] rounded-lg p-3 ${
                        message.role === "assistant"
                          ? "bg-midnight-teal/50 border border-rich-gold/10 text-magnolia-white"
                          : "bg-rich-gold/10 border border-rich-gold/20 text-rich-gold"
                      }`}
                    >
                      <p className="font-lora">{message.content}</p>
                      <p className="text-xs opacity-70 mt-1">
                        {message.timestamp.toLocaleTimeString([], { hour: "2-digit", minute: "2-digit" })}
                      </p>
                    </div>
                  </motion.div>
                ))}
              </AnimatePresence>
              <div ref={messagesEndRef} />
            </CardContent>

            <CardFooter className="p-4 border-t border-rich-gold/20 bg-midnight-blue/80 backdrop-blur-sm z-10">
              <form onSubmit={handleSubmit} className="flex w-full gap-2">
                <Input
                  value={input}
                  onChange={(e) => setInput(e.target.value)}
                  placeholder="Ask about our services, products, or story..."
                  disabled={isLoading || isTyping}
                  className="flex-1 bg-midnight-blue/50 border-rich-gold/20 text-magnolia-white placeholder:text-magnolia-white/50 focus-visible:ring-rich-gold/30"
                />
                <Button
                  type="submit"
                  disabled={isLoading || isTyping || !input.trim()}
                  className="bg-rich-gold hover:bg-rich-gold/90 text-midnight-blue"
                >
                  <Send className="h-4 w-4" />
                  <span className="sr-only">Send</span>
                </Button>
              </form>
            </CardFooter>
          </>
        )}
      </Card>
    </motion.div>
  )
}

