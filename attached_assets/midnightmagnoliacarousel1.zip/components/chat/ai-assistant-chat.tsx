"use client"

import type React from "react"

import { useState, useRef, useEffect } from "react"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardFooter, CardHeader } from "@/components/ui/card"
import { Input } from "@/components/ui/input"
import { Send, X, Minimize2, Maximize2, Bot, Sparkles } from "lucide-react"
import { motion, AnimatePresence } from "framer-motion"
import { FloatingMagnolia } from "@/components/floating-magnolia"

interface Message {
  id: string
  role: "user" | "assistant"
  content: string
  timestamp: Date
}

// Predefined responses based on keywords
const predefinedResponses: Record<string, string[]> = {
  default: [
    "I'd be happy to help you with that! Is there anything specific you'd like to know about Midnight Magnolia?",
    "Thank you for reaching out. How can I assist you with your entrepreneurial journey today?",
    "I'm here to help you navigate Midnight Magnolia's offerings. What are you most interested in learning about?",
  ],
  services: [
    "Midnight Magnolia offers several signature services including Digital Product Mastery ($1,997), our Midnight Magnolia Membership ($97/month), and VIP Strategy Days ($3,500). Each is designed to support neurodivergent entrepreneurs at different stages of their journey. Would you like more details about any of these?",
    "Our services are designed specifically for neurodivergent entrepreneurs seeking sustainable success. From our 8-week Digital Product Mastery program to our VIP Strategy Days, we focus on creating systems that work with your unique brain wiring, not against it.",
    "Latisha's approach to services centers on honoring neurodivergent thinking as a creative advantage. Whether through our membership community or 1:1 support, we help you build business systems that support long-term success without burnout.",
  ],
  products: [
    "Our digital products include the Midnight Entrepreneur Planner ($49), Southern Digital Brand Kit ($79), and our bestselling Midnight Strategy Vault ($97). Each is designed with neurodivergent entrepreneurs in mind, featuring clear organization and flexible implementation options.",
    "Midnight Magnolia's digital products offer exceptional profit margins (85-98%) and can be created in just 2-7 days. From planners to template bundles, each product embodies our Southern Gothic aesthetic while providing practical business tools.",
    "Looking for passive income streams? Our digital products are designed to be both beautiful and functional, with the Midnight Entrepreneur Planner being our most popular offering for ADHD and neurodivergent business owners.",
  ],
  about: [
    "Midnight Magnolia was born from founder Latisha Vincent-Waters' personal journey through burnout, activism trauma, and her ADHD diagnosis at age 42. It represents a reclamation of creative and financial power that bridges Southern heritage with digital innovation.",
    "At Midnight Magnolia, we believe in the power of showing up as your full, unmasked self. Our approach honors neurodivergent thinking as a creative advantage, not a limitation, while embracing the elegant resilience of Southern Gothic aesthetics.",
    "Like the magnolia tree that blooms through adversity and stands strong against storms, Midnight Magnolia represents endurance and beauty through challenge. Our brand exists at the intersection of neurodivergent entrepreneurship, digital innovation, and Southern resilience.",
  ],
  blog: [
    "Our blog, Midnight Musings, features articles on neurodivergent entrepreneurship, digital product creation, and sustainable business practices. Our most popular post is 'The Neurodivergent Entrepreneur's Guide to Sustainable Success.'",
    "Latisha regularly shares insights on topics like building systems for ADHD entrepreneurs, creating high-margin digital products, and embracing rest as resistance against hustle culture on our Midnight Musings blog.",
    "The Midnight Magnolia blog explores the intersection of neurodivergence, entrepreneurship, and Southern Gothic aesthetics. Recent topics include 'From Burnout to Brilliance' and 'The Power of Diagnosis: How ADHD Changed My Business.'",
  ],
  pricing: [
    "Our digital products range from $37 for the Magnolia AI Prompt Collection to $97 for the comprehensive Midnight Strategy Vault. For services, we offer the Digital Product Mastery program at $1,997, monthly membership at $97/month, and VIP Strategy Days at $3,500.",
    "Midnight Magnolia offers options for various budgets, from self-paced digital products starting at $37 to high-touch services like our VIP Strategy Day at $3,500. Payment plans are available for all our programs.",
    "Investment in our signature Digital Product Mastery program is $1,997 with payment plans available. Our membership is $97/month or $997 annually (saving $167). Digital products range from $37-97 depending on complexity.",
  ],
  contact: [
    "You can reach us at contact@midnightmagnolia.com or schedule a complimentary discovery call through our website. We're also active on Instagram (@rumi_nationz) and Facebook (@ruminationsshop).",
    "The best way to connect with Latisha is to book a discovery call through our website or email contact@midnightmagnolia.com. We aim to respond to all inquiries within 48 hours.",
    "For questions about our services or products, please email contact@midnightmagnolia.com or use the contact form on our website. We're based in New Orleans, Louisiana, with virtual services available worldwide.",
  ],
}

export function AIAssistantChat() {
  const [messages, setMessages] = useState<Message[]>([
    {
      id: "1",
      role: "assistant",
      content:
        "Hello! I'm your Midnight Magnolia assistant. How can I help you navigate our Southern Gothic digital sanctuary today?",
      timestamp: new Date(),
    },
  ])
  const [input, setInput] = useState("")
  const [isOpen, setIsOpen] = useState(false)
  const [isMinimized, setIsMinimized] = useState(false)
  const [isLoading, setIsLoading] = useState(false)
  const [isTyping, setIsTyping] = useState(false)
  const messagesEndRef = useRef<HTMLDivElement>(null)

  const findRelevantResponse = (input: string): string => {
    const lowercaseInput = input.toLowerCase()

    // Check for keywords in the input
    for (const [category, responses] of Object.entries(predefinedResponses)) {
      if (category === "default") continue

      const keywords = {
        services: ["service", "program", "coaching", "membership", "vip", "strategy day", "mastery"],
        products: ["product", "digital product", "planner", "template", "vault", "brand kit", "journal"],
        about: ["about", "story", "latisha", "founder", "mission", "values", "history"],
        blog: ["blog", "article", "post", "content", "read", "midnight musings"],
        pricing: ["price", "cost", "fee", "payment", "invest", "afford", "expensive", "cheap"],
        contact: ["contact", "email", "phone", "reach", "message", "call", "schedule"],
      }

      if (keywords[category as keyof typeof keywords].some((keyword) => lowercaseInput.includes(keyword))) {
        return responses[Math.floor(Math.random() * responses.length)]
      }
    }

    // If no specific category matches, return a default response
    const defaultResponses = predefinedResponses.default
    return defaultResponses[Math.floor(Math.random() * defaultResponses.length)]
  }

  const simulateTyping = async (content: string) => {
    setIsTyping(true)

    // Add a temporary typing message
    const typingMessage: Message = {
      id: `typing-${Date.now()}`,
      role: "assistant",
      content: "...",
      timestamp: new Date(),
    }

    setMessages((prev) => [...prev, typingMessage])

    // Simulate typing delay based on message length
    const typingDelay = Math.min(1500, Math.max(800, content.length * 10))
    await new Promise((resolve) => setTimeout(resolve, typingDelay))

    // Remove typing indicator and add the actual message
    setMessages((prev) => prev.filter((msg) => msg.id !== typingMessage.id))
    setIsTyping(false)

    const assistantMessage: Message = {
      id: Date.now().toString(),
      role: "assistant",
      content: content,
      timestamp: new Date(),
    }

    setMessages((prev) => [...prev, assistantMessage])
  }

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault()
    if (input.trim() && !isLoading && !isTyping) {
      // Add user message
      const userMessage: Message = {
        id: Date.now().toString(),
        role: "user",
        content: input,
        timestamp: new Date(),
      }

      setMessages((prev) => [...prev, userMessage])
      setInput("")
      setIsLoading(true)

      try {
        // Find a relevant response based on the user's input
        const response = findRelevantResponse(input)

        // Simulate API call delay
        await new Promise((resolve) => setTimeout(resolve, 500))

        // Simulate typing
        await simulateTyping(response)
      } catch (error) {
        console.error("Error sending message to AI assistant:", error)

        // Add error message
        const errorMessage: Message = {
          id: Date.now().toString(),
          role: "assistant",
          content: "I apologize, but I encountered an error. Please try again later.",
          timestamp: new Date(),
        }

        setMessages((prev) => [...prev, errorMessage])
      } finally {
        setIsLoading(false)
      }
    }
  }

  const scrollToBottom = () => {
    messagesEndRef.current?.scrollIntoView({ behavior: "smooth" })
  }

  useEffect(() => {
    if (isOpen && !isMinimized) {
      scrollToBottom()
    }
  }, [messages, isOpen, isMinimized])

  if (!isOpen) {
    return (
      <motion.div
        initial={{ scale: 0.8, opacity: 0 }}
        animate={{ scale: 1, opacity: 1 }}
        transition={{ duration: 0.3 }}
      >
        <Button
          onClick={() => setIsOpen(true)}
          className="fixed bottom-4 right-4 rounded-full w-14 h-14 bg-rich-gold hover:bg-rich-gold/90 text-midnight-blue shadow-lg flex items-center justify-center"
        >
          <span className="sr-only">Open AI Assistant</span>
          <Bot className="h-6 w-6" />
        </Button>
      </motion.div>
    )
  }

  return (
    <motion.div
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      exit={{ opacity: 0, y: 20 }}
      transition={{ duration: 0.3 }}
      className={`fixed bottom-4 right-4 z-50 w-full max-w-md transition-all duration-300 ease-in-out ${isMinimized ? "h-16" : "h-[32rem]"}`}
    >
      <Card className="h-full flex flex-col bg-midnight-blue border-rich-gold/20 shadow-xl relative overflow-hidden">
        {/* Background decorative elements */}
        <div className="absolute inset-0 pointer-events-none">
          <div className="absolute top-0 left-0 right-0 h-px bg-gradient-to-r from-transparent via-rich-gold/30 to-transparent" />
          <div className="absolute bottom-0 left-0 right-0 h-px bg-gradient-to-r from-transparent via-rich-gold/30 to-transparent" />
          <FloatingMagnolia size="sm" color="gold" className="top-1/4 right-[15%] opacity-20" />
          <FloatingMagnolia size="md" color="white" className="bottom-1/4 left-[10%] opacity-10" delay={1.2} />
        </div>

        <CardHeader className="p-4 border-b border-rich-gold/20 flex flex-row items-center justify-between bg-midnight-blue/80 backdrop-blur-sm z-10">
          <div className="flex items-center">
            <div className="w-8 h-8 rounded-full bg-rich-gold/20 flex items-center justify-center mr-2">
              <Sparkles className="h-4 w-4 text-rich-gold" />
            </div>
            <h3 className="font-serif font-bold text-rich-gold">Midnight Magnolia Assistant</h3>
          </div>
          <div className="flex items-center gap-1">
            {isMinimized ? (
              <Button
                variant="ghost"
                size="icon"
                onClick={() => setIsMinimized(false)}
                className="h-8 w-8 text-rich-gold hover:text-rich-gold/80 hover:bg-midnight-blue/50"
              >
                <Maximize2 className="h-4 w-4" />
                <span className="sr-only">Maximize</span>
              </Button>
            ) : (
              <Button
                variant="ghost"
                size="icon"
                onClick={() => setIsMinimized(true)}
                className="h-8 w-8 text-rich-gold hover:text-rich-gold/80 hover:bg-midnight-blue/50"
              >
                <Minimize2 className="h-4 w-4" />
                <span className="sr-only">Minimize</span>
              </Button>
            )}
            <Button
              variant="ghost"
              size="icon"
              onClick={() => setIsOpen(false)}
              className="h-8 w-8 text-rich-gold hover:text-rich-gold/80 hover:bg-midnight-blue/50"
            >
              <X className="h-4 w-4" />
              <span className="sr-only">Close</span>
            </Button>
          </div>
        </CardHeader>

        {!isMinimized && (
          <>
            <CardContent className="flex-1 overflow-y-auto p-4 space-y-4 z-10">
              <AnimatePresence initial={false}>
                {messages.map((message) => (
                  <motion.div
                    key={message.id}
                    initial={{ opacity: 0, y: 10 }}
                    animate={{ opacity: 1, y: 0 }}
                    exit={{ opacity: 0 }}
                    transition={{ duration: 0.3 }}
                    className={`flex ${message.role === "assistant" ? "justify-start" : "justify-end"}`}
                  >
                    <div
                      className={`max-w-[80%] rounded-lg p-3 ${
                        message.role === "assistant"
                          ? "bg-midnight-teal/50 border border-rich-gold/10 text-magnolia-white"
                          : "bg-rich-gold/10 border border-rich-gold/20 text-rich-gold"
                      }`}
                    >
                      <p className="font-lora">{message.content}</p>
                      <p className="text-xs opacity-70 mt-1">
                        {message.timestamp.toLocaleTimeString([], { hour: "2-digit", minute: "2-digit" })}
                      </p>
                    </div>
                  </motion.div>
                ))}
              </AnimatePresence>
              <div ref={messagesEndRef} />
            </CardContent>

            <CardFooter className="p-4 border-t border-rich-gold/20 bg-midnight-blue/80 backdrop-blur-sm z-10">
              <form onSubmit={handleSubmit} className="flex w-full gap-2">
                <Input
                  value={input}
                  onChange={(e) => setInput(e.target.value)}
                  placeholder="Ask about our services, products, or story..."
                  disabled={isLoading || isTyping}
                  className="flex-1 bg-midnight-blue/50 border-rich-gold/20 text-magnolia-white placeholder:text-magnolia-white/50 focus-visible:ring-rich-gold/30"
                />
                <Button
                  type="submit"
                  disabled={isLoading || isTyping || !input.trim()}
                  className="bg-rich-gold hover:bg-rich-gold/90 text-midnight-blue"
                >
                  <Send className="h-4 w-4" />
                  <span className="sr-only">Send</span>
                </Button>
              </form>
            </CardFooter>
          </>
        )}
      </Card>
    </motion.div>
  )
}

