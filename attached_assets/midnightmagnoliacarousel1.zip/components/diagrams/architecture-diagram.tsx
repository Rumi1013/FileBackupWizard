"use client"

import { useEffect, useState } from "react"

export function ArchitectureDiagram() {
  const [mounted, setMounted] = useState(false)

  useEffect(() => {
    setMounted(true)
  }, [])

  if (!mounted) return null

  return (
    <div className="bg-midnight-blue/30 border border-rich-gold/20 rounded-lg p-8 overflow-hidden">
      <h2 className="text-2xl font-serif font-bold text-rich-gold mb-6 text-center">Midnight Magnolia Architecture</h2>

      <div className="relative w-full h-[500px] mx-auto">
        {/* Core Application */}
        <div className="absolute top-0 left-1/2 transform -translate-x-1/2 w-64 p-4 bg-midnight-teal/50 border border-rich-gold/30 rounded-lg text-center">
          <h3 className="text-lg font-serif font-bold text-rich-gold mb-2">Core Application</h3>
          <p className="text-sm text-magnolia-white/90">Error Handling, State Management, Authentication</p>
        </div>

        {/* Connecting line */}
        <div className="absolute top-[84px] left-1/2 transform -translate-x-1/2 w-1 h-16 bg-rich-gold/30"></div>

        {/* Middle layer */}
        <div className="absolute top-[100px] left-1/2 transform -translate-x-1/2 w-full flex justify-center space-x-4">
          <div className="w-48 p-3 bg-midnight-teal/50 border border-rich-gold/30 rounded-lg text-center">
            <h3 className="text-md font-serif font-bold text-rich-gold mb-1">UI Components</h3>
            <p className="text-xs text-magnolia-white/90">Navigation, Forms, Cards</p>
          </div>
          <div className="w-48 p-3 bg-midnight-teal/50 border border-rich-gold/30 rounded-lg text-center">
            <h3 className="text-md font-serif font-bold text-rich-gold mb-1">Data Services</h3>
            <p className="text-xs text-magnolia-white/90">API, Storage, Analytics</p>
          </div>
        </div>

        {/* Connecting lines */}
        <div className="absolute top-[164px] left-[calc(50%-72px)] transform -translate-x-1/2 w-1 h-16 bg-rich-gold/30"></div>
        <div className="absolute top-[164px] left-[calc(50%+72px)] transform -translate-x-1/2 w-1 h-16 bg-rich-gold/30"></div>

        {/* Bottom layer */}
        <div className="absolute top-[180px] left-1/2 transform -translate-x-1/2 w-full flex justify-center space-x-4">
          <div className="w-32 p-2 bg-midnight-teal/50 border border-rich-gold/30 rounded-lg text-center">
            <h3 className="text-sm font-serif font-bold text-rich-gold mb-1">Products</h3>
            <p className="text-xs text-magnolia-white/90">Digital Goods</p>
          </div>
          <div className="w-32 p-2 bg-midnight-teal/50 border border-rich-gold/30 rounded-lg text-center">
            <h3 className="text-sm font-serif font-bold text-rich-gold mb-1">Content</h3>
            <p className="text-xs text-magnolia-white/90">Blog, Media</p>
          </div>
          <div className="w-32 p-2 bg-midnight-teal/50 border border-rich-gold/30 rounded-lg text-center">
            <h3 className="text-sm font-serif font-bold text-rich-gold mb-1">Marketing</h3>
            <p className="text-xs text-magnolia-white/90">Campaigns</p>
          </div>
        </div>

        {/* Connecting lines */}
        <div className="absolute top-[244px] left-[calc(50%-104px)] transform -translate-x-1/2 w-1 h-16 bg-rich-gold/30"></div>
        <div className="absolute top-[244px] left-1/2 transform -translate-x-1/2 w-1 h-16 bg-rich-gold/30"></div>
        <div className="absolute top-[244px] left-[calc(50%+104px)] transform -translate-x-1/2 w-1 h-16 bg-rich-gold/30"></div>

        {/* Bottom layer */}
        <div className="absolute top-[260px] left-1/2 transform -translate-x-1/2 w-full flex justify-center space-x-3">
          <div className="w-24 p-2 bg-midnight-teal/50 border border-rich-gold/30 rounded-lg text-center">
            <h3 className="text-xs font-serif font-bold text-rich-gold mb-1">Shop</h3>
            <p className="text-xs text-magnolia-white/90">E-commerce</p>
          </div>
          <div className="w-24 p-2 bg-midnight-teal/50 border border-rich-gold/30 rounded-lg text-center">
            <h3 className="text-xs font-serif font-bold text-rich-gold mb-1">Blog</h3>
            <p className="text-xs text-magnolia-white/90">Articles</p>
          </div>
          <div className="w-24 p-2 bg-midnight-teal/50 border border-rich-gold/30 rounded-lg text-center">
            <h3 className="text-xs font-serif font-bold text-rich-gold mb-1">Gallery</h3>
            <p className="text-xs text-magnolia-white/90">Portfolio</p>
          </div>
          <div className="w-24 p-2 bg-midnight-teal/50 border border-rich-gold/30 rounded-lg text-center">
            <h3 className="text-xs font-serif font-bold text-rich-gold mb-1">Services</h3>
            <p className="text-xs text-magnolia-white/90">Offerings</p>
          </div>
        </div>

        {/* AI Assistant */}
        <div className="absolute bottom-0 right-0 w-48 p-3 bg-rich-gold/20 border border-rich-gold/40 rounded-lg text-center">
          <h3 className="text-md font-serif font-bold text-rich-gold mb-1">AI Assistant</h3>
          <p className="text-xs text-magnolia-white/90">Interactive Support</p>
        </div>

        {/* Connecting line to AI */}
        <div className="absolute bottom-[60px] right-[24px] w-16 h-1 bg-rich-gold/30"></div>
      </div>
    </div>
  )
}

