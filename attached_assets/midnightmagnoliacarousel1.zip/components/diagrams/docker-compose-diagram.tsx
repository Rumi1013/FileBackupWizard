"use client"

import { useEffect, useState } from "react"

export function DockerComposeDiagram() {
  const [isClient, setIsClient] = useState(false)

  useEffect(() => {
    setIsClient(true)
  }, [])

  if (!isClient) return null

  return (
    <div className="w-full overflow-x-auto py-8">
      <div className="min-w-[800px]">
        <div className="relative bg-midnight-blue/50 border border-rich-gold/20 rounded-lg p-8">
          <h3 className="font-playfair text-2xl text-rich-gold mb-6 text-center">Midnight Magnolia Architecture</h3>

          {/* External User */}
          <div className="absolute top-4 left-1/2 -translate-x-1/2 flex flex-col items-center">
            <div className="w-16 h-16 rounded-full bg-rich-gold/10 border border-rich-gold/30 flex items-center justify-center mb-2">
              <svg
                className="w-8 h-8 text-rich-gold"
                viewBox="0 0 24 24"
                fill="none"
                xmlns="http://www.w3.org/2000/svg"
              >
                <path
                  d="M12 11C14.2091 11 16 9.20914 16 7C16 4.79086 14.2091 3 12 3C9.79086 3 8 4.79086 8 7C8 9.20914 9.79086 11 12 11Z"
                  stroke="currentColor"
                  strokeWidth="2"
                  strokeLinecap="round"
                  strokeLinejoin="round"
                />
                <path
                  d="M12 14C8.13401 14 5 17.134 5 21H19C19 17.134 15.866 14 12 14Z"
                  stroke="currentColor"
                  strokeWidth="2"
                  strokeLinecap="round"
                  strokeLinejoin="round"
                />
              </svg>
            </div>
            <span className="font-lora text-magnolia-white text-sm">User</span>
          </div>

          {/* Container Grid */}
          <div className="mt-24 grid grid-cols-3 gap-6">
            {/* Nginx Container */}
            <div className="col-span-3 bg-midnight-teal/30 border border-rich-gold/20 rounded-lg p-4 relative">
              <div className="absolute -top-3 left-4 bg-rich-gold/90 text-midnight-blue px-2 py-1 rounded text-xs font-montserrat font-semibold">
                nginx
              </div>
              <div className="flex items-center justify-center h-16">
                <svg
                  className="w-12 h-12 text-rich-gold/70"
                  viewBox="0 0 24 24"
                  fill="none"
                  xmlns="http://www.w3.org/2000/svg"
                >
                  <path
                    d="M12 2L2 7L12 12L22 7L12 2Z"
                    stroke="currentColor"
                    strokeWidth="2"
                    strokeLinecap="round"
                    strokeLinejoin="round"
                  />
                  <path
                    d="M2 17L12 22L22 17"
                    stroke="currentColor"
                    strokeWidth="2"
                    strokeLinecap="round"
                    strokeLinejoin="round"
                  />
                  <path
                    d="M2 12L12 17L22 12"
                    stroke="currentColor"
                    strokeWidth="2"
                    strokeLinecap="round"
                    strokeLinejoin="round"
                  />
                </svg>
                <div className="ml-4">
                  <h4 className="font-playfair text-lg text-rich-gold">Nginx</h4>
                  <p className="font-lora text-sm text-magnolia-white/70">Reverse Proxy & SSL Termination</p>
                </div>
              </div>

              {/* Certbot Container */}
              <div className="absolute -right-3 top-1/2 -translate-y-1/2 bg-midnight-teal/50 border border-rich-gold/20 rounded-lg p-2">
                <div className="absolute -top-2 left-1/2 -translate-x-1/2 bg-rich-gold/90 text-midnight-blue px-2 py-0.5 rounded text-xs font-montserrat font-semibold whitespace-nowrap">
                  certbot
                </div>
                <svg
                  className="w-8 h-8 text-rich-gold/70"
                  viewBox="0 0 24 24"
                  fill="none"
                  xmlns="http://www.w3.org/2000/svg"
                >
                  <path
                    d="M12 22C17.5228 22 22 17.5228 22 12C22 6.47715 17.5228 2 12 2C6.47715 2 2 6.47715 2 12C2 17.5228 6.47715 22 12 22Z"
                    stroke="currentColor"
                    strokeWidth="2"
                    strokeLinecap="round"
                    strokeLinejoin="round"
                  />
                  <path
                    d="M12 16V12"
                    stroke="currentColor"
                    strokeWidth="2"
                    strokeLinecap="round"
                    strokeLinejoin="round"
                  />
                  <path
                    d="M12 8H12.01"
                    stroke="currentColor"
                    strokeWidth="2"
                    strokeLinecap="round"
                    strokeLinejoin="round"
                  />
                </svg>
              </div>
            </div>

            {/* Frontend Container */}
            <div className="bg-midnight-teal/30 border border-rich-gold/20 rounded-lg p-4 relative">
              <div className="absolute -top-3 left-4 bg-rich-gold/90 text-midnight-blue px-2 py-1 rounded text-xs font-montserrat font-semibold">
                frontend
              </div>
              <div className="flex flex-col items-center justify-center h-32">
                <svg
                  className="w-12 h-12 text-rich-gold/70 mb-2"
                  viewBox="0 0 24 24"
                  fill="none"
                  xmlns="http://www.w3.org/2000/svg"
                >
                  <path
                    d="M12 2L2 7L12 12L22 7L12 2Z"
                    stroke="currentColor"
                    strokeWidth="2"
                    strokeLinecap="round"
                    strokeLinejoin="round"
                  />
                  <path
                    d="M2 17L12 22L22 17"
                    stroke="currentColor"
                    strokeWidth="2"
                    strokeLinecap="round"
                    strokeLinejoin="round"
                  />
                  <path
                    d="M2 12L12 17L22 12"
                    stroke="currentColor"
                    strokeWidth="2"
                    strokeLinecap="round"
                    strokeLinejoin="round"
                  />
                </svg>
                <h4 className="font-playfair text-lg text-rich-gold">Next.js Frontend</h4>
                <p className="font-lora text-sm text-magnolia-white/70 text-center">
                  User Interface & Client-Side Logic
                </p>
              </div>
            </div>

            {/* API Container */}
            <div className="bg-midnight-teal/30 border border-rich-gold/20 rounded-lg p-4 relative">
              <div className="absolute -top-3 left-4 bg-rich-gold/90 text-midnight-blue px-2 py-1 rounded text-xs font-montserrat font-semibold">
                api
              </div>
              <div className="flex flex-col items-center justify-center h-32">
                <svg
                  className="w-12 h-12 text-rich-gold/70 mb-2"
                  viewBox="0 0 24 24"
                  fill="none"
                  xmlns="http://www.w3.org/2000/svg"
                >
                  <path
                    d="M20 14.66V20C20 20.5304 19.7893 21.0391 19.4142 21.4142C19.0391 21.7893 18.5304 22 18 22H4C3.46957 22 2.96086 21.7893 2.58579 21.4142C2.21071 21.0391 2 20.5304 2 20V6C2 5.46957 2.21071 4.96086 2.58579 4.58579C2.96086 4.21071 3.46957 4 4 4H9.34"
                    stroke="currentColor"
                    strokeWidth="2"
                    strokeLinecap="round"
                    strokeLinejoin="round"
                  />
                  <path
                    d="M16 2L22 8L12 18H6V12L16 2Z"
                    stroke="currentColor"
                    strokeWidth="2"
                    strokeLinecap="round"
                    strokeLinejoin="round"
                  />
                </svg>
                <h4 className="font-playfair text-lg text-rich-gold">Express API</h4>
                <p className="font-lora text-sm text-magnolia-white/70 text-center">Business Logic & Data Processing</p>
              </div>
            </div>

            {/* Database & Redis Container */}
            <div className="bg-midnight-teal/30 border border-rich-gold/20 rounded-lg p-4 relative">
              <div className="absolute -top-3 left-4 bg-rich-gold/90 text-midnight-blue px-2 py-1 rounded text-xs font-montserrat font-semibold">
                db & redis
              </div>
              <div className="flex flex-col items-center justify-center h-32">
                <div className="flex space-x-6">
                  <div className="flex flex-col items-center">
                    <svg
                      className="w-10 h-10 text-rich-gold/70 mb-2"
                      viewBox="0 0 24 24"
                      fill="none"
                      xmlns="http://www.w3.org/2000/svg"
                    >
                      <path
                        d="M21 5C21 6.65685 16.9706 8 12 8C7.02944 8 3 6.65685 3 5"
                        stroke="currentColor"
                        strokeWidth="2"
                        strokeLinecap="round"
                        strokeLinejoin="round"
                      />
                      <path
                        d="M3 5V19C3 20.6569 7.02944 22 12 22C16.9706 22 21 20.6569 21 19V5"
                        stroke="currentColor"
                        strokeWidth="2"
                        strokeLinecap="round"
                        strokeLinejoin="round"
                      />
                      <path
                        d="M3 12C3 13.6569 7.02944 15 12 15C16.9706 15 21 13.6569 21 12"
                        stroke="currentColor"
                        strokeWidth="2"
                        strokeLinecap="round"
                        strokeLinejoin="round"
                      />
                    </svg>
                    <span className="font-lora text-sm text-magnolia-white/70">PostgreSQL</span>
                  </div>
                  <div className="flex flex-col items-center">
                    <svg
                      className="w-10 h-10 text-rich-gold/70 mb-2"
                      viewBox="0 0 24 24"
                      fill="none"
                      xmlns="http://www.w3.org/2000/svg"
                    >
                      <path
                        d="M12 3L20 7.5V16.5L12 21L4 16.5V7.5L12 3Z"
                        stroke="currentColor"
                        strokeWidth="2"
                        strokeLinecap="round"
                        strokeLinejoin="round"
                      />
                      <path
                        d="M12 12L20 7.5"
                        stroke="currentColor"
                        strokeWidth="2"
                        strokeLinecap="round"
                        strokeLinejoin="round"
                      />
                      <path
                        d="M12 12V21"
                        stroke="currentColor"
                        strokeWidth="2"
                        strokeLinecap="round"
                        strokeLinejoin="round"
                      />
                      <path
                        d="M12 12L4 7.5"
                        stroke="currentColor"
                        strokeWidth="2"
                        strokeLinecap="round"
                        strokeLinejoin="round"
                      />
                    </svg>
                    <span className="font-lora text-sm text-magnolia-white/70">Redis</span>
                  </div>
                </div>
                <h4 className="font-playfair text-lg text-rich-gold mt-2">Data Storage</h4>
              </div>
            </div>
          </div>

          {/* Connection Lines */}
          <svg className="absolute inset-0 w-full h-full pointer-events-none" xmlns="http://www.w3.org/2000/svg">
            {/* User to Nginx */}
            <path d="M400,40 L400,100" stroke="#D4AF37" strokeWidth="2" strokeDasharray="4" />

            {/* Nginx to Frontend */}
            <path d="M200,180 L200,230" stroke="#D4AF37" strokeWidth="2" strokeDasharray="4" />

            {/* Nginx to API */}
            <path d="M400,180 L400,230" stroke="#D4AF37" strokeWidth="2" strokeDasharray="4" />

            {/* API to Database */}
            <path d="M400,330 L400,380" stroke="#D4AF37" strokeWidth="2" strokeDasharray="4" />

            {/* Frontend to API */}
            <path d="M250,280 L350,280" stroke="#D4AF37" strokeWidth="2" strokeDasharray="4" />
          </svg>

          {/* Volume Indicators */}
          <div className="mt-6 flex justify-center space-x-8">
            <div className="flex items-center">
              <div className="w-4 h-4 rounded-full bg-rich-gold/30 border border-rich-gold/50 mr-2"></div>
              <span className="font-lora text-sm text-magnolia-white/70">postgres-data</span>
            </div>
            <div className="flex items-center">
              <div className="w-4 h-4 rounded-full bg-rich-gold/30 border border-rich-gold/50 mr-2"></div>
              <span className="font-lora text-sm text-magnolia-white/70">redis-data</span>
            </div>
            <div className="flex items-center">
              <div className="w-4 h-4 rounded-full bg-rich-gold/30 border border-rich-gold/50 mr-2"></div>
              <span className="font-lora text-sm text-magnolia-white/70">certbot-data</span>
            </div>
          </div>
        </div>
      </div>
    </div>
  )
}

