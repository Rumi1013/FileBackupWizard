"use client"

import { useState, useEffect } from "react"
import { motion, AnimatePresence } from "framer-motion"
import { ChevronLeft, ChevronRight, ExternalLink } from "lucide-react"
import { Button } from "@/components/ui/button"
import { FloatingMagnolia } from "@/components/floating-magnolia"
import Image from "next/image"
import Link from "next/link"

// Define the project type
interface Project {
  id: string
  title: string
  category: "web" | "brand" | "digital"
  image: string
  link: string
}

// Sample project data
const projectsData: Project[] = [
  {
    id: "1",
    title: "Southern Heritage Website",
    category: "web",
    image: "/placeholder.svg?height=500&width=800",
    link: "/projects/southern-heritage",
  },
  {
    id: "2",
    title: "Magnolia Brand System",
    category: "brand",
    image: "/placeholder.svg?height=500&width=800",
    link: "/projects/magnolia-brand",
  },
  {
    id: "3",
    title: "Digital Entrepreneur Planner",
    category: "digital",
    image: "/placeholder.svg?height=500&width=800",
    link: "/projects/entrepreneur-planner",
  },
  {
    id: "4",
    title: "Crescent Moon E-commerce",
    category: "web",
    image: "/placeholder.svg?height=500&width=800",
    link: "/projects/crescent-ecommerce",
  },
  {
    id: "5",
    title: "Southern Gothic Identity",
    category: "brand",
    image: "/placeholder.svg?height=500&width=800",
    link: "/projects/gothic-identity",
  },
  {
    id: "6",
    title: "Neurodivergent Business Templates",
    category: "digital",
    image: "/placeholder.svg?height=500&width=800",
    link: "/projects/business-templates",
  },
  {
    id: "7",
    title: "Bayou Wellness Platform",
    category: "web",
    image: "/placeholder.svg?height=500&width=800",
    link: "/projects/bayou-wellness",
  },
  {
    id: "8",
    title: "Midnight Strategy Vault",
    category: "digital",
    image: "/placeholder.svg?height=500&width=800",
    link: "/projects/strategy-vault",
  },
  {
    id: "9",
    title: "Magnolia Bloom Photography",
    category: "brand",
    image: "/placeholder.svg?height=500&width=800",
    link: "/projects/bloom-photography",
  },
]

// Number of projects per page
const PROJECTS_PER_PAGE = 6

export function PortfolioGallery() {
  // State for active filter
  const [activeFilter, setActiveFilter] = useState<string>("all")

  // State for current page
  const [currentPage, setCurrentPage] = useState(1)

  // State for filtered projects
  const [filteredProjects, setFilteredProjects] = useState<Project[]>(projectsData)

  // State for pagination
  const [totalPages, setTotalPages] = useState(Math.ceil(projectsData.length / PROJECTS_PER_PAGE))

  // State for visible projects (after pagination)
  const [visibleProjects, setVisibleProjects] = useState<Project[]>([])

  // State for animation when filter changes
  const [isAnimating, setIsAnimating] = useState(false)

  // Handle filter change
  const handleFilterChange = (filter: string) => {
    if (filter === activeFilter) return

    setIsAnimating(true)
    setTimeout(() => {
      setActiveFilter(filter)
      setCurrentPage(1)
      setIsAnimating(false)
    }, 300)
  }

  // Update filtered projects when active filter changes
  useEffect(() => {
    let filtered = projectsData

    if (activeFilter !== "all") {
      filtered = projectsData.filter((project) => project.category === activeFilter)
    }

    setFilteredProjects(filtered)
    setTotalPages(Math.ceil(filtered.length / PROJECTS_PER_PAGE))
  }, [activeFilter])

  // Update visible projects when filtered projects or current page changes
  useEffect(() => {
    const startIndex = (currentPage - 1) * PROJECTS_PER_PAGE
    const endIndex = startIndex + PROJECTS_PER_PAGE
    setVisibleProjects(filteredProjects.slice(startIndex, endIndex))
  }, [filteredProjects, currentPage])

  // Handle pagination
  const handlePageChange = (page: number) => {
    if (page < 1 || page > totalPages) return
    setCurrentPage(page)

    // Scroll to top of gallery
    document.getElementById("portfolio-gallery")?.scrollIntoView({ behavior: "smooth" })
  }

  return (
    <div id="portfolio-gallery" className="py-16 md:py-24 relative overflow-hidden">
      <div className="absolute inset-0 bg-gradient-to-b from-midnight-blue to-midnight-teal opacity-95" />

      {/* Decorative elements */}
      <FloatingMagnolia size="lg" color="gold" className="absolute top-12 right-[10%] opacity-30" />
      <FloatingMagnolia size="md" color="white" className="absolute bottom-24 left-[15%] opacity-20" delay={1.5} />

      <div className="container relative z-10 px-4">
        <div className="text-center mb-12">
          <h2 className="text-3xl md:text-4xl font-serif font-bold text-rich-gold mb-4">Our Portfolio</h2>
          <p className="text-lg text-magnolia-white/80 max-w-2xl mx-auto font-lora">
            Explore our collection of projects showcasing Southern Gothic elegance paired with digital innovation.
          </p>
        </div>

        {/* Filter Buttons */}
        <div className="flex justify-center flex-wrap gap-3 mb-12" role="tablist" aria-label="Portfolio filters">
          <Button
            variant={activeFilter === "all" ? "default" : "outline"}
            className={`font-sans text-sm font-medium tracking-wide uppercase ${
              activeFilter === "all"
                ? "bg-rich-gold hover:bg-rich-gold/90 text-midnight-blue"
                : "border-rich-gold/50 text-rich-gold hover:bg-rich-gold/10"
            }`}
            onClick={() => handleFilterChange("all")}
            aria-selected={activeFilter === "all"}
            role="tab"
          >
            All Projects
          </Button>
          <Button
            variant={activeFilter === "web" ? "default" : "outline"}
            className={`font-sans text-sm font-medium tracking-wide uppercase ${
              activeFilter === "web"
                ? "bg-rich-gold hover:bg-rich-gold/90 text-midnight-blue"
                : "border-rich-gold/50 text-rich-gold hover:bg-rich-gold/10"
            }`}
            onClick={() => handleFilterChange("web")}
            aria-selected={activeFilter === "web"}
            role="tab"
          >
            Web Design
          </Button>
          <Button
            variant={activeFilter === "brand" ? "default" : "outline"}
            className={`font-sans text-sm font-medium tracking-wide uppercase ${
              activeFilter === "brand"
                ? "bg-rich-gold hover:bg-rich-gold/90 text-midnight-blue"
                : "border-rich-gold/50 text-rich-gold hover:bg-rich-gold/10"
            }`}
            onClick={() => handleFilterChange("brand")}
            aria-selected={activeFilter === "brand"}
            role="tab"
          >
            Brand Identity
          </Button>
          <Button
            variant={activeFilter === "digital" ? "default" : "outline"}
            className={`font-sans text-sm font-medium tracking-wide uppercase ${
              activeFilter === "digital"
                ? "bg-rich-gold hover:bg-rich-gold/90 text-midnight-blue"
                : "border-rich-gold/50 text-rich-gold hover:bg-rich-gold/10"
            }`}
            onClick={() => handleFilterChange("digital")}
            aria-selected={activeFilter === "digital"}
            role="tab"
          >
            Digital Products
          </Button>
        </div>

        {/* Project Grid */}
        <div role="tabpanel" aria-label={`${activeFilter} projects`}>
          <AnimatePresence mode="wait">
            <motion.div
              key={activeFilter + currentPage}
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              exit={{ opacity: 0, y: -20 }}
              transition={{ duration: 0.4 }}
              className={`grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6 md:gap-8 ${isAnimating ? "opacity-0" : ""}`}
            >
              {visibleProjects.map((project) => (
                <ProjectCard key={project.id} project={project} />
              ))}
            </motion.div>
          </AnimatePresence>
        </div>

        {/* Pagination */}
        {totalPages > 1 && (
          <div className="flex justify-center items-center mt-12" role="navigation" aria-label="Pagination">
            <Button
              variant="outline"
              size="icon"
              className="rounded-full border-rich-gold/50 text-rich-gold hover:bg-rich-gold/10 mr-4"
              onClick={() => handlePageChange(currentPage - 1)}
              disabled={currentPage === 1}
              aria-label="Previous page"
            >
              <ChevronLeft className="h-5 w-5" />
            </Button>

            <div className="flex gap-2">
              {Array.from({ length: totalPages }, (_, i) => i + 1).map((page) => (
                <Button
                  key={page}
                  variant={page === currentPage ? "default" : "outline"}
                  size="icon"
                  className={`w-8 h-8 rounded-full ${
                    page === currentPage
                      ? "bg-rich-gold text-midnight-blue"
                      : "border-rich-gold/50 text-magnolia-white hover:bg-rich-gold/10"
                  }`}
                  onClick={() => handlePageChange(page)}
                  aria-label={`Page ${page}`}
                  aria-current={page === currentPage ? "page" : undefined}
                >
                  {page}
                </Button>
              ))}
            </div>

            <Button
              variant="outline"
              size="icon"
              className="rounded-full border-rich-gold/50 text-rich-gold hover:bg-rich-gold/10 ml-4"
              onClick={() => handlePageChange(currentPage + 1)}
              disabled={currentPage === totalPages}
              aria-label="Next page"
            >
              <ChevronRight className="h-5 w-5" />
            </Button>
          </div>
        )}
      </div>
    </div>
  )
}

// Project Card Component
function ProjectCard({ project }: { project: Project }) {
  return (
    <motion.div
      whileHover={{ y: -5 }}
      className="bg-midnight-blue/50 border border-rich-gold/20 rounded-lg overflow-hidden transition-all duration-300 hover:border-rich-gold/60 hover:shadow-[0_10px_20px_rgba(0,0,0,0.1)]"
    >
      <div className="relative h-64 overflow-hidden">
        <Image
          src={project.image || "/placeholder.svg"}
          alt={project.title}
          fill
          className="object-cover transition-transform duration-500 hover:scale-105"
        />

        <div className="absolute inset-0 bg-midnight-blue/70 opacity-0 hover:opacity-100 transition-opacity duration-300 flex items-center justify-center">
          <motion.div initial={{ opacity: 0, y: 20 }} whileHover={{ opacity: 1, y: 0 }} transition={{ duration: 0.3 }}>
            <Link
              href={project.link}
              className="w-10 h-10 rounded-full bg-rich-gold text-midnight-blue flex items-center justify-center"
              aria-label={`View ${project.title} project details`}
            >
              <ExternalLink className="h-5 w-5" />
            </Link>
          </motion.div>
        </div>
      </div>

      <div className="p-5">
        <h3 className="font-serif text-lg font-bold text-magnolia-white mb-1">{project.title}</h3>
        <p className="font-sans text-xs uppercase tracking-wider text-rich-gold">
          {project.category === "web" && "Web Design"}
          {project.category === "brand" && "Brand Identity"}
          {project.category === "digital" && "Digital Product"}
        </p>
      </div>
    </motion.div>
  )
}

