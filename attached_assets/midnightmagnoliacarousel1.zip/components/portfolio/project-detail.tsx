"use client"

import { useState } from "react"
import Image from "next/image"
import Link from "next/link"
import { motion } from "framer-motion"
import { ArrowLeft, ExternalLink, Calendar, User, Tag } from "lucide-react"
import { Button } from "@/components/ui/button"
import { FloatingMagnolia } from "@/components/floating-magnolia"

interface ProjectDetailProps {
  project: {
    title: string
    category: string
    date: string
    client: string
    description: string
    challenge: string
    solution: string
    result: string
    technologies: string[]
    mainImage: string
    galleryImages: string[]
    link?: string
  }
}

export function ProjectDetail({ project }: ProjectDetailProps) {
  const [selectedImage, setSelectedImage] = useState<string | null>(null)

  return (
    <div className="py-16 md:py-24 relative overflow-hidden">
      <div className="absolute inset-0 bg-gradient-to-b from-midnight-blue to-midnight-teal opacity-95" />

      {/* Decorative elements */}
      <FloatingMagnolia size="lg" color="gold" className="absolute top-12 right-[10%] opacity-30" />
      <FloatingMagnolia size="md" color="white" className="absolute bottom-24 left-[15%] opacity-20" delay={1.5} />

      <div className="container relative z-10 px-4">
        <Link href="/portfolio" className="inline-flex items-center text-rich-gold hover:text-rich-gold/80 mb-8">
          <ArrowLeft className="h-4 w-4 mr-2" />
          Back to Portfolio
        </Link>

        <div className="grid grid-cols-1 lg:grid-cols-2 gap-12 mb-16">
          <div>
            <div className="relative aspect-[4/3] rounded-lg overflow-hidden mb-6">
              <Image src={project.mainImage || "/placeholder.svg"} alt={project.title} fill className="object-cover" />
            </div>

            <div className="grid grid-cols-3 gap-3">
              {project.galleryImages.slice(0, 3).map((image, index) => (
                <div
                  key={index}
                  className="relative aspect-square rounded-lg overflow-hidden cursor-pointer"
                  onClick={() => setSelectedImage(image)}
                >
                  <Image
                    src={image || "/placeholder.svg"}
                    alt={`${project.title} gallery image ${index + 1}`}
                    fill
                    className="object-cover hover:scale-105 transition-transform duration-300"
                  />
                </div>
              ))}
            </div>
          </div>

          <div>
            <h1 className="text-3xl md:text-4xl font-serif font-bold text-rich-gold mb-4">{project.title}</h1>

            <div className="flex flex-wrap gap-4 mb-6">
              <div className="flex items-center text-magnolia-white/70">
                <Calendar className="h-4 w-4 mr-2 text-rich-gold" />
                <span>{project.date}</span>
              </div>
              <div className="flex items-center text-magnolia-white/70">
                <User className="h-4 w-4 mr-2 text-rich-gold" />
                <span>{project.client}</span>
              </div>
              <div className="flex items-center text-magnolia-white/70">
                <Tag className="h-4 w-4 mr-2 text-rich-gold" />
                <span>{project.category}</span>
              </div>
            </div>

            <div className="prose prose-invert max-w-none mb-8">
              <p className="text-magnolia-white/90 font-lora">{project.description}</p>
            </div>

            {project.link && (
              <Button className="bg-rich-gold hover:bg-rich-gold/90 text-midnight-blue">
                <ExternalLink className="h-4 w-4 mr-2" />
                Visit Project
              </Button>
            )}
          </div>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-3 gap-8 mb-16">
          <div className="bg-midnight-blue/30 border border-rich-gold/20 rounded-lg p-6">
            <h2 className="text-xl font-serif font-bold text-rich-gold mb-4">The Challenge</h2>
            <p className="text-magnolia-white/80 font-lora">{project.challenge}</p>
          </div>

          <div className="bg-midnight-blue/30 border border-rich-gold/20 rounded-lg p-6">
            <h2 className="text-xl font-serif font-bold text-rich-gold mb-4">The Solution</h2>
            <p className="text-magnolia-white/80 font-lora">{project.solution}</p>
          </div>

          <div className="bg-midnight-blue/30 border border-rich-gold/20 rounded-lg p-6">
            <h2 className="text-xl font-serif font-bold text-rich-gold mb-4">The Result</h2>
            <p className="text-magnolia-white/80 font-lora">{project.result}</p>
          </div>
        </div>

        <div className="mb-16">
          <h2 className="text-2xl font-serif font-bold text-rich-gold mb-6">Technologies Used</h2>
          <div className="flex flex-wrap gap-3">
            {project.technologies.map((tech, index) => (
              <span
                key={index}
                className="px-3 py-1 bg-rich-gold/10 border border-rich-gold/30 rounded-full text-rich-gold text-sm"
              >
                {tech}
              </span>
            ))}
          </div>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
          {project.galleryImages.slice(3).map((image, index) => (
            <div
              key={index}
              className="relative aspect-square rounded-lg overflow-hidden cursor-pointer"
              onClick={() => setSelectedImage(image)}
            >
              <Image
                src={image || "/placeholder.svg"}
                alt={`${project.title} gallery image ${index + 4}`}
                fill
                className="object-cover hover:scale-105 transition-transform duration-300"
              />
            </div>
          ))}
        </div>
      </div>

      {/* Lightbox */}
      {selectedImage && (
        <div
          className="fixed inset-0 z-50 bg-midnight-blue/95 flex items-center justify-center p-4"
          onClick={() => setSelectedImage(null)}
        >
          <motion.div
            initial={{ opacity: 0, scale: 0.9 }}
            animate={{ opacity: 1, scale: 1 }}
            exit={{ opacity: 0, scale: 0.9 }}
            className="relative max-w-5xl max-h-[90vh] w-full"
            onClick={(e) => e.stopPropagation()}
          >
            <div className="relative aspect-[16/9] w-full">
              <Image src={selectedImage || "/placeholder.svg"} alt="Project image" fill className="object-contain" />
            </div>

            <button
              className="absolute top-4 right-4 text-magnolia-white hover:text-rich-gold"
              onClick={() => setSelectedImage(null)}
              aria-label="Close lightbox"
            >
              <svg width="24" height="24" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
                <path
                  d="M18 6L6 18"
                  stroke="currentColor"
                  strokeWidth="2"
                  strokeLinecap="round"
                  strokeLinejoin="round"
                />
                <path
                  d="M6 6L18 18"
                  stroke="currentColor"
                  strokeWidth="2"
                  strokeLinecap="round"
                  strokeLinejoin="round"
                />
              </svg>
            </button>
          </motion.div>
        </div>
      )}
    </div>
  )
}

