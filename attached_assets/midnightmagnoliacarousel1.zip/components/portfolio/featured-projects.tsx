"use client"

import { motion } from "framer-motion"
import { ExternalLink } from "lucide-react"
import { Button } from "@/components/ui/button"
import Image from "next/image"
import Link from "next/link"

// Define the project type
interface Project {
  id: string
  title: string
  category: "web" | "brand" | "digital"
  image: string
  link: string
}

// Sample featured projects
const featuredProjects: Project[] = [
  {
    id: "1",
    title: "Southern Heritage Website",
    category: "web",
    image: "/placeholder.svg?height=500&width=800",
    link: "/projects/southern-heritage",
  },
  {
    id: "2",
    title: "Magnolia Brand System",
    category: "brand",
    image: "/placeholder.svg?height=500&width=800",
    link: "/projects/magnolia-brand",
  },
  {
    id: "3",
    title: "Digital Entrepreneur Planner",
    category: "digital",
    image: "/placeholder.svg?height=500&width=800",
    link: "/projects/entrepreneur-planner",
  },
]

export function FeaturedProjects() {
  return (
    <section className="py-16 md:py-24 relative overflow-hidden">
      <div className="absolute inset-0 bg-gradient-to-b from-midnight-blue to-midnight-teal opacity-95" />

      <div className="container relative z-10 px-4">
        <div className="text-center mb-12">
          <h2 className="text-3xl md:text-4xl font-serif font-bold text-rich-gold mb-4">Featured Projects</h2>
          <p className="text-lg text-magnolia-white/80 max-w-2xl mx-auto font-lora">
            Explore some of our recent work showcasing Southern Gothic elegance paired with digital innovation.
          </p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-3 gap-6 md:gap-8 mb-12">
          {featuredProjects.map((project) => (
            <motion.div
              key={project.id}
              whileHover={{ y: -5 }}
              className="bg-midnight-blue/50 border border-rich-gold/20 rounded-lg overflow-hidden transition-all duration-300 hover:border-rich-gold/60 hover:shadow-[0_10px_20px_rgba(0,0,0,0.1)]"
            >
              <div className="relative h-64 overflow-hidden">
                <Image
                  src={project.image || "/placeholder.svg"}
                  alt={project.title}
                  fill
                  className="object-cover transition-transform duration-500 hover:scale-105"
                />

                <div className="absolute inset-0 bg-midnight-blue/70 opacity-0 hover:opacity-100 transition-opacity duration-300 flex items-center justify-center">
                  <motion.div
                    initial={{ opacity: 0, y: 20 }}
                    whileHover={{ opacity: 1, y: 0 }}
                    transition={{ duration: 0.3 }}
                  >
                    <Link
                      href={project.link}
                      className="w-10 h-10 rounded-full bg-rich-gold text-midnight-blue flex items-center justify-center"
                      aria-label={`View ${project.title} project details`}
                    >
                      <ExternalLink className="h-5 w-5" />
                    </Link>
                  </motion.div>
                </div>
              </div>

              <div className="p-5">
                <h3 className="font-serif text-lg font-bold text-magnolia-white mb-1">{project.title}</h3>
                <p className="font-sans text-xs uppercase tracking-wider text-rich-gold">
                  {project.category === "web" && "Web Design"}
                  {project.category === "brand" && "Brand Identity"}
                  {project.category === "digital" && "Digital Product"}
                </p>
              </div>
            </motion.div>
          ))}
        </div>

        <div className="text-center">
          <Link href="/portfolio">
            <Button className="bg-rich-gold hover:bg-rich-gold/90 text-midnight-blue">View All Projects</Button>
          </Link>
        </div>
      </div>
    </section>
  )
}

