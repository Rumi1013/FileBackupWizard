"use client"

import { useState } from "react"
import Image from "next/image"
import { motion, AnimatePresence } from "framer-motion"
import { X } from "lucide-react"

const galleryImages = [
  {
    id: 1,
    src: "/placeholder.svg?height=600&width=800",
    alt: "Southern Gothic mansion with golden moon and hanging lanterns",
    title: "Golden Moon Sanctuary",
    description: "The ancestral home illuminated by the golden light of transformation.",
  },
  {
    id: 2,
    src: "/placeholder.svg?height=600&width=800",
    alt: "Woman in white dress overlooking a Southern mansion with blue magnolias",
    title: "Midnight Blooms",
    description: "Magnolias glow with ethereal light, symbolizing resilience in darkness.",
  },
  {
    id: 3,
    src: "/placeholder.svg?height=600&width=800",
    alt: "Southern Gothic scene with crescent moon and magnolia flowers",
    title: "Crescent Journey",
    description: "The path forward illuminated by both celestial and earthly light.",
  },
]

export function ImageGallery() {
  const [selectedImage, setSelectedImage] = useState<number | null>(null)

  return (
    <div className="py-16 bg-gradient-midnight">
      <div className="container px-4">
        <div className="text-center mb-12">
          <h2 className="text-3xl md:text-4xl font-serif font-bold text-rich-gold mb-4">Southern Gothic Elegance</h2>
          <p className="text-lg text-magnolia-white/80 max-w-2xl mx-auto font-lora">
            Explore the visual embodiment of Midnight Magnolia's essence—where Southern tradition meets transformative
            resilience under moonlit skies.
          </p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          {galleryImages.map((image) => (
            <motion.div
              key={image.id}
              whileHover={{ y: -5 }}
              className="relative group cursor-pointer overflow-hidden rounded-lg"
              onClick={() => setSelectedImage(image.id)}
            >
              <div className="aspect-[4/3] relative overflow-hidden">
                <Image
                  src={image.src || "/placeholder.svg"}
                  alt={image.alt}
                  fill
                  className="object-cover transition-transform duration-500 group-hover:scale-110"
                />
                <div className="absolute inset-0 bg-gradient-to-t from-midnight-blue/80 via-midnight-blue/30 to-transparent opacity-80 group-hover:opacity-100 transition-opacity" />

                <div className="absolute bottom-0 left-0 right-0 p-4 transform translate-y-2 group-hover:translate-y-0 transition-transform">
                  <h3 className="text-xl font-serif font-bold text-rich-gold mb-1">{image.title}</h3>
                  <p className="text-sm text-magnolia-white/90 line-clamp-2">{image.description}</p>
                </div>
              </div>
            </motion.div>
          ))}
        </div>
      </div>

      {/* Lightbox */}
      <AnimatePresence>
        {selectedImage !== null && (
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            className="fixed inset-0 z-50 flex items-center justify-center bg-midnight-blue/95 p-4"
            onClick={() => setSelectedImage(null)}
          >
            <button
              className="absolute top-4 right-4 text-magnolia-white hover:text-rich-gold z-10"
              aria-label="Close lightbox"
            >
              <X className="h-8 w-8" />
            </button>

            <motion.div
              initial={{ scale: 0.9, opacity: 0 }}
              animate={{ scale: 1, opacity: 1 }}
              exit={{ scale: 0.9, opacity: 0 }}
              className="relative max-w-5xl max-h-[80vh] w-full"
              onClick={(e) => e.stopPropagation()}
            >
              <div className="relative aspect-[16/9] w-full">
                <Image
                  src={galleryImages.find((img) => img.id === selectedImage)?.src || ""}
                  alt={galleryImages.find((img) => img.id === selectedImage)?.alt || ""}
                  fill
                  className="object-contain"
                />
              </div>

              <div className="absolute bottom-0 left-0 right-0 p-4 bg-midnight-blue/80 backdrop-blur-sm">
                <h3 className="text-xl font-serif font-bold text-rich-gold mb-1">
                  {galleryImages.find((img) => img.id === selectedImage)?.title}
                </h3>
                <p className="text-magnolia-white/90">
                  {galleryImages.find((img) => img.id === selectedImage)?.description}
                </p>
              </div>
            </motion.div>
          </motion.div>
        )}
      </AnimatePresence>
    </div>
  )
}

