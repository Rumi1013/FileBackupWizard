"use client"

import { useState } from "react"
import Image from "next/image"
import { motion, AnimatePresence } from "framer-motion"
import { X, ChevronLeft, ChevronRight } from "lucide-react"
import { Button } from "@/components/ui/button"
import { FloatingMagnolia } from "@/components/floating-magnolia"

const galleryImages = [
  {
    id: 1,
    src: "https://hebbkx1anhila5yf.public.blob.vercel-storage.com/universal_upscale_0_04d80a2f-965f-465b-b915-4810db79f264_0.jpg-yMTC4Sj5Xo3pINpUiZ5e26ApiKiL1s.jpeg",
    alt: "Southern Gothic mansion with golden moon and woman in white dress overlooking water",
    title: "Golden Moon Sanctuary",
    description: "The ancestral home illuminated by the golden light of transformation.",
  },
  {
    id: 2,
    src: "https://hebbkx1anhila5yf.public.blob.vercel-storage.com/Leonardo_Phoenix_10_1980x1020_image_a_Southern_Gothicinspired_0%20%282%29.jpg-mtwigIDIYI7v30gas7Rod9cpYgHk78.jpeg",
    alt: "Woman in off-shoulder white dress gazing at illuminated plantation house across water",
    title: "Midnight Blooms",
    description: "Magnolias glow with ethereal light, symbolizing resilience in darkness.",
  },
  {
    id: 3,
    src: "https://hebbkx1anhila5yf.public.blob.vercel-storage.com/Leonardo_Phoenix_10_1980x1020_image_a_Southern_Gothicinspired_0%20%281%29.jpg-ifRnFBx11kJhtSmlzW8KNOQGj4ILOB.jpeg",
    alt: "Woman in white dress with illuminated mansion and blue magnolias in foreground",
    title: "Crescent Journey",
    description: "The path forward illuminated by both celestial and earthly light.",
  },
  {
    id: 4,
    src: "https://hebbkx1anhila5yf.public.blob.vercel-storage.com/Leonardo_Phoenix_10_1980x1020_image_a_Southern_Gothicinspired_0.jpg-FyzC07NeEAvuGDARoCdYMUZj3dJy43.jpeg",
    alt: "Woman in golden dress with rich gold moon illuminating a Southern mansion",
    title: "Gilded Transformation",
    description: "The golden hour of change, when possibility hangs in the misty air.",
  },
  {
    id: 5,
    src: "https://hebbkx1anhila5yf.public.blob.vercel-storage.com/universal_upscale_0_3bf74993-f566-47fa-b5e9-e994c73dcb43_0.jpg-llYjdK8hB8876xH4ZISor8F94PiHUY.jpeg",
    alt: "Woman in white dress with magnolia flowers and hanging lanterns by water",
    title: "Magnolia Whispers",
    description: "White blooms that speak of purity amidst the shadows of history.",
  },
  {
    id: 6,
    src: "https://hebbkx1anhila5yf.public.blob.vercel-storage.com/universal_upscale_0_a3b40d15-32e3-4d25-84f5-865e603e079d_0.jpg-Z9AnkJU508B3NxR3xtJWMdwFHqZMbX.jpeg",
    alt: "Woman in white dress with illuminated house and boat on misty water",
    title: "Midnight Voyage",
    description: "The journey across still waters to reclaim what was always yours.",
  },
  {
    id: 7,
    src: "https://hebbkx1anhila5yf.public.blob.vercel-storage.com/universal_upscale_0_d52368e1-5b27-4a96-94f0-4dedbca6c955_0.jpg-FNnQUemusHTPQ05gQ5FY3UsVPOQ6b9.jpeg",
    alt: "Woman in off-shoulder dress with crescent moon emblem on plantation house",
    title: "Crescent Legacy",
    description: "The waxing moon of possibility illuminating ancestral grounds.",
  },
  {
    id: 8,
    src: "https://hebbkx1anhila5yf.public.blob.vercel-storage.com/universal_upscale_0_28e4a20c-aac7-44eb-b27a-98394ad2adb0_0.jpg-wEx4x90cvqxUyeIzUJvWQAaZuhkmKi.jpeg",
    alt: "Woman in glowing dress with crescent moon and white magnolias by water",
    title: "Luminous Path",
    description: "The way forward glows with the light of a thousand fireflies.",
  },
]

export function SouthernGothicGallery() {
  const [selectedImage, setSelectedImage] = useState<number | null>(null)
  const [lightboxIndex, setLightboxIndex] = useState(0)

  const openLightbox = (id: number) => {
    const index = galleryImages.findIndex((img) => img.id === id)
    setLightboxIndex(index)
    setSelectedImage(id)
  }

  const closeLightbox = () => {
    setSelectedImage(null)
  }

  const nextImage = () => {
    setLightboxIndex((prev) => (prev === galleryImages.length - 1 ? 0 : prev + 1))
  }

  const prevImage = () => {
    setLightboxIndex((prev) => (prev === 0 ? galleryImages.length - 1 : prev - 1))
  }

  return (
    <div className="py-16 bg-gradient-midnight relative overflow-hidden">
      <div className="absolute inset-0 bg-gradient-to-b from-midnight-blue to-midnight-teal opacity-95" />

      {/* Decorative elements */}
      <FloatingMagnolia size="lg" color="gold" className="absolute top-12 right-[10%]" />
      <FloatingMagnolia size="md" color="white" className="absolute bottom-24 left-[15%]" delay={1.5} />

      <div className="container relative z-10 px-4">
        <div className="text-center mb-12">
          <h2 className="text-3xl md:text-4xl font-serif font-bold text-rich-gold mb-4">Southern Gothic Elegance</h2>
          <p className="text-lg text-magnolia-white/80 max-w-2xl mx-auto font-lora">
            Explore the visual embodiment of Midnight Magnolia's essence—where Southern tradition meets transformative
            resilience under moonlit skies.
          </p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
          {galleryImages.map((image) => (
            <motion.div
              key={image.id}
              whileHover={{ y: -5 }}
              className="relative group cursor-pointer overflow-hidden rounded-lg"
              onClick={() => openLightbox(image.id)}
            >
              <div className="aspect-[3/4] relative overflow-hidden">
                <Image
                  src={image.src || "/placeholder.svg"}
                  alt={image.alt}
                  fill
                  className="object-cover transition-transform duration-500 group-hover:scale-110"
                />
                <div className="absolute inset-0 bg-gradient-to-t from-midnight-blue/80 via-midnight-blue/30 to-transparent opacity-80 group-hover:opacity-100 transition-opacity" />

                <div className="absolute bottom-0 left-0 right-0 p-4 transform translate-y-2 group-hover:translate-y-0 transition-transform">
                  <h3 className="text-xl font-serif font-bold text-rich-gold mb-1">{image.title}</h3>
                  <p className="text-sm text-magnolia-white/90 line-clamp-2">{image.description}</p>
                </div>
              </div>
            </motion.div>
          ))}
        </div>
      </div>

      {/* Lightbox */}
      <AnimatePresence>
        {selectedImage !== null && (
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            className="fixed inset-0 z-50 flex items-center justify-center bg-midnight-blue/95 p-4"
            onClick={closeLightbox}
          >
            <button
              className="absolute top-4 right-4 text-magnolia-white hover:text-rich-gold z-10"
              aria-label="Close lightbox"
            >
              <X className="h-8 w-8" />
            </button>

            <Button
              variant="ghost"
              size="icon"
              className="absolute left-4 top-1/2 -translate-y-1/2 z-30 bg-midnight-blue/30 hover:bg-midnight-blue/50 text-magnolia-white rounded-full h-12 w-12"
              onClick={(e) => {
                e.stopPropagation()
                prevImage()
              }}
              aria-label="Previous image"
            >
              <ChevronLeft className="h-6 w-6" />
            </Button>

            <Button
              variant="ghost"
              size="icon"
              className="absolute right-4 top-1/2 -translate-y-1/2 z-30 bg-midnight-blue/30 hover:bg-midnight-blue/50 text-magnolia-white rounded-full h-12 w-12"
              onClick={(e) => {
                e.stopPropagation()
                nextImage()
              }}
              aria-label="Next image"
            >
              <ChevronRight className="h-6 w-6" />
            </Button>

            <motion.div
              initial={{ scale: 0.9, opacity: 0 }}
              animate={{ scale: 1, opacity: 1 }}
              exit={{ scale: 0.9, opacity: 0 }}
              className="relative max-w-5xl max-h-[80vh] w-full"
              onClick={(e) => e.stopPropagation()}
            >
              <div className="relative aspect-[16/9] w-full">
                <Image
                  src={galleryImages[lightboxIndex].src || "/placeholder.svg"}
                  alt={galleryImages[lightboxIndex].alt}
                  fill
                  className="object-contain"
                />
              </div>

              <div className="absolute bottom-0 left-0 right-0 p-4 bg-midnight-blue/80 backdrop-blur-sm">
                <h3 className="text-xl font-serif font-bold text-rich-gold mb-1">
                  {galleryImages[lightboxIndex].title}
                </h3>
                <p className="text-magnolia-white/90">{galleryImages[lightboxIndex].description}</p>
              </div>
            </motion.div>
          </motion.div>
        )}
      </AnimatePresence>
    </div>
  )
}

