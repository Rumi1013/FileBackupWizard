"use client"

import { useEffect, useRef } from "react"
import { motion } from "framer-motion"
import { Button } from "@/components/ui/button"

export function HeroSection() {
  const canvasRef = useRef<HTMLCanvasElement>(null)

  // Water ripple effect
  useEffect(() => {
    const canvas = canvasRef.current
    if (!canvas) return

    const ctx = canvas.getContext("2d")
    if (!ctx) return

    canvas.width = window.innerWidth
    canvas.height = window.innerHeight

    const resizeCanvas = () => {
      canvas.width = window.innerWidth
      canvas.height = window.innerHeight
    }

    window.addEventListener("resize", resizeCanvas)

    class Particle {
      x: number
      y: number
      size: number
      speedX: number
      speedY: number
      color: string

      constructor() {
        this.x = Math.random() * canvas.width
        this.y = Math.random() * canvas.height
        this.size = Math.random() * 3 + 1
        this.speedX = Math.random() * 0.5 - 0.25
        this.speedY = Math.random() * 0.5 - 0.25
        this.color = `rgba(212, 175, 55, ${Math.random() * 0.5})`
      }

      update() {
        this.x += this.speedX
        this.y += this.speedY

        if (this.x < 0 || this.x > canvas.width) {
          this.speedX = -this.speedX
        }

        if (this.y < 0 || this.y > canvas.height) {
          this.speedY = -this.speedY
        }
      }

      draw() {
        if (!ctx) return
        ctx.fillStyle = this.color
        ctx.beginPath()
        ctx.arc(this.x, this.y, this.size, 0, Math.PI * 2)
        ctx.fill()
      }
    }

    const particles: Particle[] = []
    const createParticles = () => {
      for (let i = 0; i < 50; i++) {
        particles.push(new Particle())
      }
    }

    createParticles()

    const animate = () => {
      if (!ctx) return
      ctx.clearRect(0, 0, canvas.width, canvas.height)

      for (let i = 0; i < particles.length; i++) {
        particles[i].update()
        particles[i].draw()
      }

      requestAnimationFrame(animate)
    }

    animate()

    return () => {
      window.removeEventListener("resize", resizeCanvas)
    }
  }, [])

  return (
    <div className="relative min-h-screen flex items-center justify-center overflow-hidden">
      <canvas ref={canvasRef} className="absolute inset-0 bg-gradient-midnight z-0" aria-hidden="true" />

      <div className="absolute inset-0 bg-gradient-midnight opacity-90 z-10" />

      <div className="container relative z-20 px-4 py-16 md:py-24">
        <div className="grid grid-cols-1 md:grid-cols-2 gap-8 items-center">
          <div>
            <motion.div initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} transition={{ duration: 0.8 }}>
              <h1 className="text-4xl md:text-6xl font-bold text-magnolia-white mb-4">
                Rooted in <span className="text-rich-gold">Resilience</span>
              </h1>

              <p className="text-lg md:text-xl text-magnolia-white/80 mb-8 font-lora">
                From the ashes of burnout, the trauma of activism, and the misdiagnosis of my being—I birthed Midnight
                Magnolia. Not just a business. A sanctuary. A soft rebellion.
              </p>

              <div className="flex flex-col sm:flex-row gap-4">
                <Button className="bg-rich-gold text-midnight-blue hover:bg-rich-gold/90">Explore Services</Button>
                <Button variant="outline" className="border-rich-gold text-rich-gold hover:bg-rich-gold/10">
                  Learn My Story
                </Button>
              </div>
            </motion.div>
          </div>

          <div className="relative">
            <motion.div
              initial={{ opacity: 0, scale: 0.9 }}
              animate={{ opacity: 1, scale: 1 }}
              transition={{ duration: 0.8, delay: 0.2 }}
              className="relative"
            >
              <div className="aspect-square rounded-full bg-midnight-teal/50 p-8 animate-float">
                <div className="w-full h-full rounded-full bg-rich-gold/10 flex items-center justify-center p-8">
                  <div className="w-full h-full rounded-full bg-rich-gold/20 animate-glow flex items-center justify-center">
                    <span className="text-6xl text-rich-gold">MM</span>
                  </div>
                </div>
              </div>

              {/* Floating magnolia petals */}
              <motion.div
                className="absolute top-1/4 right-0 w-8 h-8 bg-magnolia-white/20 rounded-full"
                animate={{
                  y: [0, -20, 0],
                  x: [0, 10, 0],
                  rotate: [0, 45, 0],
                }}
                transition={{
                  duration: 8,
                  repeat: Number.POSITIVE_INFINITY,
                  ease: "easeInOut",
                }}
              />
              <motion.div
                className="absolute bottom-1/4 left-0 w-6 h-6 bg-magnolia-white/20 rounded-full"
                animate={{
                  y: [0, 15, 0],
                  x: [0, -10, 0],
                  rotate: [0, -30, 0],
                }}
                transition={{
                  duration: 7,
                  repeat: Number.POSITIVE_INFINITY,
                  ease: "easeInOut",
                  delay: 1,
                }}
              />
              <motion.div
                className="absolute top-1/2 left-1/4 w-4 h-4 bg-magnolia-white/20 rounded-full"
                animate={{
                  y: [0, 10, 0],
                  x: [0, 5, 0],
                  rotate: [0, 60, 0],
                }}
                transition={{
                  duration: 6,
                  repeat: Number.POSITIVE_INFINITY,
                  ease: "easeInOut",
                  delay: 2,
                }}
              />
            </motion.div>
          </div>
        </div>
      </div>
    </div>
  )
}

