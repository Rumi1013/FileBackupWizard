"use client"

import { useState, useEffect, useCallback } from "react"
import Image from "next/image"
import { motion, AnimatePresence } from "framer-motion"
import { ChevronLeft, ChevronRight } from "lucide-react"
import { Button } from "@/components/ui/button"

const slides = [
  {
    id: 1,
    image: "/placeholder.svg?height=1080&width=1920",
    alt: "Southern Gothic mansion with golden moon and hanging lanterns",
    title: "Midnight Sanctuary",
    subtitle: "Where transformation begins under the golden moon",
  },
  {
    id: 2,
    image: "/placeholder.svg?height=1080&width=1920",
    alt: "Woman in white dress overlooking a Southern mansion with blue magnolias",
    title: "Magnolia Dreams",
    subtitle: "Embracing the journey toward resilience and reclamation",
  },
  {
    id: 3,
    image: "/placeholder.svg?height=1080&width=1920",
    alt: "Southern Gothic scene with crescent moon and magnolia flowers",
    title: "Crescent Whispers",
    subtitle: "The soft rebellion of choosing yourself",
  },
]

export function HeroSlider() {
  const [current, setCurrent] = useState(0)
  const [autoplay, setAutoplay] = useState(true)

  const nextSlide = useCallback(() => {
    setCurrent((current) => (current === slides.length - 1 ? 0 : current + 1))
  }, [])

  const prevSlide = useCallback(() => {
    setCurrent((current) => (current === 0 ? slides.length - 1 : current - 1))
  }, [])

  useEffect(() => {
    if (!autoplay) return

    const interval = setInterval(() => {
      nextSlide()
    }, 6000)

    return () => clearInterval(interval)
  }, [autoplay, nextSlide])

  return (
    <div
      className="relative w-full h-screen overflow-hidden"
      onMouseEnter={() => setAutoplay(false)}
      onMouseLeave={() => setAutoplay(true)}
    >
      {/* Slides */}
      <AnimatePresence mode="wait">
        <motion.div
          key={current}
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          exit={{ opacity: 0 }}
          transition={{ duration: 1, ease: "easeInOut" }}
          className="absolute inset-0"
        >
          <div className="absolute inset-0 bg-midnight-blue/30 z-10" />

          <Image
            src={slides[current].image || "/placeholder.svg"}
            alt={slides[current].alt}
            fill
            priority
            className="object-cover"
          />

          {/* Content */}
          <div className="absolute inset-0 flex items-center justify-center z-20">
            <motion.div
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: 0.5, duration: 0.8 }}
              className="text-center px-4 max-w-4xl"
            >
              <h1 className="text-4xl md:text-6xl lg:text-7xl font-serif font-bold text-magnolia-white mb-4 drop-shadow-lg">
                {slides[current].title}
              </h1>
              <p className="text-xl md:text-2xl text-magnolia-white/90 font-lora italic mb-8 drop-shadow-lg">
                {slides[current].subtitle}
              </p>
              <div className="flex flex-col sm:flex-row justify-center gap-4">
                <Button size="lg" className="bg-rich-gold hover:bg-rich-gold/90 text-midnight-blue font-medium">
                  Explore Our Story
                </Button>
                <Button size="lg" variant="outline" className="border-rich-gold text-rich-gold hover:bg-rich-gold/10">
                  View Services
                </Button>
              </div>
            </motion.div>
          </div>
        </motion.div>
      </AnimatePresence>

      {/* Navigation */}
      <div className="absolute bottom-8 left-0 right-0 z-30 flex justify-center gap-2">
        {slides.map((_, index) => (
          <button
            key={index}
            onClick={() => setCurrent(index)}
            className={`w-3 h-3 rounded-full transition-all ${
              index === current ? "bg-rich-gold w-8" : "bg-magnolia-white/50 hover:bg-magnolia-white"
            }`}
            aria-label={`Go to slide ${index + 1}`}
          />
        ))}
      </div>

      {/* Arrows */}
      <Button
        variant="ghost"
        size="icon"
        className="absolute left-4 top-1/2 -translate-y-1/2 z-30 bg-midnight-blue/30 hover:bg-midnight-blue/50 text-magnolia-white rounded-full h-12 w-12"
        onClick={prevSlide}
        aria-label="Previous slide"
      >
        <ChevronLeft className="h-6 w-6" />
      </Button>

      <Button
        variant="ghost"
        size="icon"
        className="absolute right-4 top-1/2 -translate-y-1/2 z-30 bg-midnight-blue/30 hover:bg-midnight-blue/50 text-magnolia-white rounded-full h-12 w-12"
        onClick={nextSlide}
        aria-label="Next slide"
      >
        <ChevronRight className="h-6 w-6" />
      </Button>

      {/* Decorative elements */}
      <div className="absolute bottom-0 left-0 right-0 h-32 bg-gradient-to-t from-midnight-blue/70 to-transparent z-20 pointer-events-none" />

      {/* Floating particles */}
      <div className="absolute inset-0 z-20 pointer-events-none">
        {Array.from({ length: 50 }).map((_, i) => (
          <motion.div
            key={i}
            className="absolute w-1.5 h-1.5 rounded-full bg-rich-gold/70"
            style={{
              left: `${Math.random() * 100}%`,
              top: `${Math.random() * 100}%`,
            }}
            animate={{
              opacity: [0.2, 0.8, 0.2],
              scale: [0.8, 1.2, 0.8],
            }}
            transition={{
              duration: 3 + Math.random() * 3,
              repeat: Number.POSITIVE_INFINITY,
              delay: Math.random() * 5,
            }}
          />
        ))}
      </div>
    </div>
  )
}

