"use client"

import type React from "react"

import { useState, useEffect, useCallback } from "react"
import Image from "next/image"
import { motion, AnimatePresence } from "framer-motion"
import { ChevronLeft, ChevronRight } from "lucide-react"
import { Button } from "@/components/ui/button"
import { FloatingMagnolia } from "@/components/floating-magnolia"

const slides = [
  {
    id: 1,
    image:
      "https://hebbkx1anhila5yf.public.blob.vercel-storage.com/universal_upscale_0_04d80a2f-965f-465b-b915-4810db79f264_0.jpg-yMTC4Sj5Xo3pINpUiZ5e26ApiKiL1s.jpeg",
    alt: "Southern Gothic mansion with golden moon and woman in white dress overlooking water",
    title: "Midnight Sanctuary",
    subtitle: "Where transformation begins under the golden moon",
  },
  {
    id: 2,
    image:
      "https://hebbkx1anhila5yf.public.blob.vercel-storage.com/Leonardo_Phoenix_10_1980x1020_image_a_Southern_Gothicinspired_0%20%282%29.jpg-mtwigIDIYI7v30gas7Rod9cpYgHk78.jpeg",
    alt: "Woman in off-shoulder white dress gazing at illuminated plantation house across water",
    title: "Magnolia Dreams",
    subtitle: "Embracing the journey toward resilience and reclamation",
  },
  {
    id: 3,
    image:
      "https://hebbkx1anhila5yf.public.blob.vercel-storage.com/Leonardo_Phoenix_10_1980x1020_image_a_Southern_Gothicinspired_0%20%281%29.jpg-ifRnFBx11kJhtSmlzW8KNOQGj4ILOB.jpeg",
    alt: "Woman in white dress with illuminated mansion and blue magnolias in foreground",
    title: "Crescent Whispers",
    subtitle: "The soft rebellion of choosing yourself",
  },
  {
    id: 4,
    image:
      "https://hebbkx1anhila5yf.public.blob.vercel-storage.com/Leonardo_Phoenix_10_1980x1020_image_a_Southern_Gothicinspired_0.jpg-FyzC07NeEAvuGDARoCdYMUZj3dJy43.jpeg",
    alt: "Woman in golden dress with rich gold moon illuminating a Southern mansion",
    title: "Golden Transformation",
    subtitle: "Illuminating the path to your authentic power",
  },
  {
    id: 5,
    image:
      "https://hebbkx1anhila5yf.public.blob.vercel-storage.com/universal_upscale_0_3bf74993-f566-47fa-b5e9-e994c73dcb43_0.jpg-llYjdK8hB8876xH4ZISor8F94PiHUY.jpeg",
    alt: "Woman in white dress with magnolia flowers and hanging lanterns by water",
    title: "Magnolia Blooms",
    subtitle: "Beauty that flourishes in the darkness",
  },
  {
    id: 6,
    image:
      "https://hebbkx1anhila5yf.public.blob.vercel-storage.com/universal_upscale_0_a3b40d15-32e3-4d25-84f5-865e603e079d_0.jpg-Z9AnkJU508B3NxR3xtJWMdwFHqZMbX.jpeg",
    alt: "Woman in white dress with illuminated house and boat on misty water",
    title: "Midnight Voyage",
    subtitle: "Navigating the waters of creative transformation",
  },
  {
    id: 7,
    image:
      "https://hebbkx1anhila5yf.public.blob.vercel-storage.com/universal_upscale_0_d52368e1-5b27-4a96-94f0-4dedbca6c955_0.jpg-FNnQUemusHTPQ05gQ5FY3UsVPOQ6b9.jpeg",
    alt: "Woman in off-shoulder dress with crescent moon emblem on plantation house",
    title: "Crescent Legacy",
    subtitle: "Honoring your roots while creating your future",
  },
  {
    id: 8,
    image:
      "https://hebbkx1anhila5yf.public.blob.vercel-storage.com/universal_upscale_0_28e4a20c-aac7-44eb-b27a-98394ad2adb0_0.jpg-wEx4x90cvqxUyeIzUJvWQAaZuhkmKi.jpeg",
    alt: "Woman in glowing dress with crescent moon and white magnolias by water",
    title: "Luminous Path",
    subtitle: "Finding your light in the Southern night",
  },
]

export function EnhancedHeroSlider() {
  const [current, setCurrent] = useState(0)
  const [autoplay, setAutoplay] = useState(true)
  const [isLoading, setIsLoading] = useState(true)
  const [touchStart, setTouchStart] = useState(0)
  const [touchEnd, setTouchEnd] = useState(0)

  const nextSlide = useCallback(() => {
    setCurrent((current) => (current === slides.length - 1 ? 0 : current + 1))
  }, [])

  const prevSlide = useCallback(() => {
    setCurrent((current) => (current === 0 ? slides.length - 1 : current - 1))
  }, [])

  useEffect(() => {
    if (!autoplay) return

    const interval = setInterval(() => {
      nextSlide()
    }, 6000)

    return () => clearInterval(interval)
  }, [autoplay, nextSlide])

  const handleTouchStart = (e: React.TouchEvent) => {
    setTouchStart(e.targetTouches[0].clientX)
  }

  const handleTouchMove = (e: React.TouchEvent) => {
    setTouchEnd(e.targetTouches[0].clientX)
  }

  const handleTouchEnd = () => {
    if (touchStart - touchEnd > 150) {
      nextSlide()
    }

    if (touchStart - touchEnd < -150) {
      prevSlide()
    }
  }

  return (
    <div
      className="relative w-full h-screen overflow-hidden"
      onMouseEnter={() => setAutoplay(false)}
      onMouseLeave={() => setAutoplay(true)}
      onTouchStart={handleTouchStart}
      onTouchMove={handleTouchMove}
      onTouchEnd={handleTouchEnd}
    >
      {/* Slides */}
      <AnimatePresence mode="wait">
        <motion.div
          key={current}
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          exit={{ opacity: 0 }}
          transition={{ duration: 1, ease: "easeInOut" }}
          className="absolute inset-0"
        >
          <div className="absolute inset-0 bg-midnight-blue/30 z-10" />

          <div className="relative h-full w-full">
            <Image
              src={slides[current].image || "/placeholder.svg"}
              alt={slides[current].alt}
              fill
              priority
              className="object-cover"
              onLoadingComplete={() => setIsLoading(false)}
            />
          </div>

          {/* Content */}
          <div className="absolute inset-0 flex items-center justify-center z-20">
            <motion.div
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: 0.5, duration: 0.8 }}
              className="text-center px-4 max-w-4xl"
            >
              <h1 className="text-4xl md:text-6xl lg:text-7xl font-serif font-bold text-magnolia-white mb-4 drop-shadow-lg">
                {slides[current].title}
              </h1>
              <p className="text-xl md:text-2xl text-magnolia-white/90 font-lora italic mb-8 drop-shadow-lg">
                {slides[current].subtitle}
              </p>
              <div className="flex flex-col sm:flex-row justify-center gap-4">
                <Button size="lg" className="bg-rich-gold hover:bg-rich-gold/90 text-midnight-blue font-medium">
                  Explore Our Story
                </Button>
                <Button size="lg" variant="outline" className="border-rich-gold text-rich-gold hover:bg-rich-gold/10">
                  View Services
                </Button>
              </div>
            </motion.div>
          </div>
        </motion.div>
      </AnimatePresence>

      {/* Navigation */}
      <div className="absolute bottom-8 left-0 right-0 z-30 flex justify-center gap-2">
        {slides.map((_, index) => (
          <button
            key={index}
            onClick={() => setCurrent(index)}
            className={`w-3 h-3 rounded-full transition-all ${
              index === current ? "bg-rich-gold w-8" : "bg-magnolia-white/50 hover:bg-magnolia-white"
            }`}
            aria-label={`Go to slide ${index + 1}`}
          />
        ))}
      </div>

      {/* Arrows */}
      <Button
        variant="ghost"
        size="icon"
        className="absolute left-4 top-1/2 -translate-y-1/2 z-30 bg-midnight-blue/30 hover:bg-midnight-blue/50 text-magnolia-white rounded-full h-12 w-12"
        onClick={prevSlide}
        aria-label="Previous slide"
      >
        <ChevronLeft className="h-6 w-6" />
      </Button>

      <Button
        variant="ghost"
        size="icon"
        className="absolute right-4 top-1/2 -translate-y-1/2 z-30 bg-midnight-blue/30 hover:bg-midnight-blue/50 text-magnolia-white rounded-full h-12 w-12"
        onClick={nextSlide}
        aria-label="Next slide"
      >
        <ChevronRight className="h-6 w-6" />
      </Button>

      {/* Decorative elements */}
      <div className="absolute bottom-0 left-0 right-0 h-32 bg-gradient-to-t from-midnight-blue/70 to-transparent z-20 pointer-events-none" />

      {/* Floating magnolias */}
      <FloatingMagnolia size="md" color="gold" className="absolute top-[20%] right-[10%] z-20" />
      <FloatingMagnolia size="sm" color="white" className="absolute bottom-[30%] left-[15%] z-20" delay={1.2} />
      <FloatingMagnolia size="lg" color="gold" className="absolute top-[40%] left-[5%] z-20" delay={0.5} />

      {/* Floating particles */}
      <div className="absolute inset-0 z-20 pointer-events-none">
        {Array.from({ length: 50 }).map((_, i) => (
          <motion.div
            key={i}
            className="absolute w-1.5 h-1.5 rounded-full bg-rich-gold/70"
            style={{
              left: `${Math.random() * 100}%`,
              top: `${Math.random() * 100}%`,
            }}
            animate={{
              opacity: [0.2, 0.8, 0.2],
              scale: [0.8, 1.2, 0.8],
            }}
            transition={{
              duration: 3 + Math.random() * 3,
              repeat: Number.POSITIVE_INFINITY,
              delay: Math.random() * 5,
            }}
          />
        ))}
      </div>

      {/* Loading overlay */}
      {isLoading && (
        <div className="absolute inset-0 bg-midnight-blue z-50 flex items-center justify-center">
          <div className="w-16 h-16 border-4 border-rich-gold/20 border-t-rich-gold rounded-full animate-spin" />
        </div>
      )}
    </div>
  )
}

