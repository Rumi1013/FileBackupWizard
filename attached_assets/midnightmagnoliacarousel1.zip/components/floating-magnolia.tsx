"use client"

import { motion } from "framer-motion"

interface FloatingMagnoliaProps {
  className?: string
  size?: "sm" | "md" | "lg"
  color?: "gold" | "white" | "sage"
  delay?: number
}

export function FloatingMagnolia({ className = "", size = "md", color = "gold", delay = 0 }: FloatingMagnoliaProps) {
  const sizeMap = {
    sm: "w-8 h-8",
    md: "w-12 h-12",
    lg: "w-16 h-16",
  }

  const colorMap = {
    gold: "bg-rich-gold/20",
    white: "bg-magnolia-white/20",
    sage: "bg-sage-green/20",
  }

  return (
    <motion.div
      className={`absolute rounded-full ${sizeMap[size]} ${colorMap[color]} ${className}`}
      animate={{
        y: [0, -15, 0],
        x: [0, 8, 0],
        rotate: [0, 45, 0],
      }}
      transition={{
        duration: 6 + Math.random() * 4,
        repeat: Number.POSITIVE_INFINITY,
        ease: "easeInOut",
        delay: delay,
      }}
    >
      <motion.div
        className="w-full h-full rounded-full bg-current opacity-20"
        animate={{ scale: [1, 1.1, 1] }}
        transition={{
          duration: 4,
          repeat: Number.POSITIVE_INFINITY,
          ease: "easeInOut",
          delay: delay + 1,
        }}
      />
    </motion.div>
  )
}

