export function NewsletterSignup() {
  return (
    <section className="py-16 bg-gradient-midnight relative overflow-hidden">
      <div className="absolute inset-0 bg-[url('/placeholder.svg?height=1080&width=1920')] bg-cover bg-center opacity-10" />
      <div className="absolute inset-0 bg-gradient-midnight opacity-90" />

      <div className="container relative z-10 px-4 text-center">
        <h2 className="text-3xl md:text-4xl font-serif font-bold text-rich-gold mb-6">Join the Midnight Letter</h2>
        <p className="text-xl text-magnolia-white/90 font-lora max-w-2xl mx-auto mb-8">
          Subscribe to receive monthly insights, exclusive content, and special offers delivered directly to your inbox.
        </p>

        <form className="flex flex-col sm:flex-row gap-2 max-w-md mx-auto">
          <input
            type="email"
            placeholder="Your email address"
            className="px-4 py-2 bg-midnight-teal/50 border border-rich-gold/20 rounded-md focus:outline-none focus:ring-2 focus:ring-rich-gold/50 text-magnolia-white flex-1"
            required
          />
          <button
            type="submit"
            className="px-4 py-2 bg-rich-gold hover:bg-rich-gold/90 text-midnight-blue rounded-md transition-colors"
          >
            Subscribe
          </button>
        </form>

        <p className="mt-4 text-sm text-magnolia-white/60 font-lora">
          We respect your privacy. Unsubscribe at any time.
        </p>
      </div>
    </section>
  )
}

