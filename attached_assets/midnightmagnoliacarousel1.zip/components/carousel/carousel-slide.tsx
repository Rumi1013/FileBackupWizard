"\"use client"

import { useState, useEffect } from "react"
import { Card } from "@/components/ui/card"
import { motion } from "framer-motion"

interface CarouselSlideProps {
  title: string
  text: string
  slideNumber: number
  totalSlides: number
}

export function CarouselSlide({ title, text, slideNumber, totalSlides }: CarouselSlideProps) {
  const [mounted, setMounted] = useState(false)

  useEffect(() => {
    setMounted(true)
  }, [])

  if (!mounted) return null

  return (
    <Card className="relative w-full aspect-square overflow-hidden rounded-lg">
      {/* Background gradient */}
      <div className="absolute inset-0 bg-gradient-to-b from-[#0A192F] to-[#0A3B4D] z-0" aria-hidden="true" />

      {/* Decorative elements */}
      <motion.div
        className="absolute top-5 right-5 w-16 h-16 opacity-60"
        initial={{ opacity: 0, scale: 0.8 }}
        animate={{ opacity: 0.6, scale: 1 }}
        transition={{ duration: 2, repeat: Number.POSITIVE_INFINITY, repeatType: "reverse" }}
      >
        {/* Moon element - replace with your uploaded image */}
        <div className="w-full h-full rounded-full bg-[#D4AF37]/30 shadow-[0_0_15px_5px_rgba(212,175,55,0.3)]"></div>
      </motion.div>

      {/* Content */}
      <div className="relative z-10 flex flex-col justify-between h-full p-8 text-[#FAF3E0]">
        <div>
          <h2 className="font-serif text-2xl font-bold text-[#D4AF37] mb-4">{title}</h2>
          <div className="whitespace-pre-line">{text}</div>
        </div>

        <div className="flex justify-between items-center mt-6">
          <div className="text-sm text-[#D4AF37]">
            {slideNumber}/{totalSlides}
          </div>
          <div className="text-sm italic">Midnight Magnolia</div>
        </div>
      </div>
    </Card>
  )
}

