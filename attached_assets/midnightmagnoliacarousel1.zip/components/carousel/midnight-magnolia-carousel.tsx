"use client"

import { useState } from "react"
import { ChevronLeft, ChevronRight } from "lucide-react"
import { Button } from "@/components/ui/button"
import { CarouselSlide } from "./carousel-slide"

// Sample data from your carousel content
const slides = [
  {
    title: "Eulogy for the Life I Survived",
    text: "This is not just a eulogy.\nThis is a rite of passage.\nA ceremony for the self that once carried everyone else's burden\nwhile silently drowning in her own.",
  },
  {
    title: "For the Girl Who Carried Too Much",
    text: "I was only eighteen.\nBright. Brilliant. Tender.\nCarrying books and dreams\nand the weight of silence.\n\nNo one warned me that the world could be this cruel,\neven in places that claimed to protect us.",
  },
  {
    title: "For the Love That Was Promised",
    text: "I wanted protection.\nI wanted someone to shield me from the storms.\nBut instead, I became the shelter for everyone else,\nwith no one to hold me.",
  },
  {
    title: "And So, I Created Midnight Magnolia",
    text: "From the ashes of burnout,\nthe trauma of activism,\nand the misdiagnosis of my being—\nI birthed Midnight Magnolia.",
  },
]

export function MidnightMagnoliaCarousel() {
  const [currentSlide, setCurrentSlide] = useState(0)

  const nextSlide = () => {
    setCurrentSlide((prev) => (prev + 1) % slides.length)
  }

  const prevSlide = () => {
    setCurrentSlide((prev) => (prev - 1 + slides.length) % slides.length)
  }

  return (
    <div className="relative w-full max-w-md mx-auto">
      <div className="relative overflow-hidden rounded-lg">
        <div
          className="flex transition-transform duration-500 ease-in-out"
          style={{ transform: `translateX(-${currentSlide * 100}%)` }}
        >
          {slides.map((slide, index) => (
            <div key={index} className="w-full flex-shrink-0">
              <CarouselSlide
                title={slide.title}
                text={slide.text}
                slideNumber={index + 1}
                totalSlides={slides.length}
              />
            </div>
          ))}
        </div>
      </div>

      <div className="flex justify-between mt-4">
        <Button
          variant="outline"
          size="icon"
          onClick={prevSlide}
          className="bg-[#0A192F]/80 border-[#D4AF37] text-[#D4AF37] hover:bg-[#0A192F] hover:text-[#FAF3E0]"
        >
          <ChevronLeft className="h-4 w-4" />
          <span className="sr-only">Previous slide</span>
        </Button>

        <Button
          variant="outline"
          size="icon"
          onClick={nextSlide}
          className="bg-[#0A192F]/80 border-[#D4AF37] text-[#D4AF37] hover:bg-[#0A192F] hover:text-[#FAF3E0]"
        >
          <ChevronRight className="h-4 w-4" />
          <span className="sr-only">Next slide</span>
        </Button>
      </div>
    </div>
  )
}

