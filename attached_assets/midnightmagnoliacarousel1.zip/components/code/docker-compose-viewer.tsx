"use client"

import { useState } from "react"
import { Button } from "@/components/ui/button"
import { Card } from "@/components/ui/card"

export function DockerComposeViewer() {
  const [copied, setCopied] = useState(false)

  const dockerComposeContent = `version: '3.8'

services:
  db:
    image: postgres:14
    container_name: mm-postgres
    restart: always
    environment:
      POSTGRES_USER: \${DB_USER}
      POSTGRES_PASSWORD: \${DB_PASSWORD}
      POSTGRES_DB: \${DB_NAME}
    volumes:
      - postgres-data:/var/lib/postgresql/data
    ports:
      - "5432:5432"
    networks:
      - mm-network

  redis:
    image: redis:7
    container_name: mm-redis
    restart: always
    volumes:
      - redis-data:/data
    ports:
      - "6379:6379"
    networks:
      - mm-network

  api:
    build: 
      context: ./api
      dockerfile: Dockerfile
    container_name: mm-api
    restart: always
    depends_on:
      - db
      - redis
    environment:
      NODE_ENV: production
      DB_HOST: db
      DB_USER: \${DB_USER}
      DB_PASSWORD: \${DB_PASSWORD}
      DB_NAME: \${DB_NAME}
      DB_PORT: 5432
      REDIS_HOST: redis
      REDIS_PORT: 6379
      JWT_SECRET: \${JWT_SECRET}
      STRIPE_SECRET_KEY: \${STRIPE_SECRET_KEY}
      SENDGRID_API_KEY: \${SENDGRID_API_KEY}
      S3_BUCKET: \${S3_BUCKET}
      CDN_BASE_URL: \${CDN_BASE_URL}
    ports:
      - "3001:3001"
    networks:
      - mm-network

  frontend:
    build:
      context: ./frontend
      dockerfile: Dockerfile
    container_name: mm-frontend
    restart: always
    depends_on:
      - api
    environment:
      NODE_ENV: production
      NEXT_PUBLIC_API_URL: http://api:3001
    ports:
      - "3000:3000"
    networks:
      - mm-network

  nginx:
    image: nginx:latest
    container_name: mm-nginx
    restart: always
    ports:
      - "80:80"
      - "443:443"
    volumes:
      - ./nginx:/etc/nginx/conf.d
      - ./certbot/conf:/etc/letsencrypt
      - ./certbot/www:/var/www/certbot
    depends_on:
      - frontend
      - api
    networks:
      - mm-network

  certbot:
    image: certbot/certbot
    container_name: mm-certbot
    volumes:
      - ./certbot/conf:/etc/letsencrypt
      - ./certbot/www:/var/www/certbot
    entrypoint: "/bin/sh -c 'trap exit TERM; while :; do certbot renew; sleep 12h & wait \$\${!}; done;'"

networks:
  mm-network:
    driver: bridge

volumes:
  postgres-data:
  redis-data:`

  const copyToClipboard = () => {
    navigator.clipboard.writeText(dockerComposeContent)
    setCopied(true)
    setTimeout(() => setCopied(false), 2000)
  }

  return (
    <Card className="border border-rich-gold/20 bg-midnight-blue/50 overflow-hidden">
      <div className="flex items-center justify-between bg-midnight-teal/50 px-4 py-2 border-b border-rich-gold/20">
        <h3 className="font-playfair text-lg text-rich-gold">docker-compose.yml</h3>
        <Button
          variant="outline"
          size="sm"
          onClick={copyToClipboard}
          className="text-xs font-montserrat border-rich-gold/30 text-rich-gold hover:bg-rich-gold/20"
        >
          {copied ? "Copied!" : "Copy"}
        </Button>
      </div>
      <div className="p-4 overflow-x-auto">
        <pre className="font-mono text-sm text-magnolia-white/90 whitespace-pre">{dockerComposeContent}</pre>
      </div>
    </Card>
  )
}

