"use client"

import { useState } from "react"
import Link from "next/link"
import { Menu, X } from "lucide-react"
import { Button } from "@/components/ui/button"

export function Navigation() {
  const [isOpen, setIsOpen] = useState(false)

  return (
    <nav className="fixed w-full z-50 bg-background/80 backdrop-blur-sm border-b border-border/40">
      <div className="container mx-auto px-4">
        <div className="flex h-16 items-center justify-between">
          <div className="flex items-center">
            <Link href="/" className="flex items-center space-x-2">
              <span className="h-8 w-8 rounded-full bg-rich-gold animate-pulse"></span>
              <span className="font-serif text-xl font-bold text-rich-gold">Midnight Magnolia</span>
            </Link>
          </div>

          <div className="hidden md:flex md:items-center md:space-x-6">
            <Link href="/" className="text-foreground/80 hover:text-rich-gold transition-colors">
              Home
            </Link>
            <Link href="/about" className="text-foreground/80 hover:text-rich-gold transition-colors">
              About
            </Link>
            <Link href="/services" className="text-foreground/80 hover:text-rich-gold transition-colors">
              Services
            </Link>
            <Link href="/digital-products" className="text-foreground/80 hover:text-rich-gold transition-colors">
              Digital Products
            </Link>
            <Link href="/blog" className="text-foreground/80 hover:text-rich-gold transition-colors">
              Blog
            </Link>
            <Link href="/contact" className="text-foreground/80 hover:text-rich-gold transition-colors">
              Contact
            </Link>
          </div>

          <div className="flex items-center">
            <Button
              variant="ghost"
              size="icon"
              className="md:hidden text-foreground/80 hover:text-rich-gold"
              onClick={() => setIsOpen(!isOpen)}
            >
              {isOpen ? <X className="h-5 w-5" /> : <Menu className="h-5 w-5" />}
              <span className="sr-only">Toggle menu</span>
            </Button>
          </div>
        </div>
      </div>

      {/* Mobile menu */}
      {isOpen && (
        <div className="md:hidden bg-background/95 backdrop-blur-sm">
          <div className="flex flex-col items-center justify-center space-y-4 p-4">
            <Link
              href="/"
              className="text-xl font-serif text-foreground hover:text-rich-gold transition-colors"
              onClick={() => setIsOpen(false)}
            >
              Home
            </Link>
            <Link
              href="/about"
              className="text-xl font-serif text-foreground hover:text-rich-gold transition-colors"
              onClick={() => setIsOpen(false)}
            >
              About
            </Link>
            <Link
              href="/services"
              className="text-xl font-serif text-foreground hover:text-rich-gold transition-colors"
              onClick={() => setIsOpen(false)}
            >
              Services
            </Link>
            <Link
              href="/digital-products"
              className="text-xl font-serif text-foreground hover:text-rich-gold transition-colors"
              onClick={() => setIsOpen(false)}
            >
              Digital Products
            </Link>
            <Link
              href="/blog"
              className="text-xl font-serif text-foreground hover:text-rich-gold transition-colors"
              onClick={() => setIsOpen(false)}
            >
              Blog
            </Link>
            <Link
              href="/contact"
              className="text-xl font-serif text-foreground hover:text-rich-gold transition-colors"
              onClick={() => setIsOpen(false)}
            >
              Contact
            </Link>
          </div>
        </div>
      )}
    </nav>
  )
}

