"use client"

import { useState } from "react"
import { Card, CardContent, CardFooter, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Tabs, TabsList, TabsTrigger } from "@/components/ui/tabs"

// Sample product data
const products = [
  {
    id: 1,
    name: "Midnight Entrepreneur Planner",
    description: "Digital planner with income tracking, automation checklists, and strategy frameworks.",
    price: "$49",
    category: "digital",
  },
  {
    id: 2,
    name: "Southern Digital Brand Kit",
    description: "Complete brand template system with mood boards, logo placeholders, and color palettes.",
    price: "$79",
    category: "digital",
  },
  {
    id: 3,
    name: "Magnolia AI Prompt Collection",
    description: "100+ curated prompts for business automation, content creation, and digital product development.",
    price: "$37",
    category: "digital",
  },
  {
    id: 4,
    name: "Midnight Magnolia Journal",
    description: "Hardcover journal with Southern Gothic aesthetic, cream pages, and gold accents.",
    price: "$32",
    category: "print",
  },
]

export function ProductGrid() {
  const [activeCategory, setActiveCategory] = useState("all")

  const filteredProducts =
    activeCategory === "all" ? products : products.filter((product) => product.category === activeCategory)

  return (
    <section className="py-16 md:py-24 bg-gradient-midnight relative overflow-hidden">
      <div className="container px-4">
        <div className="text-center mb-16">
          <h2 className="text-3xl md:text-4xl font-serif font-bold text-rich-gold mb-4">Featured Products</h2>
          <p className="text-lg text-magnolia-white/80 max-w-2xl mx-auto font-lora">
            Explore our collection of digital products designed to support your entrepreneurial journey.
          </p>
        </div>

        <Tabs defaultValue="all" className="w-full" onValueChange={setActiveCategory}>
          <div className="flex justify-center mb-8">
            <TabsList className="bg-midnight-blue/30">
              <TabsTrigger
                value="all"
                className="data-[state=active]:bg-rich-gold/20 data-[state=active]:text-rich-gold"
              >
                All Products
              </TabsTrigger>
              <TabsTrigger
                value="digital"
                className="data-[state=active]:bg-rich-gold/20 data-[state=active]:text-rich-gold"
              >
                Digital Products
              </TabsTrigger>
              <TabsTrigger
                value="print"
                className="data-[state=active]:bg-rich-gold/20 data-[state=active]:text-rich-gold"
              >
                Print Products
              </TabsTrigger>
            </TabsList>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
            {filteredProducts.map((product) => (
              <Card key={product.id} className="bg-midnight-blue/20 border-rich-gold/20 h-full flex flex-col">
                <CardHeader className="pb-2">
                  <CardTitle className="text-rich-gold">{product.name}</CardTitle>
                </CardHeader>
                <CardContent className="flex-grow">
                  <p className="text-foreground/80 font-lora text-sm">{product.description}</p>
                </CardContent>
                <CardFooter className="flex justify-between items-center">
                  <p className="font-serif font-bold text-rich-gold">{product.price}</p>
                  <Button className="bg-rich-gold hover:bg-rich-gold/90 text-midnight-blue">View Details</Button>
                </CardFooter>
              </Card>
            ))}
          </div>
        </Tabs>
      </div>
    </section>
  )
}

