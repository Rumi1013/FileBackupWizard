"use client"

import type React from "react"

import { useState, useRef, useEffect } from "react"
import { motion } from "framer-motion"
import Image from "next/image"
import Link from "next/link"
import { ShoppingCart, Eye } from "lucide-react"
import { useAccessibility } from "@/contexts/accessibility-context"
import { productLoader, addToCart } from "@/lib/product-loader"
import { Button } from "@/components/ui/button"
import { toast } from "@/components/ui/use-toast"

interface ProductCardProps {
  product: {
    id: string
    title: string
    price: number
    image: string
    imageAlt?: string
    shortDescription: string
    type: "digital" | "physical"
    isNew?: boolean
    slug: string
  }
}

export function ProductCard({ product }: ProductCardProps) {
  const [focused, setFocused] = useState(false)
  const [isHovered, setIsHovered] = useState(false)
  const cardRef = useRef<HTMLDivElement>(null)
  const loadingIndicatorRef = useRef<HTMLDivElement>(null)
  const { config, prefersReducedMotion } = useAccessibility()

  // Register loading indicator with product loader
  useEffect(() => {
    productLoader.registerIndicator(product.id, loadingIndicatorRef.current)

    return () => {
      productLoader.registerIndicator(product.id, null)
    }
  }, [product.id])

  // ADHD-friendly: Maintain focus state for accessible highlighting
  const handleFocus = () => setFocused(true)
  const handleBlur = () => setFocused(false)

  // ADHD-friendly: Add keyboard support
  const handleKeyPress = (e: React.KeyboardEvent) => {
    if (e.key === "Enter" || e.key === " ") {
      e.preventDefault()
      window.location.href = `/products/${product.slug}`
    }
  }

  // Handle add to cart
  const handleAddToCart = async (e: React.MouseEvent) => {
    e.stopPropagation()
    e.preventDefault()

    try {
      await addToCart(product.id, 1)
      toast({
        title: "Added to cart",
        description: `${product.title} has been added to your cart.`,
        variant: "default",
      })
    } catch (error) {
      toast({
        title: "Error",
        description: "Failed to add product to cart. Please try again.",
        variant: "destructive",
      })
    }
  }

  // Animation settings based on accessibility preferences
  const animationSettings = prefersReducedMotion
    ? { y: 0 } // No animation if user prefers reduced motion
    : { y: -5 }

  const transitionSettings = {
    duration: Number.parseFloat(config.animation.transitionDuration.replace("s", "")),
  }

  return (
    <motion.div
      ref={cardRef}
      className={`
        relative bg-midnight-blue/50 border border-rich-gold/20 rounded-lg overflow-hidden 
        transition-all duration-300 h-full flex flex-col
        ${focused ? "ring-2 ring-rich-gold ring-offset-2 ring-offset-midnight-blue" : ""}
        ${product.type === "digital" ? "border-l-rich-gold" : ""}
      `}
      tabIndex={0}
      onFocus={handleFocus}
      onBlur={handleBlur}
      onKeyDown={handleKeyPress}
      whileHover={animationSettings}
      transition={transitionSettings}
      onMouseEnter={() => setIsHovered(true)}
      onMouseLeave={() => setIsHovered(false)}
      aria-labelledby={`product-title-${product.id}`}
    >
      {/* Loading indicator */}
      <div
        ref={loadingIndicatorRef}
        className="absolute inset-0 bg-midnight-blue/80 z-20 flex items-center justify-center opacity-0 transition-opacity pointer-events-none mm-loading-indicator"
        aria-hidden="true"
      >
        <div className="w-10 h-10 border-4 border-rich-gold/20 border-t-rich-gold rounded-full animate-spin"></div>
      </div>

      <div className="relative aspect-square overflow-hidden">
        <Image
          src={product.image || "/placeholder.svg"}
          alt={product.imageAlt || `Product image for ${product.title}`}
          fill
          className="object-cover transition-transform duration-500 hover:scale-105"
          loading="lazy"
        />

        {/* Product badges */}
        <div className="absolute top-2 left-2 flex flex-col gap-2">
          {product.isNew && (
            <span className="px-2 py-1 bg-rich-gold text-midnight-blue text-xs font-bold rounded-full">New</span>
          )}
          {product.type === "digital" && (
            <span className="px-2 py-1 bg-midnight-teal/80 text-magnolia-white text-xs font-bold rounded-full">
              Digital
            </span>
          )}
        </div>

        {/* Hover overlay with actions */}
        <div
          className={`
            absolute inset-0 bg-midnight-blue/70 flex items-center justify-center gap-4
            transition-opacity duration-300
            ${isHovered || focused ? "opacity-100" : "opacity-0"}
          `}
        >
          <Link
            href={`/products/${product.slug}`}
            className="w-10 h-10 rounded-full bg-rich-gold text-midnight-blue flex items-center justify-center"
            aria-label={`View details for ${product.title}`}
            onClick={(e) => e.stopPropagation()}
          >
            <Eye className="h-5 w-5" />
          </Link>

          <button
            onClick={handleAddToCart}
            className="w-10 h-10 rounded-full bg-rich-gold text-midnight-blue flex items-center justify-center"
            aria-label={`Add ${product.title} to cart`}
          >
            <ShoppingCart className="h-5 w-5" />
          </button>
        </div>
      </div>

      <div className="p-5 flex-grow flex flex-col">
        <h3 id={`product-title-${product.id}`} className="font-serif text-lg font-bold text-magnolia-white mb-1">
          {product.title}
        </h3>

        <p className="font-serif font-bold text-rich-gold mb-2">${product.price.toFixed(2)}</p>

        <p className="text-magnolia-white/80 font-lora text-sm mb-4 flex-grow">{product.shortDescription}</p>

        <div className="flex justify-between items-center mt-auto">
          <Link
            href={`/products/${product.slug}`}
            className="text-rich-gold hover:text-rich-gold/80 text-sm font-medium"
          >
            View Details
          </Link>

          <Button size="sm" onClick={handleAddToCart} className="bg-rich-gold hover:bg-rich-gold/90 text-midnight-blue">
            Add to Cart
          </Button>
        </div>
      </div>
    </motion.div>
  )
}

