"use client"

import { useState, useEffect, useRef } from "react"
import { motion, AnimatePresence } from "framer-motion"
import { ChevronLeft, ChevronRight, Filter, X } from "lucide-react"
import { Button } from "@/components/ui/button"
import { ProductCard } from "@/components/products/product-card"
import { FloatingMagnolia } from "@/components/floating-magnolia"
import { useAccessibility } from "@/contexts/accessibility-context"
import { Skeleton } from "@/components/ui/skeleton"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import {
  Sheet,
  SheetContent,
  SheetDescription,
  SheetHeader,
  SheetTitle,
  SheetTrigger,
  SheetClose,
} from "@/components/ui/sheet"
import { Accordion, AccordionContent, AccordionItem, AccordionTrigger } from "@/components/ui/accordion"
import { Checkbox } from "@/components/ui/checkbox"
import { Label } from "@/components/ui/label"
import { Slider } from "@/components/ui/slider"

// Define product type
interface Product {
  id: string
  title: string
  price: number
  image: string
  imageAlt?: string
  shortDescription: string
  type: "digital" | "physical"
  isNew?: boolean
  slug: string
  category?: string
}

// Sample product data
const sampleProducts: Product[] = Array.from({ length: 12 }, (_, i) => ({
  id: (i + 1).toString(),
  title: `${i % 2 === 0 ? "Digital" : "Physical"} Product ${i + 1}`,
  price: 49.99 + i * 10,
  image: `/placeholder.svg?height=400&width=400&text=Product+${i + 1}`,
  shortDescription: "A beautiful product designed for creative entrepreneurs with Southern Gothic aesthetics.",
  type: i % 2 === 0 ? "digital" : "physical",
  isNew: i < 3,
  slug: `product-${i + 1}`,
  category: i % 3 === 0 ? "Templates" : i % 3 === 1 ? "Planners" : "Courses",
}))

// Number of products per page
const PRODUCTS_PER_PAGE = 6

export function ProductGallery() {
  // State for products
  const [products, setProducts] = useState<Product[]>([])
  const [filteredProducts, setFilteredProducts] = useState<Product[]>([])
  const [visibleProducts, setVisibleProducts] = useState<Product[]>([])

  // State for loading
  const [isLoading, setIsLoading] = useState(true)

  // State for pagination
  const [currentPage, setCurrentPage] = useState(1)
  const [totalPages, setTotalPages] = useState(1)

  // State for filters
  const [activeFilters, setActiveFilters] = useState({
    type: "all",
    category: "all",
    priceRange: [0, 200] as [number, number],
    newOnly: false,
  })

  // State for sorting
  const [sortOption, setSortOption] = useState("featured")

  // State for mobile filter visibility
  const [mobileFiltersOpen, setMobileFiltersOpen] = useState(false)

  // Ref for gallery container (for scrolling)
  const galleryRef = useRef<HTMLDivElement>(null)

  // Get accessibility settings
  const { prefersReducedMotion } = useAccessibility()

  // Load products on mount
  useEffect(() => {
    const loadProducts = async () => {
      setIsLoading(true)

      try {
        // Simulate API call
        await new Promise((resolve) => setTimeout(resolve, 1500))
        setProducts(sampleProducts)
      } catch (error) {
        console.error("Failed to load products:", error)
      } finally {
        setIsLoading(false)
      }
    }

    loadProducts()
  }, [])

  // Apply filters and sorting
  useEffect(() => {
    let result = [...products]

    // Apply type filter
    if (activeFilters.type !== "all") {
      result = result.filter((product) => product.type === activeFilters.type)
    }

    // Apply category filter
    if (activeFilters.category !== "all") {
      result = result.filter((product) => product.category === activeFilters.category)
    }

    // Apply price range filter
    result = result.filter(
      (product) => product.price >= activeFilters.priceRange[0] && product.price <= activeFilters.priceRange[1],
    )

    // Apply new only filter
    if (activeFilters.newOnly) {
      result = result.filter((product) => product.isNew)
    }

    // Apply sorting
    switch (sortOption) {
      case "price-low-high":
        result.sort((a, b) => a.price - b.price)
        break
      case "price-high-low":
        result.sort((a, b) => b.price - a.price)
        break
      case "newest":
        // In a real app, you'd sort by date
        result.sort((a, b) => (a.isNew ? -1 : 1) - (b.isNew ? -1 : 1))
        break
      case "featured":
      default:
        // Keep original order for featured
        break
    }

    setFilteredProducts(result)
    setTotalPages(Math.ceil(result.length / PRODUCTS_PER_PAGE))

    // Reset to first page when filters change
    setCurrentPage(1)
  }, [products, activeFilters, sortOption])

  // Update visible products when filtered products or current page changes
  useEffect(() => {
    const startIndex = (currentPage - 1) * PRODUCTS_PER_PAGE
    const endIndex = startIndex + PRODUCTS_PER_PAGE
    setVisibleProducts(filteredProducts.slice(startIndex, endIndex))
  }, [filteredProducts, currentPage])

  // Handle pagination
  const handlePageChange = (page: number) => {
    if (page < 1 || page > totalPages) return
    setCurrentPage(page)

    // Scroll to top of gallery with smooth scrolling
    if (galleryRef.current) {
      galleryRef.current.scrollIntoView({ behavior: "smooth" })
    }
  }

  // Handle filter changes
  const handleFilterChange = (filterType: string, value: any) => {
    setActiveFilters((prev) => ({
      ...prev,
      [filterType]: value,
    }))
  }

  // Reset all filters
  const resetFilters = () => {
    setActiveFilters({
      type: "all",
      category: "all",
      priceRange: [0, 200],
      newOnly: false,
    })
    setSortOption("featured")
  }

  // Get unique categories from products
  const categories = ["all", ...new Set(products.map((p) => p.category || ""))]

  // Animation settings based on accessibility preferences
  const containerAnimation = {
    initial: { opacity: 0 },
    animate: { opacity: 1 },
    exit: { opacity: 0 },
    transition: {
      duration: prefersReducedMotion ? 0.1 : 0.4,
    },
  }

  return (
    <div ref={galleryRef} className="py-16 md:py-24 relative overflow-hidden" id="product-gallery">
      <div className="absolute inset-0 bg-gradient-to-b from-midnight-blue to-midnight-teal opacity-95" />

      {/* Decorative elements */}
      <FloatingMagnolia size="lg" color="gold" className="absolute top-12 right-[10%] opacity-30" />
      <FloatingMagnolia size="md" color="white" className="absolute bottom-24 left-[15%] opacity-20" delay={1.5} />

      <div className="container relative z-10 px-4">
        <div className="text-center mb-12">
          <h2 className="text-3xl md:text-4xl font-serif font-bold text-rich-gold mb-4">Digital Sanctuary</h2>
          <p className="text-lg text-magnolia-white/80 max-w-2xl mx-auto font-lora">
            Explore our collection of digital products designed to enhance your entrepreneurial journey.
          </p>
        </div>

        {/* Filters and Sorting - Desktop */}
        <div className="hidden md:flex justify-between items-center mb-8">
          <div className="flex items-center gap-4">
            {/* Product Type Filter */}
            <div>
              <Select value={activeFilters.type} onValueChange={(value) => handleFilterChange("type", value)}>
                <SelectTrigger className="w-[180px] bg-midnight-blue/50 border-rich-gold/30 text-magnolia-white">
                  <SelectValue placeholder="Product Type" />
                </SelectTrigger>
                <SelectContent className="bg-midnight-blue border-rich-gold/30">
                  <SelectItem value="all">All Types</SelectItem>
                  <SelectItem value="digital">Digital Only</SelectItem>
                  <SelectItem value="physical">Physical Only</SelectItem>
                </SelectContent>
              </Select>
            </div>

            {/* Category Filter */}
            <div>
              <Select value={activeFilters.category} onValueChange={(value) => handleFilterChange("category", value)}>
                <SelectTrigger className="w-[180px] bg-midnight-blue/50 border-rich-gold/30 text-magnolia-white">
                  <SelectValue placeholder="Category" />
                </SelectTrigger>
                <SelectContent className="bg-midnight-blue border-rich-gold/30">
                  {categories.map((category) => (
                    <SelectItem key={category} value={category}>
                      {category === "all" ? "All Categories" : category}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>

            {/* New Only Filter */}
            <div className="flex items-center gap-2">
              <Checkbox
                id="new-only"
                checked={activeFilters.newOnly}
                onCheckedChange={(checked) => handleFilterChange("newOnly", checked === true)}
                className="border-rich-gold/50 data-[state=checked]:bg-rich-gold data-[state=checked]:text-midnight-blue"
              />
              <Label htmlFor="new-only" className="text-magnolia-white cursor-pointer">
                New Arrivals Only
              </Label>
            </div>

            {/* Reset Filters */}
            <Button
              variant="outline"
              size="sm"
              onClick={resetFilters}
              className="border-rich-gold/50 text-rich-gold hover:bg-rich-gold/10"
            >
              Reset Filters
            </Button>
          </div>

          {/* Sorting */}
          <div>
            <Select value={sortOption} onValueChange={setSortOption}>
              <SelectTrigger className="w-[180px] bg-midnight-blue/50 border-rich-gold/30 text-magnolia-white">
                <SelectValue placeholder="Sort By" />
              </SelectTrigger>
              <SelectContent className="bg-midnight-blue border-rich-gold/30">
                <SelectItem value="featured">Featured</SelectItem>
                <SelectItem value="price-low-high">Price: Low to High</SelectItem>
                <SelectItem value="price-high-low">Price: High to Low</SelectItem>
                <SelectItem value="newest">Newest First</SelectItem>
              </SelectContent>
            </Select>
          </div>
        </div>

        {/* Filters and Sorting - Mobile */}
        <div className="flex md:hidden justify-between items-center mb-8">
          <Sheet open={mobileFiltersOpen} onOpenChange={setMobileFiltersOpen}>
            <SheetTrigger asChild>
              <Button variant="outline" className="border-rich-gold/50 text-rich-gold hover:bg-rich-gold/10">
                <Filter className="h-4 w-4 mr-2" />
                Filters
              </Button>
            </SheetTrigger>
            <SheetContent side="left" className="bg-midnight-blue border-r border-rich-gold/30 w-[300px]">
              <SheetHeader>
                <SheetTitle className="text-rich-gold font-serif">Filters</SheetTitle>
                <SheetDescription className="text-magnolia-white/70">Refine your product search</SheetDescription>
              </SheetHeader>

              <div className="py-6 space-y-6">
                <Accordion type="single" collapsible className="w-full">
                  {/* Product Type */}
                  <AccordionItem value="type" className="border-rich-gold/30">
                    <AccordionTrigger className="text-magnolia-white hover:text-rich-gold">
                      Product Type
                    </AccordionTrigger>
                    <AccordionContent>
                      <div className="space-y-2 pt-2">
                        {["all", "digital", "physical"].map((type) => (
                          <div key={type} className="flex items-center gap-2">
                            <Checkbox
                              id={`type-${type}`}
                              checked={activeFilters.type === type}
                              onCheckedChange={() => {
                                handleFilterChange("type", type)
                                setMobileFiltersOpen(false)
                              }}
                              className="border-rich-gold/50 data-[state=checked]:bg-rich-gold data-[state=checked]:text-midnight-blue"
                            />
                            <Label htmlFor={`type-${type}`} className="text-magnolia-white cursor-pointer">
                              {type === "all" ? "All Types" : type === "digital" ? "Digital Only" : "Physical Only"}
                            </Label>
                          </div>
                        ))}
                      </div>
                    </AccordionContent>
                  </AccordionItem>

                  {/* Category */}
                  <AccordionItem value="category" className="border-rich-gold/30">
                    <AccordionTrigger className="text-magnolia-white hover:text-rich-gold">Category</AccordionTrigger>
                    <AccordionContent>
                      <div className="space-y-2 pt-2">
                        {categories.map((category) => (
                          <div key={category} className="flex items-center gap-2">
                            <Checkbox
                              id={`category-${category}`}
                              checked={activeFilters.category === category}
                              onCheckedChange={() => {
                                handleFilterChange("category", category)
                                setMobileFiltersOpen(false)
                              }}
                              className="border-rich-gold/50 data-[state=checked]:bg-rich-gold data-[state=checked]:text-midnight-blue"
                            />
                            <Label htmlFor={`category-${category}`} className="text-magnolia-white cursor-pointer">
                              {category === "all" ? "All Categories" : category}
                            </Label>
                          </div>
                        ))}
                      </div>
                    </AccordionContent>
                  </AccordionItem>

                  {/* Price Range */}
                  <AccordionItem value="price" className="border-rich-gold/30">
                    <AccordionTrigger className="text-magnolia-white hover:text-rich-gold">
                      Price Range
                    </AccordionTrigger>
                    <AccordionContent>
                      <div className="space-y-6 pt-2">
                        <div className="flex justify-between">
                          <span className="text-magnolia-white">${activeFilters.priceRange[0]}</span>
                          <span className="text-magnolia-white">${activeFilters.priceRange[1]}</span>
                        </div>
                        <Slider
                          defaultValue={activeFilters.priceRange}
                          min={0}
                          max={200}
                          step={10}
                          onValueChange={(value) => handleFilterChange("priceRange", value)}
                          className="[&_[role=slider]]:bg-rich-gold"
                        />
                      </div>
                    </AccordionContent>
                  </AccordionItem>

                  {/* New Only */}
                  <AccordionItem value="new" className="border-rich-gold/30">
                    <AccordionTrigger className="text-magnolia-white hover:text-rich-gold">
                      New Arrivals
                    </AccordionTrigger>
                    <AccordionContent>
                      <div className="flex items-center gap-2 pt-2">
                        <Checkbox
                          id="mobile-new-only"
                          checked={activeFilters.newOnly}
                          onCheckedChange={(checked) => handleFilterChange("newOnly", checked === true)}
                          className="border-rich-gold/50 data-[state=checked]:bg-rich-gold data-[state=checked]:text-midnight-blue"
                        />
                        <Label htmlFor="mobile-new-only" className="text-magnolia-white cursor-pointer">
                          Show only new arrivals
                        </Label>
                      </div>
                    </AccordionContent>
                  </AccordionItem>
                </Accordion>

                {/* Sorting - Mobile */}
                <div className="space-y-2">
                  <h3 className="text-rich-gold font-serif text-lg">Sort By</h3>
                  <Select
                    value={sortOption}
                    onValueChange={(value) => {
                      setSortOption(value)
                      setMobileFiltersOpen(false)
                    }}
                  >
                    <SelectTrigger className="w-full bg-midnight-blue/50 border-rich-gold/30 text-magnolia-white">
                      <SelectValue placeholder="Sort By" />
                    </SelectTrigger>
                    <SelectContent className="bg-midnight-blue border-rich-gold/30">
                      <SelectItem value="featured">Featured</SelectItem>
                      <SelectItem value="price-low-high">Price: Low to High</SelectItem>
                      <SelectItem value="price-high-low">Price: High to Low</SelectItem>
                      <SelectItem value="newest">Newest First</SelectItem>
                    </SelectContent>
                  </Select>
                </div>

                {/* Reset Filters - Mobile */}
                <Button
                  variant="outline"
                  onClick={() => {
                    resetFilters()
                    setMobileFiltersOpen(false)
                  }}
                  className="w-full border-rich-gold/50 text-rich-gold hover:bg-rich-gold/10"
                >
                  Reset All Filters
                </Button>
              </div>

              <SheetClose asChild>
                <Button className="mt-4 bg-rich-gold hover:bg-rich-gold/90 text-midnight-blue w-full">
                  Apply Filters
                </Button>
              </SheetClose>
            </SheetContent>
          </Sheet>

          {/* Mobile Sort */}
          <Select value={sortOption} onValueChange={setSortOption}>
            <SelectTrigger className="w-[140px] bg-midnight-blue/50 border-rich-gold/30 text-magnolia-white">
              <SelectValue placeholder="Sort By" />
            </SelectTrigger>
            <SelectContent className="bg-midnight-blue border-rich-gold/30">
              <SelectItem value="featured">Featured</SelectItem>
              <SelectItem value="price-low-high">Price: Low to High</SelectItem>
              <SelectItem value="price-high-low">Price: High to Low</SelectItem>
              <SelectItem value="newest">Newest First</SelectItem>
            </SelectContent>
          </Select>
        </div>

        {/* Active Filters Display */}
        {(activeFilters.type !== "all" ||
          activeFilters.category !== "all" ||
          activeFilters.newOnly ||
          activeFilters.priceRange[0] > 0 ||
          activeFilters.priceRange[1] < 200) && (
          <div className="flex flex-wrap gap-2 mb-6">
            <span className="text-magnolia-white/70">Active Filters:</span>

            {activeFilters.type !== "all" && (
              <button
                onClick={() => handleFilterChange("type", "all")}
                className="flex items-center gap-1 px-2 py-1 bg-rich-gold/10 border border-rich-gold/30 rounded-full text-rich-gold text-sm"
                aria-label={`Remove ${activeFilters.type} filter`}
              >
                {activeFilters.type === "digital" ? "Digital Only" : "Physical Only"}
                <X className="h-3 w-3" />
              </button>
            )}

            {activeFilters.category !== "all" && (
              <button
                onClick={() => handleFilterChange("category", "all")}
                className="flex items-center gap-1 px-2 py-1 bg-rich-gold/10 border border-rich-gold/30 rounded-full text-rich-gold text-sm"
                aria-label={`Remove ${activeFilters.category} category filter`}
              >
                {activeFilters.category}
                <X className="h-3 w-3" />
              </button>
            )}

            {activeFilters.newOnly && (
              <button
                onClick={() => handleFilterChange("newOnly", false)}
                className="flex items-center gap-1 px-2 py-1 bg-rich-gold/10 border border-rich-gold/30 rounded-full text-rich-gold text-sm"
                aria-label="Remove new arrivals only filter"
              >
                New Arrivals Only
                <X className="h-3 w-3" />
              </button>
            )}

            {(activeFilters.priceRange[0] > 0 || activeFilters.priceRange[1] < 200) && (
              <button
                onClick={() => handleFilterChange("priceRange", [0, 200])}
                className="flex items-center gap-1 px-2 py-1 bg-rich-gold/10 border border-rich-gold/30 rounded-full text-rich-gold text-sm"
                aria-label="Remove price range filter"
              >
                ${activeFilters.priceRange[0]} - ${activeFilters.priceRange[1]}
                <X className="h-3 w-3" />
              </button>
            )}

            <button
              onClick={resetFilters}
              className="flex items-center gap-1 px-2 py-1 bg-rich-gold/10 border border-rich-gold/30 rounded-full text-rich-gold text-sm"
              aria-label="Clear all filters"
            >
              Clear All
              <X className="h-3 w-3" />
            </button>
          </div>
        )}

        {/* Results Count */}
        <div className="mb-6">
          <p className="text-magnolia-white/70">
            Showing {filteredProducts.length} {filteredProducts.length === 1 ? "product" : "products"}
          </p>
        </div>

        {/* Product Grid */}
        <AnimatePresence mode="wait">
          <motion.div
            key={`${activeFilters.type}-${activeFilters.category}-${activeFilters.newOnly}-${sortOption}-${currentPage}`}
            {...containerAnimation}
            className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6 md:gap-8"
          >
            {isLoading ? (
              // Loading skeletons
              Array.from({ length: PRODUCTS_PER_PAGE }).map((_, index) => (
                <div
                  key={index}
                  className="bg-midnight-blue/50 border border-rich-gold/20 rounded-lg overflow-hidden h-full"
                >
                  <Skeleton className="h-64 w-full" />
                  <div className="p-5">
                    <Skeleton className="h-6 w-3/4 mb-2" />
                    <Skeleton className="h-4 w-1/4 mb-4" />
                    <Skeleton className="h-4 w-full mb-2" />
                    <Skeleton className="h-4 w-full mb-2" />
                    <Skeleton className="h-4 w-2/3 mb-4" />
                    <div className="flex justify-between">
                      <Skeleton className="h-8 w-24" />
                      <Skeleton className="h-8 w-24" />
                    </div>
                  </div>
                </div>
              ))
            ) : filteredProducts.length === 0 ? (
              // No results
              <div className="col-span-full py-12 text-center">
                <p className="text-magnolia-white/90 font-lora text-lg mb-4">No products match your current filters.</p>
                <Button onClick={resetFilters} className="bg-rich-gold hover:bg-rich-gold/90 text-midnight-blue">
                  Reset Filters
                </Button>
              </div>
            ) : (
              // Product cards
              visibleProducts.map((product) => <ProductCard key={product.id} product={product} />)
            )}
          </motion.div>
        </AnimatePresence>

        {/* Pagination */}
        {!isLoading && totalPages > 1 && (
          <div className="flex justify-center items-center mt-12" role="navigation" aria-label="Pagination">
            <Button
              variant="outline"
              size="icon"
              className="rounded-full border-rich-gold/50 text-rich-gold hover:bg-rich-gold/10 mr-4"
              onClick={() => handlePageChange(currentPage - 1)}
              disabled={currentPage === 1}
              aria-label="Previous page"
            >
              <ChevronLeft className="h-5 w-5" />
            </Button>

            <div className="flex gap-2">
              {Array.from({ length: totalPages }, (_, i) => i + 1).map((page) => (
                <Button
                  key={page}
                  variant={page === currentPage ? "default" : "outline"}
                  size="icon"
                  className={`w-8 h-8 rounded-full ${
                    page === currentPage
                      ? "bg-rich-gold text-midnight-blue"
                      : "border-rich-gold/50 text-magnolia-white hover:bg-rich-gold/10"
                  }`}
                  onClick={() => handlePageChange(page)}
                  aria-label={`Page ${page}`}
                  aria-current={page === currentPage ? "page" : undefined}
                >
                  {page}
                </Button>
              ))}
            </div>

            <Button
              variant="outline"
              size="icon"
              className="rounded-full border-rich-gold/50 text-rich-gold hover:bg-rich-gold/10 ml-4"
              onClick={() => handlePageChange(currentPage + 1)}
              disabled={currentPage === totalPages}
              aria-label="Next page"
            >
              <ChevronRight className="h-5 w-5" />
            </Button>
          </div>
        )}
      </div>
    </div>
  )
}

