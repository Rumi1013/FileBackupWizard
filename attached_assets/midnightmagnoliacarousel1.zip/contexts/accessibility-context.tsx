"use client"

import { createContext, useContext, useState, useEffect, type ReactNode } from "react"

// Define the accessibility configuration type
interface AccessibilityConfig {
  focus: {
    outlineWidth: string
    outlineColor: string
    outlineOffset: string
  }
  animation: {
    reducedMotion: boolean
    transitionDuration: string
  }
  contrast: {
    textToBackground: string
    primaryElements: string
  }
}

// Default configuration
const defaultConfig: AccessibilityConfig = {
  focus: {
    outlineWidth: "3px",
    outlineColor: "#D4AF37", // rich-gold
    outlineOffset: "2px",
  },
  animation: {
    reducedMotion: false,
    transitionDuration: "0.3s",
  },
  contrast: {
    textToBackground: "7:1",
    primaryElements: "4.5:1",
  },
}

// Create the context
const AccessibilityContext = createContext<{
  config: AccessibilityConfig
  updateConfig: (newConfig: Partial<AccessibilityConfig>) => void
  prefersReducedMotion: boolean
}>({
  config: defaultConfig,
  updateConfig: () => {},
  prefersReducedMotion: false,
})

// Hook to use the accessibility context
export function useAccessibility() {
  return useContext(AccessibilityContext)
}

// Provider component
export function AccessibilityProvider({ children }: { children: ReactNode }) {
  const [config, setConfig] = useState<AccessibilityConfig>(defaultConfig)
  const [prefersReducedMotion, setPrefersReducedMotion] = useState(false)

  // Check for user preference for reduced motion
  useEffect(() => {
    const mediaQuery = window.matchMedia("(prefers-reduced-motion: reduce)")
    setPrefersReducedMotion(mediaQuery.matches)

    const handleChange = (e: MediaQueryListEvent) => {
      setPrefersReducedMotion(e.matches)

      // Update config when user preference changes
      setConfig((prev) => ({
        ...prev,
        animation: {
          ...prev.animation,
          reducedMotion: e.matches,
        },
      }))
    }

    mediaQuery.addEventListener("change", handleChange)
    return () => mediaQuery.removeEventListener("change", handleChange)
  }, [])

  // Apply focus styles to CSS variables
  useEffect(() => {
    document.documentElement.style.setProperty("--focus-outline-width", config.focus.outlineWidth)
    document.documentElement.style.setProperty("--focus-outline-color", config.focus.outlineColor)
    document.documentElement.style.setProperty("--focus-outline-offset", config.focus.outlineOffset)
    document.documentElement.style.setProperty("--transition-duration", config.animation.transitionDuration)
  }, [config])

  // Function to update config
  const updateConfig = (newConfig: Partial<AccessibilityConfig>) => {
    setConfig((prev) => ({
      ...prev,
      ...newConfig,
      focus: {
        ...prev.focus,
        ...(newConfig.focus || {}),
      },
      animation: {
        ...prev.animation,
        ...(newConfig.animation || {}),
      },
      contrast: {
        ...prev.contrast,
        ...(newConfig.contrast || {}),
      },
    }))
  }

  return (
    <AccessibilityContext.Provider value={{ config, updateConfig, prefersReducedMotion }}>
      {children}
    </AccessibilityContext.Provider>
  )
}

