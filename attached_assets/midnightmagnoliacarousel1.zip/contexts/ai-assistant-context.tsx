"use client"

import { createContext, useContext, useState, useEffect, type ReactNode } from "react"

interface Message {
  id: string
  role: "user" | "assistant"
  content: string
  timestamp: Date
}

interface AIAssistantContextType {
  messages: Message[]
  isOpen: boolean
  isMinimized: boolean
  isLoading: boolean
  isTyping: boolean
  input: string
  setInput: (input: string) => void
  setIsOpen: (isOpen: boolean) => void
  setIsMinimized: (isMinimized: boolean) => void
  sendMessage: (content: string) => Promise<void>
  clearMessages: () => void
}

const AIAssistantContext = createContext<AIAssistantContextType | undefined>(undefined)

export function useAIAssistant() {
  const context = useContext(AIAssistantContext)
  if (context === undefined) {
    throw new Error("useAIAssistant must be used within an AIAssistantProvider")
  }
  return context
}

interface AIAssistantProviderProps {
  children: ReactNode
}

// Predefined responses based on keywords
const predefinedResponses: Record<string, string[]> = {
  default: [
    "I'd be happy to help you with that! Is there anything specific you'd like to know about Midnight Magnolia?",
    "Thank you for reaching out. How can I assist you with your entrepreneurial journey today?",
    "I'm here to help you navigate Midnight Magnolia's offerings. What are you most interested in learning about?",
  ],
  services: [
    "Midnight Magnolia offers several signature services including Digital Product Mastery ($1,997), our Midnight Magnolia Membership ($97/month), and VIP Strategy Days ($3,500). Each is designed to support neurodivergent entrepreneurs at different stages of their journey. Would you like more details about any of these?",
    "Our services are designed specifically for neurodivergent entrepreneurs seeking sustainable success. From our 8-week Digital Product Mastery program to our VIP Strategy Days, we focus on creating systems that work with your unique brain wiring, not against it.",
    "Latisha's approach to services centers on honoring neurodivergent thinking as a creative advantage. Whether through our membership community or 1:1 support, we help you build business systems that support long-term success without burnout.",
  ],
  products: [
    "Our digital products include the Midnight Entrepreneur Planner ($49), Southern Digital Brand Kit ($79), and our bestselling Midnight Strategy Vault ($97). Each is designed with neurodivergent entrepreneurs in mind, featuring clear organization and flexible implementation options.",
    "Midnight Magnolia's digital products offer exceptional profit margins (85-98%) and can be created in just 2-7 days. From planners to template bundles, each product embodies our Southern Gothic aesthetic while providing practical business tools.",
    "Looking for passive income streams? Our digital products are designed to be both beautiful and functional, with the Midnight Entrepreneur Planner being our most popular offering for ADHD and neurodivergent business owners.",
  ],
  about: [
    "Midnight Magnolia was born from founder Latisha Vincent-Waters' personal journey through burnout, activism trauma, and her ADHD diagnosis at age 42. It represents a reclamation of creative and financial power that bridges Southern heritage with digital innovation.",
    "At Midnight Magnolia, we believe in the power of showing up as your full, unmasked self. Our approach honors neurodivergent thinking as a creative advantage, not a limitation, while embracing the elegant resilience of Southern Gothic aesthetics.",
    "Like the magnolia tree that blooms through adversity and stands strong against storms, Midnight Magnolia represents endurance and beauty through challenge. Our brand exists at the intersection of neurodivergent entrepreneurship, digital innovation, and Southern resilience.",
  ],
  blog: [
    "Our blog, Midnight Musings, features articles on neurodivergent entrepreneurship, digital product creation, and sustainable business practices. Our most popular post is 'The Neurodivergent Entrepreneur's Guide to Sustainable Success.'",
    "Latisha regularly shares insights on topics like building systems for ADHD entrepreneurs, creating high-margin digital products, and embracing rest as resistance against hustle culture on our Midnight Musings blog.",
    "The Midnight Magnolia blog explores the intersection of neurodivergence, entrepreneurship, and Southern Gothic aesthetics. Recent topics include 'From Burnout to Brilliance' and 'The Power of Diagnosis: How ADHD Changed My Business.'",
  ],
  pricing: [
    "Our digital products range from $37 for the Magnolia AI Prompt Collection to $97 for the comprehensive Midnight Strategy Vault. For services, we offer the Digital Product Mastery program at $1,997, monthly membership at $97/month, and VIP Strategy Days at $3,500.",
    "Midnight Magnolia offers options for various budgets, from self-paced digital products starting at $37 to high-touch services like our VIP Strategy Day at $3,500. Payment plans are available for all our programs.",
    "Investment in our signature Digital Product Mastery program is $1,997 with payment plans available. Our membership is $97/month or $997 annually (saving $167). Digital products range from $37-97 depending on complexity.",
  ],
  contact: [
    "You can reach us at contact@midnightmagnolia.com or schedule a complimentary discovery call through our website. We're also active on Instagram (@rumi_nationz) and Facebook (@ruminationsshop).",
    "The best way to connect with Latisha is to book a discovery call through our website or email contact@midnightmagnolia.com. We aim to respond to all inquiries within 48 hours.",
    "For questions about our services or products, please email contact@midnightmagnolia.com or use the contact form on our website. We're based in New Orleans, Louisiana, with virtual services available worldwide.",
  ],
}

export function AIAssistantProvider({ children }: AIAssistantProviderProps) {
  const [messages, setMessages] = useState<Message[]>([
    {
      id: "1",
      role: "assistant",
      content:
        "Hello! I'm your Midnight Magnolia assistant. How can I help you navigate our Southern Gothic digital sanctuary today?",
      timestamp: new Date(),
    },
  ])
  const [isOpen, setIsOpen] = useState(false)
  const [isMinimized, setIsMinimized] = useState(false)
  const [isLoading, setIsLoading] = useState(false)
  const [isTyping, setIsTyping] = useState(false)
  const [input, setInput] = useState("")

  // Load messages from localStorage on initial render
  useEffect(() => {
    const storedMessages = localStorage.getItem("mm_assistant_messages")
    if (storedMessages) {
      try {
        const parsedMessages = JSON.parse(storedMessages)
        // Convert string timestamps back to Date objects
        const messagesWithDateObjects = parsedMessages.map((msg: any) => ({
          ...msg,
          timestamp: new Date(msg.timestamp),
        }))
        setMessages(messagesWithDateObjects)
      } catch (error) {
        console.error("Error parsing stored messages:", error)
      }
    }
  }, [])

  // Save messages to localStorage when they change
  useEffect(() => {
    localStorage.setItem("mm_assistant_messages", JSON.stringify(messages))
  }, [messages])

  const findRelevantResponse = (input: string): string => {
    const lowercaseInput = input.toLowerCase()

    // Check for keywords in the input
    for (const [category, responses] of Object.entries(predefinedResponses)) {
      if (category === "default") continue

      const keywords = {
        services: ["service", "program", "coaching", "membership", "vip", "strategy day", "mastery"],
        products: ["product", "digital product", "planner", "template", "vault", "brand kit", "journal"],
        about: ["about", "story", "latisha", "founder", "mission", "values", "history"],
        blog: ["blog", "article", "post", "content", "read", "midnight musings"],
        pricing: ["price", "cost", "fee", "payment", "invest", "afford", "expensive", "cheap"],
        contact: ["contact", "email", "phone", "reach", "message", "call", "schedule"],
      }

      if (keywords[category as keyof typeof keywords].some((keyword) => lowercaseInput.includes(keyword))) {
        return responses[Math.floor(Math.random() * responses.length)]
      }
    }

    // If no specific category matches, return a default response
    const defaultResponses = predefinedResponses.default
    return defaultResponses[Math.floor(Math.random() * defaultResponses.length)]
  }

  const simulateTyping = async (content: string) => {
    setIsTyping(true)

    // Add a temporary typing message
    const typingMessage: Message = {
      id: `typing-${Date.now()}`,
      role: "assistant",
      content: "...",
      timestamp: new Date(),
    }

    setMessages((prev) => [...prev, typingMessage])

    // Simulate typing delay based on message length
    const typingDelay = Math.min(1500, Math.max(800, content.length * 10))
    await new Promise((resolve) => setTimeout(resolve, typingDelay))

    // Remove typing indicator and add the actual message
    setMessages((prev) => prev.filter((msg) => msg.id !== typingMessage.id))
    setIsTyping(false)

    const assistantMessage: Message = {
      id: Date.now().toString(),
      role: "assistant",
      content: content,
      timestamp: new Date(),
    }

    setMessages((prev) => [...prev, assistantMessage])
  }

  const sendMessage = async (content: string) => {
    if (!content.trim() || isLoading || isTyping) return

    // Add user message
    const userMessage: Message = {
      id: Date.now().toString(),
      role: "user",
      content,
      timestamp: new Date(),
    }

    setMessages((prev) => [...prev, userMessage])
    setInput("")
    setIsLoading(true)

    try {
      // Find a relevant response based on the user's input
      const response = findRelevantResponse(content)

      // Simulate API call delay
      await new Promise((resolve) => setTimeout(resolve, 500))

      // Simulate typing
      await simulateTyping(response)
    } catch (error) {
      console.error("Error sending message to AI assistant:", error)

      // Add error message
      const errorMessage: Message = {
        id: Date.now().toString(),
        role: "assistant",
        content: "I apologize, but I encountered an error. Please try again later.",
        timestamp: new Date(),
      }

      setMessages((prev) => [...prev, errorMessage])
    } finally {
      setIsLoading(false)
    }
  }

  const clearMessages = () => {
    setMessages([
      {
        id: "1",
        role: "assistant",
        content:
          "Hello! I'm your Midnight Magnolia assistant. How can I help you navigate our Southern Gothic digital sanctuary today?",
        timestamp: new Date(),
      },
    ])
  }

  return (
    <AIAssistantContext.Provider
      value={{
        messages,
        isOpen,
        isMinimized,
        isLoading,
        isTyping,
        input,
        setInput,
        setIsOpen,
        setIsMinimized,
        sendMessage,
        clearMessages,
      }}
    >
      {children}
    </AIAssistantContext.Provider>
  )
}

